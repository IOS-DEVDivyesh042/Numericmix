import UIKit

class Distance: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    weak var delegate: destance?
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputLabel: UILabel!
    @IBOutlet weak var unitPickerView: UIPickerView!

    let distanceUnits = ["Meters", "Kilometers", "Feet", "Miles", "Yards", "Inches"]

    override func viewDidLoad() {
        super.viewDidLoad()
        unitPickerView.delegate = self
        unitPickerView.dataSource = self
    }

    override func viewWillDisappear(_ animated: Bool) {
           super.viewWillDisappear(animated)
           if isMovingFromParent {
               // This view controller is being popped off the navigation stack
               delegate?.switchStateChanged2(isOn: false)
           }
       }
    
    @IBAction func convertButtonPressed(_ sender: UIButton) {
        guard let inputValueText = inputTextField.text, let inputValue = Double(inputValueText) else {
            showAlert(message: "Please enter a valid number.")
            return
        }

        let selectedUnit = distanceUnits[unitPickerView.selectedRow(inComponent: 0)]
        let conversionFactor = conversionFactorForUnit(unit: selectedUnit)

        let convertedValue = inputValue * conversionFactor
        outputLabel.text = "\(inputValue) \(selectedUnit) is \(convertedValue) \(outputUnit())"
    }

    func conversionFactorForUnit(unit: String) -> Double {
        switch unit {
        case "Meters":
            return 1.0
        case "Kilometers":
            return 0.001
        case "Feet":
            return 3.28084
        case "Miles":
            return 0.000621371
        case "Yards":
            return 1.09361
        case "Inches":
            return 39.3701
        default:
            return 1.0
        }
    }

    func outputUnit() -> String {
        return distanceUnits[unitPickerView.selectedRow(inComponent: 0)]
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }

    // MARK: - UIPickerViewDataSource

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return distanceUnits.count
    }

    // MARK: - UIPickerViewDelegate

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return distanceUnits[row]
    }
}
