import UIKit

class Area : UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
   
    weak var delegate: AreaViewControllerDelegate?
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputLabel: UILabel!
    @IBOutlet weak var unitPickerView: UIPickerView!

    let units = ["Square Meters", "Square Feet", "Square Kilometers", "Square Miles", "Hectares", "Acres"]

    override func viewDidLoad() {
        super.viewDidLoad()
        unitPickerView.delegate = self
        unitPickerView.dataSource = self
    }

    override func viewWillDisappear(_ animated: Bool) {
           super.viewWillDisappear(animated)
           if isMovingFromParent {
               // This view controller is being popped off the navigation stack
               delegate?.switchStateChanged(isOn: false)
           }
       }
    
    @IBAction func convertButtonPressed(_ sender: UIButton) {
        guard let inputValueText = inputTextField.text, let inputValue = Double(inputValueText) else {
            showAlert(message: "Please enter a valid number.")
            return
        }

        let selectedUnit = units[unitPickerView.selectedRow(inComponent: 0)]
        let conversionFactor = conversionFactorForUnit(unit: selectedUnit)

        let convertedValue = inputValue * conversionFactor
        outputLabel.text = "\(inputValue) \(selectedUnit) is \(convertedValue) \(outputUnit())"
    }

    func conversionFactorForUnit(unit: String) -> Double {
        switch unit {
        case "Square Meters":
            return 1.0
        case "Square Feet":
            return 10.7639
        case "Square Kilometers":
            return 1_000_000.0
        case "Square Miles":
            return 2_589_988.11
        case "Hectares":
            return 10_000.0
        case "Acres":
            return 43_560.0
        default:
            return 1.0
        }
    }

    func outputUnit() -> String {
        return units[unitPickerView.selectedRow(inComponent: 0)]
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }

    // MARK: - UIPickerViewDataSource

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return units.count
    }

    // MARK: - UIPickerViewDelegate

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return units[row]
    }
}

