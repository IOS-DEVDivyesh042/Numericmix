import UIKit

class Density: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputLabel: UILabel!
    @IBOutlet weak var unitPickerView: UIPickerView!
    weak var delegate: Densityss?
    
    let densityUnits = ["Kilograms per Cubic Meter", "Grams per Cubic Centimeter", "Pounds per Cubic Foot", "Ounces per Cubic Inch", "Milligrams per Liter", "Pounds per Gallon"]

    override func viewDidLoad() {
        super.viewDidLoad()
        unitPickerView.delegate = self
        unitPickerView.dataSource = self
    }
    
    override func viewWillDisappear(_ animated: Bool) {
           super.viewWillDisappear(animated)
           if isMovingFromParent {
               // This view controller is being popped off the navigation stack
               delegate?.switchStateChanged4(isOn: false)
           }
       }
    

    @IBAction func convertButtonPressed(_ sender: UIButton) {
        guard let inputValueText = inputTextField.text, let inputValue = Double(inputValueText) else {
            showAlert(message: "Please enter a valid number.")
            return
        }

        let selectedUnit = densityUnits[unitPickerView.selectedRow(inComponent: 0)]
        let convertedValue = convertDensity(value: inputValue, fromUnit: selectedUnit)
        outputLabel.text = "\(inputValue) \(selectedUnit) is \(convertedValue) \(outputUnit())"
    }

    func convertDensity(value: Double, fromUnit: String) -> Double {
        switch fromUnit {
        case "Kilograms per Cubic Meter":
            return value
        case "Grams per Cubic Centimeter":
            return value * 1000.0
        case "Pounds per Cubic Foot":
            return value * 0.0624279606
        case "Ounces per Cubic Inch":
            return value * 0.000036127
        case "Milligrams per Liter":
            return value * 0.001
        case "Pounds per Gallon":
            return value * 0.00834540445
        default:
            return value
        }
    }

    func outputUnit() -> String {
        return densityUnits[unitPickerView.selectedRow(inComponent: 0)]
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }

    // MARK: - UIPickerViewDataSource

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return densityUnits.count
    }

    // MARK: - UIPickerViewDelegate

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return densityUnits[row]
    }
}
