import UIKit

class Speed: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    weak var delegate: speed?
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputLabel: UILabel!
    @IBOutlet weak var unitPickerView: UIPickerView!

    let speedUnits = ["Meters per Second", "Kilometers per Hour", "Feet per Second", "Miles per Hour", "Knots", "Speed of Light"]

    override func viewDidLoad() {
        super.viewDidLoad()
        unitPickerView.delegate = self
        unitPickerView.dataSource = self
    }

    override func viewWillDisappear(_ animated: Bool) {
           super.viewWillDisappear(animated)
           if isMovingFromParent {
               // This view controller is being popped off the navigation stack
               delegate?.switchStateChanged1(isOn: false)
           }
       }
    
    @IBAction func convertButtonPressed(_ sender: UIButton) {
        guard let inputValueText = inputTextField.text, let inputValue = Double(inputValueText) else {
            showAlert(message: "Please enter a valid number.")
            return
        }

        let selectedUnit = speedUnits[unitPickerView.selectedRow(inComponent: 0)]
        let conversionFactor = conversionFactorForUnit(unit: selectedUnit)

        let convertedValue = inputValue * conversionFactor
        outputLabel.text = "\(inputValue) \(selectedUnit) is \(convertedValue) \(outputUnit())"
    }

    func conversionFactorForUnit(unit: String) -> Double {
        switch unit {
        case "Meters per Second":
            return 1.0
        case "Kilometers per Hour":
            return 3.6
        case "Feet per Second":
            return 3.28084
        case "Miles per Hour":
            return 2.23694
        case "Knots":
            return 1.94384
        case "Speed of Light":
            return 299792458.0
        default:
            return 1.0
        }
    }

    func outputUnit() -> String {
        return speedUnits[unitPickerView.selectedRow(inComponent: 0)]
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }

    // MARK: - UIPickerViewDataSource

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return speedUnits.count
    }

    // MARK: - UIPickerViewDelegate

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return speedUnits[row]
    }
}
