
import UIKit

protocol AreaViewControllerDelegate: AnyObject {
    func switchStateChanged(isOn: Bool)
}

protocol speed: AnyObject {
    func switchStateChanged1(isOn: Bool)
}


protocol destance: AnyObject {
    func switchStateChanged2(isOn: Bool)
}

protocol Tempeta: AnyObject {
    func switchStateChanged3(isOn: Bool)
}


protocol Densityss: AnyObject {
    func switchStateChanged4(isOn: Bool)
}


class ViewController: UIViewController, AreaViewControllerDelegate, speed , Tempeta , Densityss,destance{
   
    
    
    @IBOutlet weak var btndens: UISwitch!
    
    @IBOutlet weak var btntemp: UISwitch!
    
    @IBOutlet weak var btndistance: UISwitch!
    
    @IBOutlet weak var btnarea: UISwitch!
    
    @IBOutlet weak var btnspeed: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    
    
    @IBAction func areaswitch(_ sender: Any) {
        if (sender as AnyObject).isOn {
            
            let vc = storyboard?.instantiateViewController(withIdentifier: "Area") as! Area
            vc.delegate = self
            navigationController?.pushViewController(vc, animated: true)
               }
        
    }
    
    
    @IBAction func speedbtn(_ sender: Any) {
        if (sender as AnyObject).isOn {
            
            let vc = storyboard?.instantiateViewController(withIdentifier: "Speed") as! Speed
            vc.delegate = self
            navigationController?.pushViewController(vc, animated: true)
               }
        
    }
    
    @IBAction func distancebtn(_ sender: Any) {
        if (sender as AnyObject).isOn {
            
            let vc = storyboard?.instantiateViewController(withIdentifier: "Distance") as! Distance
            vc.delegate = self
            navigationController?.pushViewController(vc, animated: true)
               }
        
    }
    
    
    @IBAction func btntemp(_ sender: Any) {
        if (sender as AnyObject).isOn {
            
            let vc = storyboard?.instantiateViewController(withIdentifier: "Temp") as! Temp
            vc.delegate = self
            navigationController?.pushViewController(vc, animated: true)
               }
        
    }
    
    
    @IBAction func btndensity(_ sender: Any) {
        if (sender as AnyObject).isOn {
            
            let vc = storyboard?.instantiateViewController(withIdentifier: "Density") as! Density
            vc.delegate = self
            navigationController?.pushViewController(vc, animated: true)
               }
        
    }
    
    
    
    
    
    
    func switchStateChanged(isOn: Bool) {
           btnarea.isOn = isOn
       }
    
    func switchStateChanged1(isOn: Bool) {
           btnspeed.isOn = isOn
       }
    
    func switchStateChanged2(isOn: Bool) {
           btndistance.isOn = isOn
       }
    
    func switchStateChanged3(isOn: Bool) {
           btntemp.isOn = isOn
       }
    
  
    func switchStateChanged4(isOn: Bool) {
           btndens.isOn = isOn
       }
    
    
   
    
    


}

