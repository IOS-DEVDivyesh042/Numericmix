import UIKit

class Temp: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputLabel: UILabel!
    @IBOutlet weak var unitPickerView: UIPickerView!
    weak var delegate: Tempeta?
    
    let temperatureUnits = ["Celsius", "Fahrenheit", "Kelvin"]

    override func viewDidLoad() {
        super.viewDidLoad()
        unitPickerView.delegate = self
        unitPickerView.dataSource = self
    }
    
    override func viewWillDisappear(_ animated: Bool) {
           super.viewWillDisappear(animated)
           if isMovingFromParent {
               // This view controller is being popped off the navigation stack
               delegate?.switchStateChanged3(isOn: false)
           }
       }
    

    @IBAction func convertButtonPressed(_ sender: UIButton) {
        guard let inputValueText = inputTextField.text, let inputValue = Double(inputValueText) else {
            showAlert(message: "Please enter a valid number.")
            return
        }

        let selectedUnit = temperatureUnits[unitPickerView.selectedRow(inComponent: 0)]
        let convertedValue = convertTemperature(value: inputValue, fromUnit: selectedUnit)
        outputLabel.text = "\(inputValue) \(selectedUnit) is \(convertedValue) \(outputUnit())"
    }

    func convertTemperature(value: Double, fromUnit: String) -> Double {
        switch fromUnit {
        case "Celsius":
            return convertCelsius(value)
        case "Fahrenheit":
            return convertFahrenheit(value)
        case "Kelvin":
            return convertKelvin(value)
        default:
            return value
        }
    }

    func convertCelsius(_ value: Double) -> Double {
        return value
    }

    func convertFahrenheit(_ value: Double) -> Double {
        return (value - 32) * 5/9
    }

    func convertKelvin(_ value: Double) -> Double {
        return value - 273.15
    }

    func outputUnit() -> String {
        return temperatureUnits[unitPickerView.selectedRow(inComponent: 0)]
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }

    // MARK: - UIPickerViewDataSource

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return temperatureUnits.count
    }

    // MARK: - UIPickerViewDelegate

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return temperatureUnits[row]
    }
}

