import UIKit

class teabreratio: UIViewController {

    @IBOutlet weak var teaTextField: UITextField!
    @IBOutlet weak var waterTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    @IBAction func calculateButtonPressed(_ sender: UIButton) {
        if let teaAmount = Double(teaTextField.text ?? ""),
           let waterAmount = Double(waterTextField.text ?? "") {
            let teaBrewRatio = teaAmount / waterAmount
            resultLabel.text = "Tea Brew Ratio: \(teaBrewRatio)"
        } else {
            resultLabel.text = "Invalid input. Please enter valid numbers."
        }
    }

    @IBAction func clearButtonPressed(_ sender: UIButton) {
        teaTextField.text = ""
        waterTextField.text = ""
        resultLabel.text = "Result will be shown here"
    }
}
