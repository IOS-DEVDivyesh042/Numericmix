import UIKit

class coldbrew: UIViewController {

    @IBOutlet weak var coffeeTextField: UITextField!
    @IBOutlet weak var waterTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    @IBAction func calculateButtonPressed(_ sender: UIButton) {
        if let coffeeAmount = Double(coffeeTextField.text ?? ""),
           let waterAmount = Double(waterTextField.text ?? "") {
            let coldBrewRatio = coffeeAmount / waterAmount
            resultLabel.text = "Cold Brew Ratio: \(coldBrewRatio)"
        } else {
            resultLabel.text = "Invalid input. Please enter valid numbers."
        }
    }

    @IBAction func clearButtonPressed(_ sender: UIButton) {
        coffeeTextField.text = ""
        waterTextField.text = ""
        resultLabel.text = "Result will be shown here"
    }
}
