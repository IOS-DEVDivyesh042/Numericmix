import UIKit

class cofootprint : UIViewController {

    @IBOutlet weak var coffeeTextField: UITextField!
    @IBOutlet weak var waterTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    @IBAction func calculateButtonPressed(_ sender: UIButton) {
        if let coffeeAmount = Double(coffeeTextField.text ?? ""),
           let waterAmount = Double(waterTextField.text ?? "") {
            
            // Assuming some arbitrary coefficients for environmental impact
            let cultivationImpact = 0.2
            let processingImpact = 0.1
            let transportationImpact = 0.05
            let brewingEnergyImpact = 0.15

            // Calculate the total environmental impact
            let totalImpact = (coffeeAmount * cultivationImpact) +
                             (coffeeAmount * processingImpact) +
                             (waterAmount * transportationImpact) +
                             (waterAmount * brewingEnergyImpact)

            resultLabel.text = "Coffee Footprint: \(totalImpact)"
        } else {
            resultLabel.text = "Invalid input. Please enter valid numbers."
        }
    }

    @IBAction func clearButtonPressed(_ sender: UIButton) {
        coffeeTextField.text = ""
        waterTextField.text = ""
        resultLabel.text = "Result will be shown here"
    }
}
