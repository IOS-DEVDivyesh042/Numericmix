import UIKit

class Cotowater : UIViewController {

    @IBOutlet weak var coffeeTextField: UITextField!
    @IBOutlet weak var ratioTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    @IBAction func calculateButtonPressed(_ sender: UIButton) {
        if let coffeeAmount = Double(coffeeTextField.text ?? ""),
           let ratio = Double(ratioTextField.text ?? "") {
            let waterAmount = coffeeAmount * ratio
            resultLabel.text = "Water needed: \(waterAmount) grams"
        } else {
            resultLabel.text = "Invalid input. Please enter valid numbers."
        }
    }

    @IBAction func clearButtonPressed(_ sender: UIButton) {
        coffeeTextField.text = ""
        ratioTextField.text = ""
        resultLabel.text = "Result will be shown here"
    }
}
