import UIKit

class coferatio : UIViewController {

    @IBOutlet weak var coffeeTextField: UITextField!
    @IBOutlet weak var waterTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    @IBAction func calculateButtonPressed(_ sender: UIButton) {
        if let coffeeAmount = Double(coffeeTextField.text ?? ""),
           let waterAmount = Double(waterTextField.text ?? "") {
            let coffeeRatio = coffeeAmount / waterAmount
            resultLabel.text = "Coffee Ratio: \(coffeeRatio)"
        } else {
            resultLabel.text = "Invalid input. Please enter valid numbers."
        }
    }

    @IBAction func clearButtonPressed(_ sender: UIButton) {
        coffeeTextField.text = ""
        waterTextField.text = ""
        resultLabel.text = "Result will be shown here"
    }
}
