import UIKit

class Compoundinterest : UIViewController {

    @IBOutlet weak var principalAmountTextField: UITextField!
    @IBOutlet weak var interestRateTextField: UITextField!
    @IBOutlet weak var compoundingFrequencyTextField: UITextField!
    @IBOutlet weak var numberOfYearsTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
      
    }

    @IBAction func calculateButtonPressed(_ sender: UIButton) {
        calculateCompoundInterest()
    }

   
    func calculateCompoundInterest() {
        guard
            let principalAmountText = principalAmountTextField.text, !principalAmountText.isEmpty,
            let interestRateText = interestRateTextField.text, !interestRateText.isEmpty,
            let compoundingFrequencyText = compoundingFrequencyTextField.text, !compoundingFrequencyText.isEmpty,
            let numberOfYearsText = numberOfYearsTextField.text, !numberOfYearsText.isEmpty,
            let principalAmount = Double(principalAmountText),
            let interestRate = Double(interestRateText),
            let compoundingFrequency = Double(compoundingFrequencyText),
            let numberOfYears = Double(numberOfYearsText)
        else {
            resultLabel.text = "All fields are required with valid input"
            return
        }

        if principalAmount < 0 || interestRate < 0 || compoundingFrequency <= 0 || numberOfYears < 0 {
            resultLabel.text = "Invalid input. Please enter valid numerical values."
            return
        }

        let futureValue = calculateFutureValue(principalAmount: principalAmount,
                                               interestRate: interestRate,
                                               compoundingFrequency: compoundingFrequency,
                                               numberOfYears: numberOfYears)

        resultLabel.text = "The future value of your investment is $\(futureValue)"
    }

    func calculateFutureValue(principalAmount: Double, interestRate: Double, compoundingFrequency: Double, numberOfYears: Double) -> Double {
        let n = compoundingFrequency
        let r = interestRate / 100.0 / n
        let nt = n * numberOfYears
        let futureValue = principalAmount * pow(1 + r, nt)
        return futureValue
    }
}
