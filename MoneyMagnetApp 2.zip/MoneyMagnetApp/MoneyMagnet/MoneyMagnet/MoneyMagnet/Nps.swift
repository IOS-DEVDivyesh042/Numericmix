import UIKit

class Nps : UIViewController {

    @IBOutlet weak var principalAmountTextField: UITextField!
    @IBOutlet weak var interestRateTextField: UITextField!
    @IBOutlet weak var tenureTextField: UITextField!

    @IBAction func calculateButtonTapped(_ sender: UIButton) {
        calculateNPSMaturity()
    }

    func calculateNPSMaturity() {
        guard let principalAmountText = principalAmountTextField.text,
              let interestRateText = interestRateTextField.text,
              let tenureText = tenureTextField.text,
              let principalAmount = Double(principalAmountText),
              let interestRate = Double(interestRateText),
              let tenure = Double(tenureText) else {
            showAlert(message: "Please enter valid numbers.")
            return
        }

        let interest = (principalAmount * interestRate * tenure) / (12 * 100)
        let maturityAmount = principalAmount + interest

        showAlert(message: "Your NPS maturity amount is \(maturityAmount)")
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "NPS Maturity Calculation", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
}
