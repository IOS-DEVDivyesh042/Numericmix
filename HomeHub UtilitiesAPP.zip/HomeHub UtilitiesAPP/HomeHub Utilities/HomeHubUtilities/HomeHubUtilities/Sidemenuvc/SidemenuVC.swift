

import UIKit

import StoreKit

class SidemenuVC: UIViewController {

    @IBOutlet weak var tblSidemenu: UITableView!
   
    var arrImg = ["Grocery" , "EUI" , "Wattage", "Dilution","BlindSize","HotTubCost"]
    var arrtlit = ["btnn" , "btnn" , "btnn", "btnn","btnn","btnn"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        

        tblSidemenu.delegate = self
        tblSidemenu.dataSource = self
        
        
        
        tblSidemenu.layer.transform = CATransform3DMakeScale(1.1, 0.1, 0.1)
        UIView.animate(withDuration: 1.0,animations: { [self] in
            tblSidemenu.layer.transform = CATransform3DMakeScale(1.0, 1.0,1.0)
            
        }, completion: nil)
    }
  
}

extension SidemenuVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrImg.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tblSidemenu.dequeueReusableCell(withIdentifier: "sidemenuTblCell", for: indexPath) as! sidemenuTblCell
        cell.lblTitle.text = arrImg[indexPath.row]
        cell.imgarra.image = UIImage(named: arrtlit[indexPath.row])
       
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0{
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "Grocery" ) as! Grocery
            self.navigationController?.pushViewController(vc, animated: true)
        
        }else if indexPath.row == 1{
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "EUI" ) as! EUI
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if indexPath.row == 2{
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "Wattage" ) as! Wattage
            self.navigationController?.pushViewController(vc, animated: true)
           
        }
       else if indexPath.row == 3{
           
           let vc = self.storyboard?.instantiateViewController(withIdentifier: "Dilution" ) as! Dilution
           self.navigationController?.pushViewController(vc, animated: true)
          
           
        }
    else if indexPath.row == 4{

        let vc = self.storyboard?.instantiateViewController(withIdentifier: "BlindSize" ) as! BlindSize
        self.navigationController?.pushViewController(vc, animated: true)
            
        }
        else if indexPath.row == 5 {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "HotTubCost" ) as! HotTubCost
            self.navigationController?.pushViewController(vc, animated: true)

        }
 
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }

}

