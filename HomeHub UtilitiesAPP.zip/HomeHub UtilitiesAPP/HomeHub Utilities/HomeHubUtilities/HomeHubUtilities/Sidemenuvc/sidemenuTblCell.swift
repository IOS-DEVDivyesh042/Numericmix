

import UIKit

class sidemenuTblCell: UITableViewCell {

    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var myview : UIView!
    
    @IBOutlet weak var imgarra: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        lblTitle.layer.borderWidth = 3
        lblTitle.layer.borderColor = UIColor.black.cgColor
        lblTitle.layer.cornerRadius = 5
        
        myview.layer.cornerRadius = 6
        myview.layer.borderWidth = 3
        myview.layer.borderColor = UIColor.black.cgColor
        
        
        imgarra.layer.cornerRadius = 6
        imgarra.layer.borderColor = UIColor.red.cgColor
        imgarra.layer.borderWidth = 3
   
        
    
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
       
    }

}
