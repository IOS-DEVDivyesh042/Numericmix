

import UIKit
import StoreKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func btnabts(_ sender: Any) {
    }
    
    
    @IBAction func btnfeed(_ sender: Any) {
    }
    

    @IBAction func btnshare(_ sender: Any) {
                    if let link = NSURL(string: "https://www.apple.com") {
                            let objectsToShare = ["ElectroShift", link] as [Any]
                            let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
                            self.present(activityVC, animated: true, completion: nil)
                        }

    }
    
    @IBAction func btnpoli(_ sender: Any) {
        let url = URL(string: "https://sites.google.com/view/privacy-policyand-contact/home")
                                   if UIApplication.shared.canOpenURL(url!) {
                                       UIApplication.shared.open(url!, options: [:], completionHandler: nil)
                                       
                                       UIApplication.shared.open(url!, options: [:], completionHandler: { (success) in
                                           print("Open url : \(success)")
                                       })
                                   }
    }
    
    @IBAction func btnterms(_ sender: Any) {
        let url = URL(string: "https://policies.google.com/terms?hl=en-US")
                       if UIApplication.shared.canOpenURL(url!) {
                           UIApplication.shared.open(url!, options: [:], completionHandler: nil)
                           
                           UIApplication.shared.open(url!, options: [:], completionHandler: { (success) in
                               print("Open url : \(success)")
                           })
                       }
        
    }
    
    @IBAction func btnrate(_ sender: Any) {
      
        if #available(iOS 10.3, *) {
              SKStoreReviewController.requestReview()
           } else {
             
          }
        
       
    }
    
    @IBAction func btnhelp(_ sender: Any) {
        let sUrl = "https://sites.google.com/view/ios-applicationcontact/home?authuser=1"
        UIApplication.shared.openURL(NSURL(string: sUrl)! as URL)
        
    }
    
    @IBAction func btnhowto(_ sender: Any) {
        
    }
    
    
    
}

