import UIKit

class Wattage : UIViewController {

    @IBOutlet weak var voltageTextField: UITextField!
    @IBOutlet weak var currentTextField: UITextField!
    @IBOutlet weak var wattageLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func calculateWattage(_ sender: UIButton) {
        guard let voltageText = voltageTextField.text,
              let voltage = Double(voltageText),
              let currentText = currentTextField.text,
              let current = Double(currentText) else {
            wattageLabel.text = "Invalid input"
            return
        }

        let wattage = voltage * current
        wattageLabel.text = String(format: "Wattage: %.2f Watts", wattage)
    }
}
