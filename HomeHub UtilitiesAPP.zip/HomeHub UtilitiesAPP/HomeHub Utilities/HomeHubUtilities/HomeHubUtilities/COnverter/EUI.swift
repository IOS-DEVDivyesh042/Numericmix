import UIKit

class EUI : UIViewController {

    @IBOutlet weak var energyConsumptionTextField: UITextField!
    @IBOutlet weak var floorAreaTextField: UITextField!
    @IBOutlet weak var euiLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func calculateEUI(_ sender: UIButton) {
        guard let energyConsumptionText = energyConsumptionTextField.text,
              let energyConsumption = Double(energyConsumptionText),
              let floorAreaText = floorAreaTextField.text,
              let floorArea = Double(floorAreaText) else {
            euiLabel.text = "Invalid input"
            return
        }

        let eui = energyConsumption / floorArea
        euiLabel.text = String(format: "EUI: %.2f kWh/sqft", eui)
    }
}
