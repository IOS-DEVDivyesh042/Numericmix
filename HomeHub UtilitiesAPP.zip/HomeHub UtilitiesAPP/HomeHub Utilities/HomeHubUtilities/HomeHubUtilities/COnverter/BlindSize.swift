import UIKit

class BlindSize : UIViewController {

    @IBOutlet weak var windowWidthTextField: UITextField!
    @IBOutlet weak var windowHeightTextField: UITextField!
    @IBOutlet weak var allowanceTextField: UITextField!
    @IBOutlet weak var blindSizeLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func calculateBlindSize(_ sender: UIButton) {
        guard let windowWidthText = windowWidthTextField.text,
              let windowWidth = Double(windowWidthText),
              let windowHeightText = windowHeightTextField.text,
              let windowHeight = Double(windowHeightText),
              let allowanceText = allowanceTextField.text,
              let allowance = Double(allowanceText) else {
            blindSizeLabel.text = "Invalid input"
            return
        }

        
        let blindWidth = windowWidth + allowance
        let blindHeight = windowHeight + allowance

        blindSizeLabel.text = String(format: "Blind Size: %.2f x %.2f", blindWidth, blindHeight)
    }
}
