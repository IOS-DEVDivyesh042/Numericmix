import UIKit

class Dilution: UIViewController {

    @IBOutlet weak var initialConcentrationTextField: UITextField!
    @IBOutlet weak var desiredConcentrationTextField: UITextField!
    @IBOutlet weak var volumeTextField: UITextField!
    @IBOutlet weak var dilutionRatioLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func calculateDilutionRatio(_ sender: UIButton) {
        guard let initialConcentrationText = initialConcentrationTextField.text,
              let initialConcentration = Double(initialConcentrationText),
              let desiredConcentrationText = desiredConcentrationTextField.text,
              let desiredConcentration = Double(desiredConcentrationText),
              let volumeText = volumeTextField.text,
              let volume = Double(volumeText) else {
            dilutionRatioLabel.text = "Invalid input"
            return
        }

       
        guard desiredConcentration <= initialConcentration else {
            dilutionRatioLabel.text = "Desired concentration must be <= Initial concentration"
            return
        }

        let dilutionRatio = initialConcentration / desiredConcentration
        let dilutedVolume = volume / dilutionRatio

        dilutionRatioLabel.text = String(format: "Dilution Ratio: 1:%.2f, Diluted Volume: %.2f", dilutionRatio, dilutedVolume)
    }
}
