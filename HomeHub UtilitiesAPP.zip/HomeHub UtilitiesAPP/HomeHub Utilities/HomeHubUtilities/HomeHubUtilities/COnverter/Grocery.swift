import UIKit

class Grocery : UIViewController {

    @IBOutlet weak var itemNameTextField: UITextField!
    @IBOutlet weak var quantityTextField: UITextField!
    @IBOutlet weak var priceTextField: UITextField!
    @IBOutlet weak var totalLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func calculateTotal(_ sender: UIButton) {
        guard let itemName = itemNameTextField.text, !itemName.isEmpty,
              let quantityText = quantityTextField.text, let quantity = Double(quantityText),
              let priceText = priceTextField.text, let price = Double(priceText) else {
            totalLabel.text = "Invalid input"
            return
        }

        let total = quantity * price
        totalLabel.text = "Total for \(itemName): $\(total)"
    }
}
