import UIKit

class HotTubCost : UIViewController {

    @IBOutlet weak var energyConsumptionTextField: UITextField!
    @IBOutlet weak var usageDurationTextField: UITextField!
    @IBOutlet weak var energyCostTextField: UITextField!
    @IBOutlet weak var costLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func calculateHotTubCost(_ sender: UIButton) {
        guard let energyConsumptionText = energyConsumptionTextField.text,
              let energyConsumption = Double(energyConsumptionText),
              let usageDurationText = usageDurationTextField.text,
              let usageDuration = Double(usageDurationText),
              let energyCostText = energyCostTextField.text,
              let energyCost = Double(energyCostText) else {
            costLabel.text = "Invalid input"
            return
        }

       
        let cost = (energyConsumption * usageDuration * energyCost) / 1000
        costLabel.text = String(format: "Cost: $%.2f", cost)
    }
}
