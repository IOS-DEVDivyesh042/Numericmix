


import UIKit

class volume: UIViewController {

    @IBOutlet weak var cubicMeterTextField: UITextField!
    @IBOutlet weak var unitTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    let units = ["Cubic Centimeters", "Cubic Inches", "Cubic Feet", "Cubic Yards", "Liters", "Milliliters", "Gallons"]
    var selectedUnit: String?

    lazy var unitPicker: UIPickerView = {
        let picker = UIPickerView()
        picker.delegate = self
        picker.dataSource = self
        return picker
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        unitTextField.inputView = unitPicker
        createToolbar()
    }

    func createToolbar() {
        let toolbar = UIToolbar()
        toolbar.sizeToFit()

        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(doneButtonTapped))
        toolbar.setItems([doneButton], animated: false)

        unitTextField.inputAccessoryView = toolbar
    }

    @objc func doneButtonTapped() {
        unitTextField.text = selectedUnit
        unitTextField.resignFirstResponder()
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let inputValue = Double(cubicMeterTextField.text ?? ""), let selectedUnit = selectedUnit {
            let result = convertVolume(value: inputValue, to: selectedUnit)
            resultLabel.text = "\(inputValue) cubic meters is \(result) \(selectedUnit)"
        } else {
            resultLabel.text = "Invalid input"
        }
    }

    func convertVolume(value: Double, to unit: String) -> Double {
        switch unit {
        case "Cubic Centimeters":
            return value * 1_000_000
        case "Cubic Inches":
            return value * 61_023.7
        case "Cubic Feet":
            return value * 35.3147
        case "Cubic Yards":
            return value * 1.30795
        case "Liters":
            return value * 1_000
        case "Milliliters":
            return value * 1_000_000
        case "Gallons":
            return value * 264.172
        default:
            return value
        }
    }
}

extension volume : UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return units.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return units[row]
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedUnit = units[row]
    }
}
