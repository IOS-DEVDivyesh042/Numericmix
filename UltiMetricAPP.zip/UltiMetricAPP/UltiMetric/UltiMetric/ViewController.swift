import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var bview: UIView!
    
    @IBOutlet weak var btn1: UIButton!
    
    @IBOutlet weak var btn2: UIButton!
    
    @IBOutlet weak var btn3: UIButton!
    
    
    @IBOutlet weak var btn4: UIButton!
    
    
    @IBOutlet weak var btn5: UIButton!
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        bview.layer.cornerRadius = 20
        bview.layer.borderColor = UIColor.black.cgColor
        bview.layer.borderWidth = 4
        
        
        
        
       
    }


}

