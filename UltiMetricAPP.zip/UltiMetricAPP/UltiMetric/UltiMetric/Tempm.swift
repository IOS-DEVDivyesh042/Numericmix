


import UIKit

class Tempem: UIViewController {

    @IBOutlet weak var celsiusTextField: UITextField!
    @IBOutlet weak var unitTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    let units = ["Celsius", "Fahrenheit", "Kelvin"]
    var selectedUnit: String?

    lazy var unitPicker: UIPickerView = {
        let picker = UIPickerView()
        picker.delegate = self
        picker.dataSource = self
        return picker
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        unitTextField.inputView = unitPicker
        createToolbar()
    }

    func createToolbar() {
        let toolbar = UIToolbar()
        toolbar.sizeToFit()

        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(doneButtonTapped))
        toolbar.setItems([doneButton], animated: false)

        unitTextField.inputAccessoryView = toolbar
    }

    @objc func doneButtonTapped() {
        unitTextField.text = selectedUnit
        unitTextField.resignFirstResponder()
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let inputValue = Double(celsiusTextField.text ?? ""), let selectedUnit = selectedUnit {
            let result = convertTemperature(value: inputValue, to: selectedUnit)
            resultLabel.text = "\(inputValue) degrees Celsius is \(result) \(selectedUnit)"
        } else {
            resultLabel.text = "Invalid input"
        }
    }

    func convertTemperature(value: Double, to unit: String) -> Double {
        switch unit {
        case "Celsius":
            return value
        case "Fahrenheit":
            return (value * 9/5) + 32
        case "Kelvin":
            return value + 273.15
        default:
            return value
        }
    }
}

extension Tempem: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return units.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return units[row]
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedUnit = units[row]
    }
}
