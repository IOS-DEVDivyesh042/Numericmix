

import UIKit

class length : UIViewController {

    

    @IBOutlet weak var meterTextField: UITextField!
    @IBOutlet weak var unitTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    let units = ["Centimeters", "Inches", "Feet", "Yards", "Kilometers"]
    var selectedUnit: String?

    lazy var unitPicker: UIPickerView = {
        let picker = UIPickerView()
        picker.delegate = self
        picker.dataSource = self
        return picker
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        unitTextField.inputView = unitPicker
        createToolbar()
    }

    func createToolbar() {
        let toolbar = UIToolbar()
        toolbar.sizeToFit()

        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(doneButtonTapped))
        toolbar.setItems([doneButton], animated: false)

        unitTextField.inputAccessoryView = toolbar
    }

    @objc func doneButtonTapped() {
        unitTextField.text = selectedUnit
        unitTextField.resignFirstResponder()
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let inputValue = Double(meterTextField.text ?? ""), let selectedUnit = selectedUnit {
            let result = convertLength(value: inputValue, to: selectedUnit)
            resultLabel.text = "\(inputValue) meters is \(result) \(selectedUnit)"
        } else {
            resultLabel.text = "Invalid input"
        }
    }

    func convertLength(value: Double, to unit: String) -> Double {
        switch unit {
        case "Centimeters":
            return value * 100
        case "Inches":
            return value * 39.3701
        case "Feet":
            return value * 3.28084
        case "Yards":
            return value * 1.09361
        case "Kilometers":
            return value / 1000
        default:
            return value
        }
    }
}

extension length : UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return units.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return units[row]
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedUnit = units[row]
    }
}
