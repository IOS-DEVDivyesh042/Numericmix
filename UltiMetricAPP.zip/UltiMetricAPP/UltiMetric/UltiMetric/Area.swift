import UIKit

class Area: UIViewController {

    @IBOutlet weak var squareMeterTextField: UITextField!
    @IBOutlet weak var unitTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    let units = ["Square Centimeters", "Square Inches", "Square Feet", "Square Yards", "Square Kilometers"]
    var selectedUnit: String?

    lazy var unitPicker: UIPickerView = {
        let picker = UIPickerView()
        picker.delegate = self
        picker.dataSource = self
        return picker
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        unitTextField.inputView = unitPicker
        createToolbar()
    }

    func createToolbar() {
        let toolbar = UIToolbar()
        toolbar.sizeToFit()

        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(doneButtonTapped))
        toolbar.setItems([doneButton], animated: false)

        unitTextField.inputAccessoryView = toolbar
    }

    @objc func doneButtonTapped() {
        unitTextField.text = selectedUnit
        unitTextField.resignFirstResponder()
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let inputValue = Double(squareMeterTextField.text ?? ""), let selectedUnit = selectedUnit {
            let result = convertArea(value: inputValue, to: selectedUnit)
            resultLabel.text = "\(inputValue) square meters is \(result) \(selectedUnit)"
        } else {
            resultLabel.text = "Invalid input"
        }
    }

    func convertArea(value: Double, to unit: String) -> Double {
        switch unit {
        case "Square Centimeters":
            return value * 10000
        case "Square Inches":
            return value * 1550.0031
        case "Square Feet":
            return value * 10.7639
        case "Square Yards":
            return value * 1.19599
        case "Square Kilometers":
            return value / 1000000
        default:
            return value
        }
    }
}

extension Area : UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return units.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return units[row]
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedUnit = units[row]
    }
}

