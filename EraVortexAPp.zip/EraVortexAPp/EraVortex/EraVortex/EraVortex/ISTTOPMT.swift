import UIKit

class ISTTOPMT: UIViewController {

    @IBOutlet weak var yearTextField: UITextField!
    @IBOutlet weak var convertedYearLabel: UILabel!

    @IBOutlet weak var timeTextField: UITextField!
    @IBOutlet weak var customTimeLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func calculateYear(_ sender: UIButton) {
        if let yearText = yearTextField.text, let inputYear = Int(yearText) {
            let convertedYear = convertYear(inputYear)
            convertedYearLabel.text = "Converted Year: \(convertedYear)"
        } else {
            convertedYearLabel.text = "Invalid Input"
        }
    }

    @IBAction func clearYear(_ sender: UIButton) {
        yearTextField.text = ""
        convertedYearLabel.text = ""
    }

    @IBAction func calculateISTtoPMT(_ sender: UIButton) {
        if let timeText = timeTextField.text, let istTime = convertTo24HourFormat(timeText) {
            let pmtTime = convertISTtoPMT(istTime)
            customTimeLabel.text = "PMT Time: \(pmtTime)"
        } else {
            customTimeLabel.text = "Invalid Input"
        }
    }

    @IBAction func clearISTtoPMT(_ sender: UIButton) {
        timeTextField.text = ""
        customTimeLabel.text = ""
    }

    func convertYear(_ inputYear: Int) -> Int {
       
        return inputYear + 1
    }

    func convertISTtoPMT(_ istTime: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        dateFormatter.timeZone = TimeZone(identifier: "Asia/Kolkata")

        if let istDate = dateFormatter.date(from: istTime) {
            let pmtTimeZone = TimeZone(secondsFromGMT: -7 * 60 * 60)
            dateFormatter.timeZone = pmtTimeZone
            return dateFormatter.string(from: istDate)
        } else {
            return "Invalid Time"
        }
    }


    func convertTo24HourFormat(_ timeString: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "h:mm a"
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")

        if let date = dateFormatter.date(from: timeString) {
            dateFormatter.dateFormat = "HH:mm"
            return dateFormatter.string(from: date)
        } else {
            return nil
        }
    }
}
