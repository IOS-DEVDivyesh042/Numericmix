import UIKit

class ISTTOEST: UIViewController {

    @IBOutlet weak var yearTextField: UITextField!
    @IBOutlet weak var convertedYearLabel: UILabel!

    @IBOutlet weak var timeTextField: UITextField!
    @IBOutlet weak var estTimeLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
       
    }

    @IBAction func calculateYear(_ sender: UIButton) {
        if let yearText = yearTextField.text, let inputYear = Int(yearText) {
            let convertedYear = convertYear(inputYear)
            convertedYearLabel.text = "Converted Year: \(convertedYear)"
        } else {
            convertedYearLabel.text = "Invalid Input"
        }
    }

    @IBAction func clearYear(_ sender: UIButton) {
        yearTextField.text = ""
        convertedYearLabel.text = ""
    }

    @IBAction func calculateISTtoEST(_ sender: UIButton) {
        if let timeText = timeTextField.text, let istTime = convertTo24HourFormat(timeText) {
            let estTime = convertISTtoEST(istTime)
            estTimeLabel.text = "EST Time: \(estTime)"
        } else {
            estTimeLabel.text = "Invalid Input"
        }
    }

    @IBAction func clearISTtoEST(_ sender: UIButton) {
        timeTextField.text = ""
        estTimeLabel.text = ""
    }

    func convertYear(_ inputYear: Int) -> Int {
       
        return inputYear + 1
    }

    func convertISTtoEST(_ istTime: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        dateFormatter.timeZone = TimeZone(identifier: "Asia/Kolkata")

        if let istDate = dateFormatter.date(from: istTime) {
            dateFormatter.timeZone = TimeZone(identifier: "America/New_York")
            return dateFormatter.string(from: istDate)
        } else {
            return "Invalid Time"
        }
    }

    func convertTo24HourFormat(_ timeString: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "h:mm a"
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")

        if let date = dateFormatter.date(from: timeString) {
            dateFormatter.dateFormat = "HH:mm"
            return dateFormatter.string(from: date)
        } else {
            return nil
        }
    }
}
