import UIKit

class BCTOAD : UIViewController {

    @IBOutlet weak var bcTextField: UITextField!
    @IBOutlet weak var adLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func calculateButtonClicked(_ sender: UIButton) {
        if let bcText = bcTextField.text, let bcYear = Int(bcText) {
            let adYear = convertBCtoAD(bcYear)
            adLabel.text = "AD Year: \(adYear)"
        } else {
            adLabel.text = "Invalid Input"
        }
    }

    @IBAction func clearButtonClicked(_ sender: UIButton) {
        bcTextField.text = ""
        adLabel.text = ""
    }

    func convertBCtoAD(_ bcYear: Int) -> Int {
        
        return bcYear + 1
    }
}
