//
//
//
//import Foundation
//
//struct firstquestion2 {
//
//    var list = [Question]()
//
//    init() {
//
//        list.append(Question(questionText: "What is the main ingredient in a Margherita pizza?", choiceA: "Pepperoni", choiceB: "Tomato Sauce", choiceC: "Cheese", choiceD: "Basil", answer: 4))
//
//        list.append(Question(questionText: "Which type of pizza has pineapple as a topping?", choiceA: "Pepperoni", choiceB: "Hawaiian", choiceC: "Vegetarian", choiceD: "Margherita", answer: 2))
//
//        list.append(Question(questionText: "What is the traditional shape of a pizza?", choiceA: "Square", choiceB: "Triangle", choiceC: "Circle", choiceD: "Rectangle", answer: 3))
//
//        list.append(Question(questionText: "Which country is famous for Neapolitan pizza?", choiceA: "United States", choiceB: "Italy", choiceC: "Greece", choiceD: "France", answer: 2))
//
//        list.append(Question(questionText: "What is the name of the folded pizza with various fillings, popular in Naples?", choiceA: "Calzone", choiceB: "Stromboli", choiceC: "Focaccia", choiceD: "Panzerotti", answer: 1))
//
//        list.append(Question(questionText: "Which cheese is commonly used on a classic New York-style pizza?", choiceA: "Mozzarella", choiceB: "Cheddar", choiceC: "Parmesan", choiceD: "Provolone", answer: 1))
//
//        list.append(Question(questionText: "What is the name of the pizza with seafood toppings, such as shrimp and calamari?", choiceA: "Margherita", choiceB: "Marinara", choiceC: "Frutti di Mare", choiceD: "Quattro Stagioni", answer: 3))
//
//        list.append(Question(questionText: "Which pizza style is known for its deep-dish crust and thick layers of toppings?", choiceA: "Neapolitan", choiceB: "New York", choiceC: "Chicago", choiceD: "Sicilian", answer: 3))
//
//        list.append(Question(questionText: "What is the primary ingredient in pesto sauce used on some pizzas?", choiceA: "Tomatoes", choiceB: "Basil", choiceC: "Olive Oil", choiceD: "Garlic", answer: 2))
//
//        list.append(Question(questionText: "Which pizza chain is known for its Hot-N-Ready pizzas?", choiceA: "Domino's", choiceB: "Papa John's", choiceC: "Little Caesars", choiceD: "Pizza Hut", answer: 3))
//
//        list.append(Question(questionText: "What is the Italian term for a wood-fired pizza oven?", choiceA: "Forno", choiceB: "Ostuni", choiceC: "Pizzeria", choiceD: "Sfornato", answer: 1))
//
//        list.append(Question(questionText: "Which famous pizza city is known for its coal-fired pizza ovens?", choiceA: "Naples", choiceB: "New York", choiceC: "Chicago", choiceD: "New Haven", answer: 4))
//
//        list.append(Question(questionText: "What is the name of the pizza topped with arugula, prosciutto, and shaved Parmesan?", choiceA: "Capricciosa", choiceB: "Quattro Formaggi", choiceC: "Margherita", choiceD: "Prosciutto e Rucola", answer: 4))
//
//        list.append(Question(questionText: "In which century did pizza become popular in Naples, Italy?", choiceA: "15th", choiceB: "17th", choiceC: "19th", choiceD: "21st", answer: 3))
//
//        list.append(Question(questionText: "What is the name of the Italian government's regulation for authentic Neapolitan pizza?", choiceA: "DOC", choiceB: "ISO", choiceC: "PGI", choiceD: "DOP", answer: 4))
//
//    }
//}


import Foundation

struct firstquestion2 {
    
    var list = [Question]()
    
    init() {
        list.append(Question(questionText: "What is the main ingredient in a classic hamburger patty?", choiceA: "Chicken", choiceB: "Beef", choiceC: "Pork", choiceD: "Turkey", answer: 2))
        
        list.append(Question(questionText: "Which cheese is commonly used in a cheeseburger?", choiceA: "Swiss", choiceB: "Cheddar", choiceC: "Mozzarella", choiceD: "Blue", answer: 2))
        
        list.append(Question(questionText: "In what year did the Big Mac burger make its debut at McDonald's?", choiceA: "1955", choiceB: "1967", choiceC: "1971", choiceD: "1980", answer: 3))
        
        list.append(Question(questionText: "What popular burger topping is made from pickled cucumbers?", choiceA: "Ketchup", choiceB: "Mustard", choiceC: "Relish", choiceD: "Mayonnaise", answer: 3))
        
        list.append(Question(questionText: "Which fast-food chain is known for its square-shaped burgers?", choiceA: "McDonald's", choiceB: "Burger King", choiceC: "Wendy's", choiceD: "In-N-Out", answer: 3))
        
        list.append(Question(questionText: "What is the name of the sauce commonly used in a classic Thousand Island Burger?", choiceA: "Barbecue Sauce", choiceB: "Ranch Dressing", choiceC: "Thousand Island", choiceD: "Hot Sauce", answer: 3))
        
        list.append(Question(questionText: "Which type of bun is commonly used for a traditional hamburger?", choiceA: "Sesame Seed", choiceB: "Whole Wheat", choiceC: "Brioche", choiceD: "Pretzel", answer: 1))
        
        list.append(Question(questionText: "What is the name of the vegetarian burger made from black beans?", choiceA: "Beyond Burger", choiceB: "Impossible Burger", choiceC: "Black Bean Burger", choiceD: "Quinoa Burger", answer: 3))
        
        list.append(Question(questionText: "Which burger is known for its spicy kick, featuring jalapenos and pepper jack cheese?", choiceA: "Spicy Chicken Burger", choiceB: "Chili Burger", choiceC: "Buffalo Burger", choiceD: "Spicy Jalapeno Burger", answer: 4))
        
        list.append(Question(questionText: "In-N-Out Burger's secret menu includes a burger called the 'Animal Style.' What does it include?", choiceA: "Extra Cheese", choiceB: "Grilled Onions", choiceC: "Special Sauce", choiceD: "Bacon", answer: 2))
        
        list.append(Question(questionText: "Which burger is often associated with the phrase 'Have it your way'?", choiceA: "McDouble", choiceB: "Whopper", choiceC: "Big Mac", choiceD: "Quarter Pounder", answer: 2))
        
        list.append(Question(questionText: "What is the name of the burger with a black bun, featuring A.1. steak sauce, crispy onions, and Swiss cheese?", choiceA: "Black and Blue Burger", choiceB: "Midnight Moon Burger", choiceC: "Black Truffle Burger", choiceD: "Steakhouse King", answer: 2))
        
        list.append(Question(questionText: "What is the name of the classic burger with only lettuce, tomato, and onion as toppings?", choiceA: "Plain Jane Burger", choiceB: "Veggie Burger", choiceC: "Classic Burger", choiceD: "Three-Topping Burger", answer: 3))
        
        list.append(Question(questionText: "Which burger features a patty made from a blend of beef and pork?", choiceA: "Surf and Turf Burger", choiceB: "Juicy Lucy", choiceC: "Mixed Grill Burger", choiceD: "Bacon-Infused Burger", answer: 2))
        
        list.append(Question(questionText: "What is the name of the burger known for its double beef patties, special sauce, lettuce, cheese, pickles, and onions?", choiceA: "Double Trouble Burger", choiceB: "Classic Double Burger", choiceC: "Double-Stack Burger", choiceD: "Big Mac", answer: 4))
    }
}




