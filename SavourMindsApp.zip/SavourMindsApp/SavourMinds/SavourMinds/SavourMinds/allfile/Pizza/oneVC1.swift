//
//  oneVC1.swift
//  newapp
//
//  Created by sahil on 07/12/23.
//

import UIKit
import AVFoundation
import Foundation

class oneVC1: UIViewController {
    
    var allQuestions = firstquestion1()
    
    var questionNumber : Int = 0
    var score : Int = 0
    var selectedAnswer : Int = 0
    
    var timer : Timer!
    var counter = 0
    var comefrom = "1"
    
    var Comefrome = ""
    var vcTitle = ""
    var id = 0
    
//    @IBOutlet weak var questionnumber: UILabel!
//    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var question: UILabel!

    @IBOutlet weak var option1: UIButton!

    @IBOutlet weak var option2: UIButton!
    
    @IBOutlet weak var option3: UIButton!
    
    @IBOutlet weak var option4: UIButton!
    
    @IBOutlet weak var myview: UIView!
//    @IBOutlet weak var collectionview: UICollectionView!
    
   
    
    var player: AVAudioPlayer?
    
    
//    var imagename = ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20"]
    
     override func viewDidLoad() {
        super.viewDidLoad()
         //btn1.layer.cornerRadius = 20
//         myview.layer.cornerRadius = 20
        
         //updateUI()
         setUpView()
        // Do any additional setup after loading the view.
    }
    
     func playSound(Soundname:String) {
         guard let url = Bundle.main.url(forResource: Soundname, withExtension: "mp3")
             else { return }
       do {
         try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
         try AVAudioSession.sharedInstance().setActive(true)
         player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.wav.rawValue)
         guard let player = player
             else { return }
         player.play()
     }
     catch let error {
         print(error.localizedDescription)
     }
 }


func setUpView(){

        //updateUI()

        updateQuestion()
       // scoreAlert()

        }


    @IBAction func Button(_ sender: UIButton) {
        playSound(Soundname: "Right Answer")

        if sender.tag == selectedAnswer {
         //  speakText(voiceData: "Right")
            sender.backgroundColor = .green
            score += 1
            questionNumber += 1
            DispatchQueue.main.asyncAfter(deadline: .now()+0.5) {
                self.updateQuestion()
            }

            print("------->>>>>mmmmmmmmmmm",score)
        }
        else {
            playSound(Soundname: "Wrong Anwer")
            sender.backgroundColor = .red

            questionNumber += 1
          //  speakText(voiceData: "Wrong")
          //  UIDevice.vibrate()
            DispatchQueue.main.asyncAfter(deadline: .now()+0.5) {
                self.updateQuestion()
            }

        }
    }
       
    @IBAction func nextbutton(_ sender: UIButton) {
        questionNumber += 1
        self.updateQuestion()
    }
    
        
        @IBAction func preButton(_ sender: UIButton) {
            questionNumber -= 1
             self.updateQuestion()
            
        }
        

  
    func updateQuestion(){
        
        if questionNumber <= allQuestions.list.count - 1{
            
           // let wrongColour =  #colorLiteral(red: 232, green: 0.3297867179, blue: 0.520627439, alpha: 1)
             let wrongColour = UIColor(red: 232/255, green: 232/255, blue: 232/255, alpha: 1)
          
            option1.backgroundColor = wrongColour
            option1.layer.cornerRadius = 10;
           
            option2.backgroundColor = wrongColour
            option2.layer.cornerRadius = 10;
            
            option3.backgroundColor = wrongColour
            option3.layer.cornerRadius = 10
           
            option4.backgroundColor = wrongColour
            option4.layer.cornerRadius = 10;
            
//            myview.backgroundColor=UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
//            myview.layer.cornerRadius = 20;

           view.backgroundColor=UIColor(red: 232/255, green: 232/255, blue: 232/255, alpha: 1)
            
            
            //    image.image = UIImage.init(named:allQuestions.list[questionNumber].questionImage)
            
            
            question.text =  allQuestions.list[questionNumber].question
            // clearcolor()
             
                
            option1.setTitle(allQuestions.list[questionNumber].optionA, for:.normal)
            option2.setTitle(allQuestions.list[questionNumber].optionB, for:.normal)
            option3.setTitle(allQuestions.list[questionNumber].optionC, for:.normal)
            option4.setTitle(allQuestions.list[questionNumber].optionD, for:.normal)
            
            
            selectedAnswer = allQuestions.list[questionNumber].correctAnswer
            // updateUI()
              
      }else{
    UserDefaults.standard.set(score, forKey: "Level1")
    let alert = UIAlertController(title: "Know About Country ", message: "End of Quiz", preferredStyle: .alert)
    let restartAction = UIAlertAction(title: "Start Again??", style: .default, handler: {action in self.restartQuiz()})
    let resultaction = UIAlertAction(title: "Result?", style: .default, handler: {action in self.scoreAlert()
       // let SB = UIStoryboard.init(name: "Main", bundle: nil)

//        let VC = SB.instantiateViewController(withIdentifier: "ScoreVC") as!ScoreVC
//              VC.strresult = String(self.score)
//              VC.strquestion = String(self.questionNumber)
//        self.navigationController?.pushViewController(VC, animated: true)
    })
    alert.addAction(restartAction)
    alert.addAction(resultaction)
    present(alert, animated: true, completion: nil)
}
     


  
     
    
}
   


  func updateUI(){
       // scoreLbl.text = "Score: \(score)"
    
   
}



func restartQuiz(){
   score = 0
   questionNumber = 0
   updateQuestion()
   
   
}



func scoreAlert() {
         
               
    let label = UILabel(frame: CGRect(x: 0, y: 0, width: 100, height: 50))
                    label.textColor = .yellow
                        label.text = String(score)
                        
                        let label2 = UILabel(frame: CGRect(x: 0, y: 0, width: 100, height: 50))
                        label2.textColor = .red
                        label2.text = String(questionNumber)
                        
                        let alert = UIAlertController(title: "YOUR SCORE", message: "Your score is \(label.text ?? "") out of \(label2.text ?? "")", preferredStyle: .alert)
                        
                        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: { action in
                            self.restartQuiz()
                        })
                        
                        alert.addAction(cancelAction)
                        present(alert, animated: true, completion: nil)
                        
                    }
    
    }


//extension oneVC : UICollectionViewDelegate,UICollectionViewDataSource{
//    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        return 15
//
//    }
//
//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let cell = collectionview.dequeueReusableCell(withReuseIdentifier: "btncollectioncell", for: indexPath)as!btncollectioncell
//        cell.btn.layer.cornerRadius = 26
//        cell.btn.setImage(UIImage(named: imagename[indexPath.row]), for: .normal)
//        //cell.myimage.layer.cornerRadius = 10
//       //cell.lbl.text = lbldetail[indexPath.row]
//       // cell.lbltitle.text = lbltitle[indexPath.row]
//
//        return cell
//    }
//
//
   
//}
