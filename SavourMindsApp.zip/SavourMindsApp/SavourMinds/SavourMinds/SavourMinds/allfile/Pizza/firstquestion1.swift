


import Foundation

struct firstquestion1 {
    
    var list = [Question]()
    
    init() {
        
        list.append(Question(questionText: "What is the main ingredient in a Margherita pizza?", choiceA: "Pepperoni", choiceB: "Tomato Sauce", choiceC: "Cheese", choiceD: "Basil", answer: 4))
        
        list.append(Question(questionText: "Which type of pizza has pineapple as a topping?", choiceA: "Pepperoni", choiceB: "Hawaiian", choiceC: "Vegetarian", choiceD: "Margherita", answer: 2))
        
        list.append(Question(questionText: "What is the traditional shape of a pizza?", choiceA: "Square", choiceB: "Triangle", choiceC: "Circle", choiceD: "Rectangle", answer: 3))
        
        list.append(Question(questionText: "Which country is famous for Neapolitan pizza?", choiceA: "United States", choiceB: "Italy", choiceC: "Greece", choiceD: "France", answer: 2))
        
        list.append(Question(questionText: "What is the name of the folded pizza with various fillings, popular in Naples?", choiceA: "Calzone", choiceB: "Stromboli", choiceC: "Focaccia", choiceD: "Panzerotti", answer: 1))
        
        list.append(Question(questionText: "Which cheese is commonly used on a classic New York-style pizza?", choiceA: "Mozzarella", choiceB: "Cheddar", choiceC: "Parmesan", choiceD: "Provolone", answer: 1))
        
        list.append(Question(questionText: "What is the name of the pizza with seafood toppings, such as shrimp and calamari?", choiceA: "Margherita", choiceB: "Marinara", choiceC: "Frutti di Mare", choiceD: "Quattro Stagioni", answer: 3))
        
        list.append(Question(questionText: "Which pizza style is known for its deep-dish crust and thick layers of toppings?", choiceA: "Neapolitan", choiceB: "New York", choiceC: "Chicago", choiceD: "Sicilian", answer: 3))
        
        list.append(Question(questionText: "What is the primary ingredient in pesto sauce used on some pizzas?", choiceA: "Tomatoes", choiceB: "Basil", choiceC: "Olive Oil", choiceD: "Garlic", answer: 2))
        
        list.append(Question(questionText: "Which pizza chain is known for its Hot-N-Ready pizzas?", choiceA: "Domino's", choiceB: "Papa John's", choiceC: "Little Caesars", choiceD: "Pizza Hut", answer: 3))
        
        list.append(Question(questionText: "What is the Italian term for a wood-fired pizza oven?", choiceA: "Forno", choiceB: "Ostuni", choiceC: "Pizzeria", choiceD: "Sfornato", answer: 1))
        
        list.append(Question(questionText: "Which famous pizza city is known for its coal-fired pizza ovens?", choiceA: "Naples", choiceB: "New York", choiceC: "Chicago", choiceD: "New Haven", answer: 4))
        
        list.append(Question(questionText: "What is the name of the pizza topped with arugula, prosciutto, and shaved Parmesan?", choiceA: "Capricciosa", choiceB: "Quattro Formaggi", choiceC: "Margherita", choiceD: "Prosciutto e Rucola", answer: 4))
        
        list.append(Question(questionText: "In which century did pizza become popular in Naples, Italy?", choiceA: "15th", choiceB: "17th", choiceC: "19th", choiceD: "21st", answer: 3))
        
        list.append(Question(questionText: "What is the name of the Italian government's regulation for authentic Neapolitan pizza?", choiceA: "DOC", choiceB: "ISO", choiceC: "PGI", choiceD: "DOP", answer: 4))
        
    }
}


