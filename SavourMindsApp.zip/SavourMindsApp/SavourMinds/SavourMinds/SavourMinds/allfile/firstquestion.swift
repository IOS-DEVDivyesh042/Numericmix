

import Foundation

struct firstquestion {
    
    var list = [Question]()
    
    init() {
        list.append(Question(questionText: "What type of bread is commonly used in a classic BLT sandwich?", choiceA: "Whole Wheat", choiceB: "Sourdough", choiceC: "Baguette", choiceD: "White", answer: 2))
        
        list.append(Question(questionText: "Which sandwich is typically made with thinly sliced raw beef or veal?", choiceA: "Turkey Club", choiceB: "Reuben", choiceC: "Philly Cheesesteak", choiceD: "Carpaccio Sandwich", answer: 4))
        
        list.append(Question(questionText: "What is the main protein in a traditional club sandwich?", choiceA: "Chicken", choiceB: "Turkey", choiceC: "Ham", choiceD: "Roast Beef", answer: 2))
        
        list.append(Question(questionText: "Which sandwich is known for its layers of corned beef, sauerkraut, Swiss cheese, and Russian dressing?", choiceA: "Cubano", choiceB: "Monte Cristo", choiceC: "Bánh Mì", choiceD: "Reuben", answer: 4))
        
        list.append(Question(questionText: "What is the main ingredient in a classic peanut butter and jelly sandwich?", choiceA: "Peanut Butter", choiceB: "Almond Butter", choiceC: "Cashew Butter", choiceD: "Hazelnut Butter", answer: 1))
        
        list.append(Question(questionText: "Which sandwich is typically made with grilled cheese, ham, and sometimes turkey?", choiceA: "Tuna Melt", choiceB: "Cuban Sandwich", choiceC: "Croque Monsieur", choiceD: "Club Sandwich", answer: 3))
        
        list.append(Question(questionText: "What type of bread is used in an authentic Italian Caprese sandwich?", choiceA: "Ciabatta", choiceB: "French Baguette", choiceC: "Focaccia", choiceD: "Panini Bread", answer: 1))
        
        list.append(Question(questionText: "What is the name of the sandwich with thinly sliced raw fish, often served in a roll?", choiceA: "BLT", choiceB: "Philly Cheesesteak", choiceC: "Sushi Sandwich", choiceD: "Submarine Sandwich", answer: 3))
        
        list.append(Question(questionText: "Which sandwich is traditionally made with hummus, falafel, and various vegetables?", choiceA: "Gyro", choiceB: "Banh Mi", choiceC: "Falafel Wrap", choiceD: "Pita Pocket", answer: 3))
        
        list.append(Question(questionText: "What is the main protein in a classic French Dip sandwich?", choiceA: "Roast Beef", choiceB: "Chicken", choiceC: "Turkey", choiceD: "Ham", answer: 1))
        
        list.append(Question(questionText: "Which sandwich is commonly made with a filling of tuna mixed with mayonnaise?", choiceA: "Cuban Sandwich", choiceB: "Tuna Melt", choiceC: "Tuna Salad Sandwich", choiceD: "Philly Cheesesteak", answer: 3))
        
        list.append(Question(questionText: "What is the main ingredient in a classic Reuben sandwich?", choiceA: "Turkey", choiceB: "Roast Beef", choiceC: "Corned Beef", choiceD: "Ham", answer: 3))
        
        list.append(Question(questionText: "Which sandwich is known for its layers of salami, ham, mortadella, provolone, and lettuce?", choiceA: "BLT", choiceB: "Club Sandwich", choiceC: "Italian Sub", choiceD: "Croissant Sandwich", answer: 3))
        
        list.append(Question(questionText: "What is the name of the sandwich made with a filling of sliced tomatoes, mozzarella, and fresh basil?", choiceA: "Cuban Sandwich", choiceB: "Caprese Sandwich", choiceC: "Philly Cheesesteak", choiceD: "Bánh Mì", answer: 2))
        
        list.append(Question(questionText: "Which sandwich is made with bacon, lettuce, and tomato?", choiceA: "Turkey Club", choiceB: "Grilled Cheese", choiceC: "BLT", choiceD: "Pulled Pork Sandwich", answer: 3))
    }
}

