import UIKit

class Ageinminutes : UIViewController {

    @IBOutlet weak var ageDatePickermin: UIDatePicker!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

  

    @IBAction func convertToMinutes(_ sender: UIButton) {
        let selectedDate = ageDatePickermin.date
        let ageInMinutes = calculateAgeInMinutes(from: selectedDate)
        resultLabel.text = "Age in Minutes: \(ageInMinutes) minutes"
    }

   
 

    private func calculateAgeInMinutes(from date: Date) -> Int {
        let currentDate = Date()
        let calendar = Calendar.current
        let ageComponents = calendar.dateComponents([.minute], from: date, to: currentDate)
        return ageComponents.minute ?? 0
    }

   

}

