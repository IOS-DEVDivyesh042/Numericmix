import UIKit

class Ageinweek: UIViewController {

    @IBOutlet weak var ageDatePicker: UIDatePicker!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

  
    @IBAction func convertToWeeks(_ sender: UIButton) {
        let selectedDate = ageDatePicker.date
        let ageInWeeks = calculateAgeInWeeks(from: selectedDate)
        resultLabel.text = "Age in Weeks: \(ageInWeeks) weeks"
    }

   

  

    private func calculateAgeInWeeks(from date: Date) -> Int {
        let currentDate = Date()
        let calendar = Calendar.current
        let ageComponents = calendar.dateComponents([.weekOfYear], from: date, to: currentDate)
        return ageComponents.weekOfYear ?? 0
    }

    

}
