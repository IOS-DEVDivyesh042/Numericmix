import UIKit

class Ageinseconds : UIViewController {

    @IBOutlet weak var ageDatePicker: UIDatePicker!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
       
    }

 

    @IBAction func convertToSeconds(_ sender: UIButton) {
        let selectedDate = ageDatePicker.date
        let ageInSeconds = calculateAgeInSeconds(from: selectedDate)
        resultLabel.text = "Age in Seconds: \(ageInSeconds) seconds"
    }


  

    private func calculateAgeInSeconds(from date: Date) -> Int {
        let currentDate = Date()
        let calendar = Calendar.current
        let ageComponents = calendar.dateComponents([.second], from: date, to: currentDate)
        return ageComponents.second ?? 0
    }

 

}
