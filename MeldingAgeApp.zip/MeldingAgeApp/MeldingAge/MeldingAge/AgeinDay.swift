import UIKit

class AgeinDay : UIViewController {

    @IBOutlet weak var ageDatePicker: UIDatePicker!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func convertToDays(_ sender: UIButton) {
        let selectedDate = ageDatePicker.date
        let ageInDays = calculateAgeInDays(from: selectedDate)
        resultLabel.text = "Age in Days: \(ageInDays) days"
    }


    private func calculateAgeInDays(from date: Date) -> Int {
        let currentDate = Date()
        let calendar = Calendar.current
        let ageComponents = calendar.dateComponents([.day], from: date, to: currentDate)
        return ageComponents.day ?? 0
    }

   

}
