import UIKit

class Ageinmonth : UIViewController {

    @IBOutlet weak var ageDatePicker: UIDatePicker!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }


    @IBAction func convertToMonths(_ sender: UIButton) {
        let selectedDate = ageDatePicker.date
        let ageInMonths = calculateAgeInMonths(from: selectedDate)
        resultLabel.text = "Age in Months: \(ageInMonths) months"
    }


    private func calculateAgeInMonths(from date: Date) -> Int {
        let currentDate = Date()
        let calendar = Calendar.current
        let ageComponents = calendar.dateComponents([.month], from: date, to: currentDate)
        return ageComponents.month ?? 0
    }

    

}

