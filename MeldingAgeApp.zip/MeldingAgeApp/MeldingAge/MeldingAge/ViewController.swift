

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var BTN1: UIButton!
    
    @IBOutlet weak var BTN2: UIButton!
    
    @IBOutlet weak var BTN3: UIButton!
    
    
    @IBOutlet weak var BTN4: UIButton!
    
    
    @IBOutlet weak var BTN5: UIButton!
    
    
    @IBOutlet weak var BTN6: UIButton!
    
    
    @IBOutlet weak var VIEW1: UIView!
    
    
    @IBOutlet weak var VIEW2: UIView!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        VIEW1.layer.cornerRadius = 50
        VIEW2.layer.cornerRadius = 50
        
        VIEW1.layer.borderColor = UIColor.black.cgColor
        VIEW1.layer.borderWidth = 5
        
        VIEW2.layer.borderColor = UIColor.black.cgColor
        VIEW2.layer.borderColor = UIColor.black.cgColor
        VIEW2.layer.borderWidth = 5
        
        BTN1.layer.borderColor = UIColor.black.cgColor
        BTN1.layer.borderWidth = 5
        BTN2.layer.borderColor = UIColor.black.cgColor
        BTN2.layer.borderWidth = 5
        BTN3.layer.borderColor = UIColor.black.cgColor
        BTN3.layer.borderWidth = 5
        BTN4.layer.borderColor = UIColor.black.cgColor
        BTN4.layer.borderWidth = 5
        BTN5.layer.borderColor = UIColor.black.cgColor
        BTN5.layer.borderWidth = 5
        BTN6.layer.borderColor = UIColor.black.cgColor
        BTN6.layer.borderWidth = 5
        
        
        BTN2.layer.cornerRadius = 10
        BTN3.layer.cornerRadius = 10
        BTN4.layer.cornerRadius = 10
        BTN5.layer.cornerRadius = 10
        BTN6.layer.cornerRadius = 10
        BTN1.layer.cornerRadius = 10
        
        
    }


}

