import UIKit

class AgeinHour : UIViewController {

    @IBOutlet weak var ageDatePicker: UIDatePicker!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
       
    }



    @IBAction func convertToHours(_ sender: UIButton) {
        let selectedDate = ageDatePicker.date
        let ageInHours = calculateAgeInHours(from: selectedDate)
        resultLabel.text = "Age in Hours: \(ageInHours) hours"
    }



   

    private func calculateAgeInHours(from date: Date) -> Int {
        let currentDate = Date()
        let calendar = Calendar.current
        let ageComponents = calendar.dateComponents([.hour], from: date, to: currentDate)
        return ageComponents.hour ?? 0
    }

   

}
