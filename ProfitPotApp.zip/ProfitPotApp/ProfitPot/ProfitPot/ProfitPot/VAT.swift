
import UIKit

class VAT: UIViewController {
    

    let amountTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter Amount"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .decimalPad
        return textField
    }()
    
    let vatRateTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter VAT Rate (%)"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .decimalPad
        return textField
    }()
    
    let calculateButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Calculate VAT", for: .normal)
        button.titleLabel?.font = UIFont(name: "ArialRoundedMTBold", size: 24)
        button.setTitleColor(.black, for: .normal)
        button.addTarget(self, action: #selector(calculateVAT), for: .touchUpInside)
        return button
    }()
    
    let resultLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    func setupUI() {
        view.backgroundColor = .white
        

        view.addSubview(amountTextField)
        view.addSubview(vatRateTextField)
        view.addSubview(calculateButton)
        view.addSubview(resultLabel)

        amountTextField.translatesAutoresizingMaskIntoConstraints = false
        vatRateTextField.translatesAutoresizingMaskIntoConstraints = false
        calculateButton.translatesAutoresizingMaskIntoConstraints = false
        resultLabel.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            amountTextField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 100),
            amountTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            amountTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            vatRateTextField.topAnchor.constraint(equalTo: amountTextField.bottomAnchor, constant: 10),
            vatRateTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            vatRateTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            calculateButton.topAnchor.constraint(equalTo: vatRateTextField.bottomAnchor, constant: 20),
            calculateButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            resultLabel.topAnchor.constraint(equalTo: calculateButton.bottomAnchor, constant: 20),
            resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
        ])
    }
    
    @objc func calculateVAT() {
        guard let amountText = amountTextField.text, let amount = Double(amountText),
              let vatRateText = vatRateTextField.text, let vatRate = Double(vatRateText) else {
            resultLabel.text = "Invalid input. Please enter valid numbers."
            return
        }
        
      
        let vatAmount = amount * (vatRate / 100)
        
        resultLabel.text = String(format: "VAT Amount: %.2f", vatAmount)
    }
}
