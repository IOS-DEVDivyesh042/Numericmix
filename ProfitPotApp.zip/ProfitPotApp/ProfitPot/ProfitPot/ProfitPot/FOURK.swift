import UIKit

class FOURK : UIViewController {
    

    let contributionTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter Monthly Contribution"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .decimalPad
        return textField
    }()
    
    let interestRateTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter Annual Interest Rate (%)"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .decimalPad
        return textField
    }()
    
    let yearsTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter Number of Years"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .decimalPad
        return textField
    }()
    
    let calculateButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Calculate 401(k)", for: .normal)
        button.titleLabel?.font = UIFont(name: "ArialRoundedMTBold", size: 24)
        button.setTitleColor(.black, for: .normal)
        button.addTarget(self, action: #selector(calculate401k), for: .touchUpInside)
        return button
    }()
    
    let resultLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    func setupUI() {
        view.backgroundColor = .white
        
        
        view.addSubview(contributionTextField)
        view.addSubview(interestRateTextField)
        view.addSubview(yearsTextField)
        view.addSubview(calculateButton)
        view.addSubview(resultLabel)
        
       
        contributionTextField.translatesAutoresizingMaskIntoConstraints = false
        interestRateTextField.translatesAutoresizingMaskIntoConstraints = false
        yearsTextField.translatesAutoresizingMaskIntoConstraints = false
        calculateButton.translatesAutoresizingMaskIntoConstraints = false
        resultLabel.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            contributionTextField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 100),
            contributionTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            contributionTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            interestRateTextField.topAnchor.constraint(equalTo: contributionTextField.bottomAnchor, constant: 10),
            interestRateTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            interestRateTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            yearsTextField.topAnchor.constraint(equalTo: interestRateTextField.bottomAnchor, constant: 10),
            yearsTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            yearsTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            calculateButton.topAnchor.constraint(equalTo: yearsTextField.bottomAnchor, constant: 20),
            calculateButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            resultLabel.topAnchor.constraint(equalTo: calculateButton.bottomAnchor, constant: 20),
            resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
        ])
    }
    
    @objc func calculate401k() {
        guard let contributionText = contributionTextField.text, let contribution = Double(contributionText),
              let interestRateText = interestRateTextField.text, let interestRate = Double(interestRateText),
              let yearsText = yearsTextField.text, let years = Double(yearsText) else {
            resultLabel.text = "Invalid input. Please enter valid numbers."
            return
        }
        
       
        let monthlyInterestRate = interestRate / 1200
        let numberOfMonths = years * 12
        let futureValue = contribution * ((pow(1 + monthlyInterestRate, numberOfMonths) - 1) / monthlyInterestRate) * (1 + monthlyInterestRate)
        
        resultLabel.text = String(format: "401(k) Value: %.2f", futureValue)
    }
}
