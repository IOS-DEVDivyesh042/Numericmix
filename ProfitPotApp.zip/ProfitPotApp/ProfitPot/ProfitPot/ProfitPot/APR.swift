import UIKit

class APR : UIViewController {
    

    let loanAmountTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter Loan Amount"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .decimalPad
        return textField
    }()
    
    let interestRateTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter Annual Interest Rate (%)"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .decimalPad
        return textField
    }()
    
    let loanTermTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter Loan Term (in years)"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .decimalPad
        return textField
    }()
    
    let calculateButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Calculate APR", for: .normal)
        button.titleLabel?.font = UIFont(name: "ArialRoundedMTBold", size: 24)
        button.setTitleColor(.black, for: .normal)
        button.addTarget(self, action: #selector(calculateAPR), for: .touchUpInside)
        return button
    }()
    
    let resultLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    func setupUI() {
            view.backgroundColor = .white

         
            view.addSubview(loanAmountTextField)
            view.addSubview(interestRateTextField)
            view.addSubview(loanTermTextField)
            view.addSubview(calculateButton)
            view.addSubview(resultLabel)

          
            loanAmountTextField.translatesAutoresizingMaskIntoConstraints = false
            interestRateTextField.translatesAutoresizingMaskIntoConstraints = false
            loanTermTextField.translatesAutoresizingMaskIntoConstraints = false
            calculateButton.translatesAutoresizingMaskIntoConstraints = false
            resultLabel.translatesAutoresizingMaskIntoConstraints = false

            NSLayoutConstraint.activate([
               
                loanAmountTextField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 100),
                loanAmountTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
                loanAmountTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

              
                interestRateTextField.topAnchor.constraint(equalTo: loanAmountTextField.bottomAnchor, constant: 40),
                interestRateTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
                interestRateTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

               
                loanTermTextField.topAnchor.constraint(equalTo: interestRateTextField.bottomAnchor, constant: 30),
                loanTermTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
                loanTermTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            
                calculateButton.topAnchor.constraint(equalTo: loanTermTextField.bottomAnchor, constant: 20),
                calculateButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),

                
                resultLabel.topAnchor.constraint(equalTo: calculateButton.bottomAnchor, constant: 10),
                resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
                resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            ])
        }
    
    @objc func calculateAPR() {
        guard let loanAmountText = loanAmountTextField.text, let loanAmount = Double(loanAmountText),
              let interestRateText = interestRateTextField.text, let interestRate = Double(interestRateText),
              let loanTermText = loanTermTextField.text, let loanTerm = Double(loanTermText) else {
            resultLabel.text = "Invalid input. Please enter valid numbers."
            return
        }
        
        let monthlyInterestRate = interestRate / 1200
        let numberOfPayments = loanTerm * 12
        
       
        let monthlyPayment = (loanAmount * monthlyInterestRate) / (1 - pow(1 + monthlyInterestRate, -numberOfPayments))
        

        let totalLoanCost = monthlyPayment * numberOfPayments
        let totalInterestPaid = totalLoanCost - loanAmount
        let apr = (totalInterestPaid / loanAmount) * (12 / loanTerm) * 100
        
        resultLabel.text = String(format: "APR: %.2f%%", apr)
    }
}
