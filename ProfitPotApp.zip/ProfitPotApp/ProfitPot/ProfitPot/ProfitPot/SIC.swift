import UIKit

class SIC : UIViewController {
    
let principalTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter Principal Amount"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .decimalPad
        return textField
    }()
    
    let rateTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter Annual Interest Rate (%)"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .decimalPad
        return textField
    }()
    
    let timeTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter Time Period (in years)"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .decimalPad
        return textField
    }()
    
    let calculateButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Calculate Simple Interest", for: .normal)
        button.titleLabel?.font = UIFont(name: "ArialRoundedMTBold", size: 24)
        button.setTitleColor(.black, for: .normal)
        button.addTarget(self, action: #selector(calculateSimpleInterest), for: .touchUpInside)
        return button
    }()
    
    let resultLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    func setupUI() {
        view.backgroundColor = .white
        
     
        view.addSubview(principalTextField)
        view.addSubview(rateTextField)
        view.addSubview(timeTextField)
        view.addSubview(calculateButton)
        view.addSubview(resultLabel)
        
   
        principalTextField.translatesAutoresizingMaskIntoConstraints = false
        rateTextField.translatesAutoresizingMaskIntoConstraints = false
        timeTextField.translatesAutoresizingMaskIntoConstraints = false
        calculateButton.translatesAutoresizingMaskIntoConstraints = false
        resultLabel.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            principalTextField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 100),
            principalTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            principalTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            rateTextField.topAnchor.constraint(equalTo: principalTextField.bottomAnchor, constant: 10),
            rateTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            rateTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            timeTextField.topAnchor.constraint(equalTo: rateTextField.bottomAnchor, constant: 10),
            timeTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            timeTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            calculateButton.topAnchor.constraint(equalTo: timeTextField.bottomAnchor, constant: 20),
            calculateButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            resultLabel.topAnchor.constraint(equalTo: calculateButton.bottomAnchor, constant: 20),
            resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
        ])
    }
    
    @objc func calculateSimpleInterest() {
        guard let principalText = principalTextField.text, let principal = Double(principalText),
              let rateText = rateTextField.text, let rate = Double(rateText),
              let timeText = timeTextField.text, let time = Double(timeText) else {
            resultLabel.text = "Invalid input. Please enter valid numbers."
            return
        }
        
       
        let interest = (principal * rate * time) / 100
        
        resultLabel.text = String(format: "Simple Interest: %.2f", interest)
    }
}
