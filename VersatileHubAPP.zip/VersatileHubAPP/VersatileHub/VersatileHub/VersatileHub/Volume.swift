//
//  Volume.swift
//  VersatileHub
//
//  Created by Manish Bhanushali on 10/11/23.
//

import UIKit

class Volume : UIViewController {
    @IBOutlet var inputTextField: UITextField!
    @IBOutlet var sourceUnitPicker: UIPickerView!
    @IBOutlet var targetUnitPicker: UIPickerView!
    @IBOutlet var convertedResultLabel: UILabel!

    let volumeUnits = ["Liters", "Milliliters", "Gallons", "Cubic Inches"]
    let conversionFactors: [[Double]] = [
        [1.0, 1000.0, 0.264172, 61.0237], // Liters
        [0.001, 1.0, 0.000264172, 0.0610237], // Milliliters
        [3.78541, 3785.41, 1.0, 231.0], // Gallons
        [0.0163871, 16.3871, 0.004329, 1.0] // Cubic Inches
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        sourceUnitPicker.dataSource = self
        sourceUnitPicker.delegate = self
        targetUnitPicker.dataSource = self
        targetUnitPicker.delegate = self
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let inputText = inputTextField.text, let inputValue = Double(inputText) {
            let sourceUnitIndex = sourceUnitPicker.selectedRow(inComponent: 0)
            let targetUnitIndex = targetUnitPicker.selectedRow(inComponent: 0)

            let conversionFactor = conversionFactors[sourceUnitIndex][targetUnitIndex]
            let resultValue = inputValue * conversionFactor

            convertedResultLabel.text = "\(inputValue) \(volumeUnits[sourceUnitIndex]) = \(resultValue) \(volumeUnits[targetUnitIndex])"
        } else {
            convertedResultLabel.text = "Invalid input"
        }
    }
}

extension Volume: UIPickerViewDataSource, UIPickerViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return volumeUnits.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return volumeUnits[row]
    }
}
