//
//  TimeZone.swift
//  VersatileHub
//
//  Created by Manish Bhanushali on 10/11/23.
//

import UIKit

class TimeZone: UIViewController {
    @IBOutlet var datePicker: UIDatePicker!
    @IBOutlet var timezonePicker: UIPickerView!
    @IBOutlet var convertedTimeLabel: UILabel!

        // let timezones = TimeZone.knownTimeZoneIdentifiers.sorted()
   // let timezones = TimeZone.knownTimeZoneIdentifiers

    let timezones = NSTimeZone.knownTimeZoneNames

    override func viewDidLoad() {
        super.viewDidLoad()
        timezonePicker.dataSource = self
        timezonePicker.delegate = self
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        let selectedDate = datePicker.date
        let selectedTimezone = timezones[timezonePicker.selectedRow(inComponent: 0)]

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatter.timeZone = Foundation.TimeZone(identifier: selectedTimezone)

            //  dateFormatter.timeZone = TimeZone(coder: selectedTimezone)
      //  dateFormatter.timeZone = TimeZone(identifier: selectedTimezone)

        let convertedTime = dateFormatter.string(from: selectedDate)
        convertedTimeLabel.text = "Converted Time: \(convertedTime)"
    }
}

extension TimeZone: UIPickerViewDataSource, UIPickerViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return timezones.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return timezones[row]
    }
}
