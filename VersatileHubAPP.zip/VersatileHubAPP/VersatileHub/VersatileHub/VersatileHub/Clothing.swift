//
//  Clothing.swift
//  VersatileHub
//
//  Created by Manish Bhanushali on 10/11/23.
//

import UIKit

class Clothing : UIViewController {
    @IBOutlet var inputTextField: UITextField!
    @IBOutlet var sourceSizePicker: UIPickerView!
    @IBOutlet var targetSizePicker: UIPickerView!
    @IBOutlet var convertedResultLabel: UILabel!

    let sizeStandards = ["US", "EU", "UK"]
    let conversionFactors: [[String: Double]] = [
        ["US": 1.0, "EU": 0.88, "UK": 0.75], // US
        ["US": 1.14, "EU": 1.0, "UK": 0.85], // EU
        ["US": 1.33, "EU": 1.18, "UK": 1.0]  // UK
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        sourceSizePicker.dataSource = self
        sourceSizePicker.delegate = self
        targetSizePicker.dataSource = self
        targetSizePicker.delegate = self
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let inputText = inputTextField.text, let inputValue = Double(inputText) {
            let sourceSizeIndex = sourceSizePicker.selectedRow(inComponent: 0)
            let targetSizeIndex = targetSizePicker.selectedRow(inComponent: 0)

            let sourceSizeStandard = sizeStandards[sourceSizeIndex]
            let targetSizeStandard = sizeStandards[targetSizeIndex]

            if let conversionFactor = conversionFactors[sourceSizeIndex][targetSizeStandard] {
                let resultValue = inputValue * conversionFactor
                convertedResultLabel.text = "\(inputValue) \(sourceSizeStandard) = \(resultValue) \(targetSizeStandard)"
            } else {
                convertedResultLabel.text = "Invalid conversion factor"
            }
        } else {
            convertedResultLabel.text = "Invalid input"
        }
    }
}

extension Clothing : UIPickerViewDataSource, UIPickerViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return sizeStandards.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return sizeStandards[row]
    }
}
