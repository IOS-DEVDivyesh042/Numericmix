//
//  ViewController.swift
//  VersatileHub
//
//  Created by Manish Bhanushali on 10/11/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var btntime: UIButton!
    
    @IBOutlet weak var btnvolu: UIButton!
    
    @IBOutlet weak var btnener: UIButton!
    
    @IBOutlet weak var btnclot: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        btntime.layer.cornerRadius = 20
        btnclot.layer.cornerRadius = 20
        btnener.layer.cornerRadius = 20
        btnvolu.layer.cornerRadius = 20
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func timezo(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "TimeZone")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    @IBAction func volum(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Volume")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    @IBAction func clothin(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Clothing")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    @IBAction func energ(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Energy")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    


}

