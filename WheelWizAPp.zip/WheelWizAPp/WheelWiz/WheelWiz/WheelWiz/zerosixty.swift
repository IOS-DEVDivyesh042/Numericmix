import UIKit

class zerosixty: UIViewController {

    var startTime: Date?

    let startButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Start Acceleration", for: .normal)
        button.addTarget(self, action: #selector(startButtonTapped), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.white, for: .normal)
        return button
    }()

    let endButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("End Acceleration", for: .normal)
        button.addTarget(self, action: #selector(endButtonTapped), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.isEnabled = false
        button.layer.backgroundColor = UIColor.black.cgColor
        button.setTitleColor(.white, for: .normal)
        return button
    }()

    let resultLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.text = "0-60 mph Time: N/A seconds"
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    override func loadView() {
        super.loadView()

        view.backgroundColor = .white

        view.addSubview(startButton)
        view.addSubview(endButton)
        view.addSubview(resultLabel)

        NSLayoutConstraint.activate([
            startButton.topAnchor.constraint(equalTo: view.topAnchor, constant: 100),
                       startButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 50),
                       startButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -50),
                       startButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),

                       endButton.topAnchor.constraint(equalTo: startButton.bottomAnchor, constant: 20),
                       endButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 50),
                       endButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -50),
                       endButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),


            resultLabel.topAnchor.constraint(equalTo: endButton.bottomAnchor, constant: 20),
            resultLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        ])
    }

    @objc func startButtonTapped() {
        startTime = Date()
        startButton.isEnabled = false
        endButton.isEnabled = true
        resultLabel.text = "0-60 mph Time: N/A seconds"
    }

    @objc func endButtonTapped() {
        guard let startTime = startTime else {
            
            return
        }

        let endTime = Date()
        let timeInterval = endTime.timeIntervalSince(startTime)
        let timeInSeconds = round(timeInterval * 10) / 10.0 

        resultLabel.text = "0-60 mph Time: \(timeInSeconds) seconds"

       
        startButton.isEnabled = true
        endButton.isEnabled = false
        self.startTime = nil
    }
}
