import UIKit

class TireSize: UIViewController {

    let metricTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter Tire Size (e.g., 205/55R16)"
        textField.borderStyle = .roundedRect
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }()

    let convertButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Convert", for: .normal)
        button.addTarget(self, action: #selector(convertButtonTapped), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.layer.backgroundColor = UIColor.black.cgColor
        button.setTitleColor(.white, for: .normal)
        return button
    }()

    let resultLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.text = "Converted Size: "
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    override func loadView() {
        super.loadView()

        view.backgroundColor = .white

        view.addSubview(metricTextField)
        view.addSubview(convertButton)
        view.addSubview(resultLabel)

        NSLayoutConstraint.activate([
            metricTextField.topAnchor.constraint(equalTo: view.topAnchor, constant: 100),
            metricTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            metricTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            convertButton.topAnchor.constraint(equalTo: metricTextField.bottomAnchor, constant: 20),
            convertButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 50),
            convertButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -50),

            resultLabel.topAnchor.constraint(equalTo: convertButton.bottomAnchor, constant: 20),
            resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
        ])
    }

    @objc func convertButtonTapped() {
        guard let metricSize = metricTextField.text else {
   
            resultLabel.text = "Invalid input"
            return
        }

        let convertedSize = convertTireSize(metricSize: metricSize)
        resultLabel.text = "Converted Size: \(convertedSize) inches"
    }

    func convertTireSize(metricSize: String) -> Double? {
        let components = metricSize.components(separatedBy: "/")

        guard components.count == 3,
              let sectionWidth = Double(components[0]),
              let aspectRatio = Double(components[1]),
              let rimDiameter = Double(components[2].dropLast()) else {
            
            return nil
        }

       
        let convertedSize = (sectionWidth * (aspectRatio / 100.0) * 2 + rimDiameter * 25.4) / 25.4
        return convertedSize
    }
}
