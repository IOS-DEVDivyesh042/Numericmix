import UIKit

class Speed: UIViewController {

    let wheelRPMTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Wheel RPM"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .numberPad
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }()

    let tireDiameterTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Tire Diameter (inches)"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .decimalPad
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }()

    let calculateButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Calculate Speed", for: .normal)
        button.addTarget(self, action: #selector(calculateButtonTapped), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.layer.backgroundColor = UIColor.black.cgColor
        button.setTitleColor(.white, for: .normal)
        return button
    }()

    let resultLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.text = "Speed: 0.00 mph"
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    override func loadView() {
        super.loadView()

        view.backgroundColor = .white

        view.addSubview(wheelRPMTextField)
        view.addSubview(tireDiameterTextField)
        view.addSubview(calculateButton)
        view.addSubview(resultLabel)

        NSLayoutConstraint.activate([
            wheelRPMTextField.topAnchor.constraint(equalTo: view.topAnchor, constant: 100),
            wheelRPMTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            wheelRPMTextField.widthAnchor.constraint(equalToConstant: 120),

            tireDiameterTextField.topAnchor.constraint(equalTo: wheelRPMTextField.topAnchor),
            tireDiameterTextField.leadingAnchor.constraint(equalTo: wheelRPMTextField.trailingAnchor, constant: 20),
            tireDiameterTextField.widthAnchor.constraint(equalToConstant: 120),

            calculateButton.topAnchor.constraint(equalTo:  tireDiameterTextField.bottomAnchor, constant: 20),
                    calculateButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 50), 
                    calculateButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -50),
            
            resultLabel.topAnchor.constraint(equalTo: calculateButton.bottomAnchor, constant: 20),
            resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
        ])
    }

    @objc func calculateButtonTapped() {
        guard let wheelRPMText = wheelRPMTextField.text,
              let tireDiameterText = tireDiameterTextField.text,
              let wheelRPM = Double(wheelRPMText),
              let tireDiameter = Double(tireDiameterText) else {
        
            resultLabel.text = "Invalid input"
            return
        }

        let speed = calculateSpeed(wheelRPM: wheelRPM, tireDiameter: tireDiameter)
        resultLabel.text = String(format: "Speed: %.2f mph", speed)
    }

    func calculateSpeed(wheelRPM: Double, tireDiameter: Double) -> Double {
        let speed = (wheelRPM * tireDiameter * Double.pi) / (12 * 5280) * 60
        return speed
    }
}
