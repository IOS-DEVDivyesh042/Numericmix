import UIKit

class CarChargingCost: UIViewController {

    let hoursTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Hours"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .numberPad
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }()

    let minutesTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Minutes"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .numberPad
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }()

    let chargingRateTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Charging Rate"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .decimalPad
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }()

    let calculateButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Calculate", for: .normal)
        button.addTarget(self, action: #selector(calculateButtonTapped), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.layer.backgroundColor = UIColor.black.cgColor
        button.setTitleColor(.white, for: .normal)
        return button
    }()

    let resultLabel: UILabel = {
        let label = UILabel()
        label.text = "Charging cost: $0.00"
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    override func loadView() {
        super.loadView()

        view.backgroundColor = .white

        view.addSubview(hoursTextField)
        view.addSubview(minutesTextField)
        view.addSubview(chargingRateTextField)
        view.addSubview(calculateButton)
        view.addSubview(resultLabel)

        NSLayoutConstraint.activate([
            hoursTextField.topAnchor.constraint(equalTo: view.topAnchor, constant: 100),
            hoursTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            hoursTextField.widthAnchor.constraint(equalToConstant: 120),

            minutesTextField.topAnchor.constraint(equalTo: hoursTextField.topAnchor),
            minutesTextField.leadingAnchor.constraint(equalTo: hoursTextField.trailingAnchor, constant: 20),
            minutesTextField.widthAnchor.constraint(equalToConstant: 120),

            chargingRateTextField.topAnchor.constraint(equalTo: hoursTextField.bottomAnchor, constant: 20),
            chargingRateTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            chargingRateTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            calculateButton.topAnchor.constraint(equalTo: chargingRateTextField.bottomAnchor, constant: 20),
                    calculateButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 50), 
                    calculateButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -50),

            resultLabel.topAnchor.constraint(equalTo: calculateButton.bottomAnchor, constant: 20),
            resultLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        ])
    }

    @objc func calculateButtonTapped() {
        guard let hoursText = hoursTextField.text, let minutesText = minutesTextField.text, let chargingRateText = chargingRateTextField.text,
              let hours = Double(hoursText), let minutes = Double(minutesText), let chargingRate = Double(chargingRateText) else {
           
            resultLabel.text = "Invalid input"
            return
        }

        let totalTime = hours + minutes / 60.0
        let cost = calculateChargingCost(chargingTime: totalTime, chargingRate: chargingRate)
        resultLabel.text = String(format: "Charging cost: $%.2f", cost)
    }

    func calculateChargingCost(chargingTime: Double, chargingRate: Double) -> Double {
        return chargingTime * chargingRate
    }
}
