//
//  ViewController.swift
//  UnitHub
//
//  Created by Manish Bhanushali on 04/11/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var view1: UIView!
    
    @IBOutlet weak var view2: UIView!
    
    @IBOutlet weak var view3: UIView!
    
    
    @IBOutlet weak var view4: UIView!
    
    @IBOutlet weak var view5: UIView!
    
    
    @IBOutlet weak var btn1: UIButton!
    
    
    @IBOutlet weak var btn2: UIButton!
    
    
    @IBOutlet weak var btn3: UIButton!
    
    @IBOutlet weak var btn4: UIButton!
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        view1.layer.cornerRadius = 5
        view1.layer.borderColor = UIColor.white.cgColor
        view1.layer.borderWidth = 3
        
        
        view2.layer.cornerRadius = 5
        view2.layer.borderColor = UIColor.black.cgColor
        view2.layer.borderWidth = 3
        
        
        
        view3.layer.cornerRadius = 5
        view3.layer.borderColor = UIColor.purple.cgColor
        view3.layer.borderWidth = 3
        
        
        view4.layer.cornerRadius = 5
        view4.layer.borderColor = UIColor.orange.cgColor
        view4.layer.borderWidth = 3
        
        view5.layer.cornerRadius = 5
        view5.layer.borderColor = UIColor.orange.cgColor
        view5.layer.borderWidth = 3
        
        btn1.layer.cornerRadius = 20
        btn2.layer.cornerRadius = 20
        btn3.layer.cornerRadius = 20
        btn4.layer.cornerRadius = 20
        
        
        
    }

    
    @IBAction func areacir(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "AreaofCircle")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    @IBAction func feet(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "feetvc")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    @IBAction func areatri(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Areaoftriangle")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    @IBAction func disbtn(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Distance")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    
    
}

