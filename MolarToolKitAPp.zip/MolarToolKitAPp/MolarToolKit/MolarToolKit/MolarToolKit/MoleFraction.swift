import UIKit

class MoleFraction : UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    @IBOutlet weak var molesATextField: UITextField!
    @IBOutlet weak var molesBTextField: UITextField!
    @IBOutlet weak var totalMolesTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var pickerView: UIPickerView!

    let units = ["Grams", "Ounces", "Atoms", "Molecules", "Liters", "Molarity", "Mole Fraction A", "Mole Fraction B"]

    override func viewDidLoad() {
        super.viewDidLoad()
        pickerView.dataSource = self
        pickerView.delegate = self
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let molesAText = molesATextField.text, let molesA = Double(molesAText),
           let molesBText = molesBTextField.text, let molesB = Double(molesBText),
           let totalMolesText = totalMolesTextField.text, let totalMoles = Double(totalMolesText) {

            let selectedUnit = units[pickerView.selectedRow(inComponent: 0)]
            let convertedValue: Double

            switch selectedUnit {
            case "Mole Fraction A":
                convertedValue = calculateMoleFraction(molesA: molesA, totalMoles: totalMoles)
            case "Mole Fraction B":
                convertedValue = calculateMoleFraction(molesA: molesB, totalMoles: totalMoles)
            case "Molarity":
                convertedValue = calculateMolarity(moles: molesA + molesB, volume: totalMoles)
            default:
                convertedValue = convertMoles(moles: molesA, toUnit: selectedUnit)
            }

            resultLabel.text = "\(convertedValue) \(selectedUnit)"
        } else {
           
            resultLabel.text = "Invalid input"
        }
    }

    func convertMoles(moles: Double, toUnit unit: String) -> Double {
        switch unit {
        case "Grams":
            return moles * 6.022 * pow(10, 23)
        case "Ounces":
            return moles * 0.03527396
        case "Atoms":
            return moles * 6.022 * pow(10, 23)
        case "Molecules":
            return moles * 6.022 * pow(10, 23)
        case "Liters":
            return moles * 22.414
        default:
            return 0.0
        }
    }

    func calculateMolarity(moles: Double, volume: Double) -> Double {
        return moles / volume
    }

    func calculateMoleFraction(molesA: Double, totalMoles: Double) -> Double {
        return molesA / totalMoles
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return units.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return units[row]
    }
}
