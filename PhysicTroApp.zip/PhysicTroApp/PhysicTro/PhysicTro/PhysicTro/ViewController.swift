//
//  ViewController.swift
//  PhysicTro
//
//  Created by Manish Bhanushali on 08/11/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var view1: UIView!
    
    @IBOutlet weak var view11: UIView!
    
    @IBOutlet weak var view2: UIView!
    
    @IBOutlet weak var view22: UIView!
    
    @IBOutlet weak var view3: UIView!
    
    @IBOutlet weak var view33: UIView!
    
    @IBOutlet weak var view4: UIView!
    
    @IBOutlet weak var view44: UIView!
    
    
    @IBOutlet weak var btn1: UIButton!
    
    
    @IBOutlet weak var btn2: UIButton!
    
    
    
    @IBOutlet weak var btn3: UIButton!
    
    
    @IBOutlet weak var btn4: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view1.layer.cornerRadius = 15
        view1.layer.borderColor = UIColor.black.cgColor
        view1.layer.borderWidth = 4
        view11.layer.cornerRadius = 15
        view11.layer.borderColor = UIColor.purple.cgColor
        view11.layer.borderWidth = 4
        
        view2.layer.cornerRadius = 15
        view2.layer.borderColor = UIColor.black.cgColor
        view2.layer.borderWidth = 4
        
        view22.layer.cornerRadius = 15
        view22.layer.borderColor = UIColor.purple.cgColor
        view22.layer.borderWidth = 4
        
        view3.layer.cornerRadius = 15
        view3.layer.borderColor = UIColor.black.cgColor
        view3.layer.borderWidth = 4
        
        view33.layer.cornerRadius = 15
        view33.layer.borderColor = UIColor.purple.cgColor
        view33.layer.borderWidth = 4
        
        view4.layer.cornerRadius = 15
        view4.layer.borderColor = UIColor.black.cgColor
        view4.layer.borderWidth = 4
        
        view44.layer.cornerRadius = 15
        view44.layer.borderColor = UIColor.purple.cgColor
        view44.layer.borderWidth = 4
        
        btn1.layer.cornerRadius = 15
        btn1.layer.borderWidth = 4
        btn1.layer.borderColor = UIColor.white.cgColor
        
        btn2.layer.cornerRadius = 15
        btn2.layer.borderWidth = 4
        btn2.layer.borderColor = UIColor.white.cgColor
        
        btn3.layer.cornerRadius = 15
        btn3.layer.borderWidth = 4
        btn3.layer.borderColor = UIColor.white.cgColor
        
        btn4.layer.cornerRadius = 15
        btn4.layer.borderWidth = 4
        btn4.layer.borderColor = UIColor.white.cgColor
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
    
    @IBAction func btnLCD(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "LinearChargeDensity")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    @IBAction func btnEC(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "ElectrostaticCapacitance")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    @IBAction func btnVCD(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "VolumeChargeDensity")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    @IBAction func btnSCD(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "SurfaceChargeDensity")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    
    
    
    
    
    
    
    
    
    
    


}

