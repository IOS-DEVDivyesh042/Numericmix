//
//  SurfaceChargeDensity.swift
//  PhysicTro
//
//  Created by Manish Bhanushali on 08/11/23.
//

import UIKit

class SurfaceChargeDensity: UIViewController {
    @IBOutlet weak var fromUnitSegmentedControl: UISegmentedControl!
    @IBOutlet weak var toUnitSegmentedControl: UISegmentedControl!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var inputTextField: UITextField!
    
    let units = ["C/m²", "μC/cm²", "nC/mm²", "mA/in²", "Fr/ft²"]
    let conversionFactors: [Double] = [1.0, 1.0e-4, 1.0e-6, 6.4516e-4, 3.3356e-11]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fromUnitSegmentedControl.removeAllSegments()
        toUnitSegmentedControl.removeAllSegments()
        
        for unit in units {
            fromUnitSegmentedControl.insertSegment(withTitle: unit, at: fromUnitSegmentedControl.numberOfSegments, animated: false)
            toUnitSegmentedControl.insertSegment(withTitle: unit, at: toUnitSegmentedControl.numberOfSegments, animated: false)
        }
        
        // Set up initial state and actions for the segmented controls.
        fromUnitSegmentedControl.selectedSegmentIndex = 0
        toUnitSegmentedControl.selectedSegmentIndex = 1
        fromUnitSegmentedControl.addTarget(self, action: #selector(segmentedControlValueChanged(_:)), for: .valueChanged)
        toUnitSegmentedControl.addTarget(self, action: #selector(segmentedControlValueChanged(_:)), for: .valueChanged)
    }

    @objc func segmentedControlValueChanged(_ sender: UISegmentedControl) {
        // Implement the conversion logic when the segmented controls change.
        // Update the resultLabel with the converted value.
        let convertedValue = convertSurfaceChargeDensity()
        resultLabel.text = String(format: "%.6f", convertedValue)
    }

    func convertSurfaceChargeDensity() -> Double {
        // Get the selected units from the segmented controls.
        let fromUnitIndex = fromUnitSegmentedControl.selectedSegmentIndex
        let toUnitIndex = toUnitSegmentedControl.selectedSegmentIndex
        
        // Get the conversion factor for the selected units.
        let conversionFactor = conversionFactors[fromUnitIndex] / conversionFactors[toUnitIndex]
        
        // Convert the input value to the selected units.
        if let inputValue = Double(inputTextField.text ?? "") {
            return inputValue * conversionFactor
        }
        
        // Return 0.0 if the input is not a valid number.
        return 0.0
    }
}
