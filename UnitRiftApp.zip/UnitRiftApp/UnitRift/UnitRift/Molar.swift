import UIKit

class Molar : UIViewController {

    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var resultLabel: UILabel!

    let molarMassFactors: [Double] = [2.0, 32.0, 12.0, 28.0, 23.0, 256.0]
    let unitNames = ["(H2)", "(O2)", "(C)", "(N2)", "(Na)", "(S8)"]

    override func viewDidLoad() {
        super.viewDidLoad()
        setupSegmentedControl()
    }

    func setupSegmentedControl() {
        for (index, unit) in unitNames.enumerated() {
            segmentedControl.setTitle(unit, forSegmentAt: index)
        }
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let inputValue = Double(inputTextField.text ?? "") {
            let selectedUnitIndex = segmentedControl.selectedSegmentIndex

            if selectedUnitIndex != UISegmentedControl.noSegment {
                let conversionFactor = molarMassFactors[selectedUnitIndex]
                let result = inputValue * conversionFactor
                resultLabel.text = "Result for \(unitNames[selectedUnitIndex]): \(result) g/mol"
            } else {
               
                resultLabel.text = "Please select a unit."
            }
        } else {
            
            resultLabel.text = "Please enter a valid number."
        }
    }
}
