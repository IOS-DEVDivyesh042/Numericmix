import UIKit

class Atomic : UIViewController {

    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var resultLabel: UILabel!


    let atomicMassUnitFactors: [Double] = [1.0, 1e-3, 1e-6]
    let unitNames = ["(AMU)", "(kg)", "(g)"]

    override func viewDidLoad() {
        super.viewDidLoad()
        setupSegmentedControl()
    }

    func setupSegmentedControl() {
        for (index, unit) in unitNames.enumerated() {
            segmentedControl.setTitle(unit, forSegmentAt: index)
        }
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
    if let inputValue = Double(inputTextField.text ?? "") {
            let selectedUnitIndex = segmentedControl.selectedSegmentIndex

            if selectedUnitIndex != UISegmentedControl.noSegment {
                let result = inputValue * atomicMassUnitFactors[selectedUnitIndex]
                resultLabel.text = "Result for \(unitNames[selectedUnitIndex]): \(result)"
            } else {
                // Handle the case when no segment is selected
                resultLabel.text = "Please select a unit."
            }
        } else {
            // Handle the case when the input value is not a valid number
            resultLabel.text = "Please enter a valid number."
        }
    }
}
