import UIKit

class Concentration : UIViewController {

    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var resultLabel: UILabel!

    let concentrationFactors: [Double] = [1.0, 0.01, 0.001]
    let unitNames = ["(M)", "PC(%)", "(mM)"]

    override func viewDidLoad() {
        super.viewDidLoad()
        setupSegmentedControl()
    }

    func setupSegmentedControl() {
        for (index, unit) in unitNames.enumerated() {
            segmentedControl.setTitle(unit, forSegmentAt: index)
        }
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let inputValue = Double(inputTextField.text ?? "") {
            let selectedUnitIndex = segmentedControl.selectedSegmentIndex

            if selectedUnitIndex != UISegmentedControl.noSegment {
                let result = inputValue * concentrationFactors[selectedUnitIndex]
                resultLabel.text = "Result for \(unitNames[selectedUnitIndex]): \(result)"
            } else {
                
                resultLabel.text = "Please select a unit."
            }
        } else {
           
            resultLabel.text = "Please enter a valid number."
        }
    }
}
