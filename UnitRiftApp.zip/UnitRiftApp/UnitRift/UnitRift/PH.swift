import UIKit

class PH : UIViewController {

    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var resultLabel: UILabel!

    let pHFactors: [Double] = [1.0, 10.0, 100.0]
    let unitNames = ["pH", "pOH", "H+"]

    override func viewDidLoad() {
        super.viewDidLoad()
        setupSegmentedControl()
    }

    func setupSegmentedControl() {
        for (index, unit) in unitNames.enumerated() {
            segmentedControl.setTitle(unit, forSegmentAt: index)
        }
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let inputValue = Double(inputTextField.text ?? "") {
            let selectedUnitIndex = segmentedControl.selectedSegmentIndex

            if selectedUnitIndex != UISegmentedControl.noSegment {
                let result = inputValue * pHFactors[selectedUnitIndex]
                resultLabel.text = "Result for \(unitNames[selectedUnitIndex]): \(result)"
            } else {
                
                resultLabel.text = "Please select a unit."
            }
        } else {
        
            resultLabel.text = "Please enter a valid number."
        }
    }
}
