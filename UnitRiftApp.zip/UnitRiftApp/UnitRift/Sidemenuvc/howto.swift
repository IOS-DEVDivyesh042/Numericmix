

import UIKit

class howto: UIViewController {

    @IBOutlet weak var txtde: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()

        txtde.layer.cornerRadius = 20
        txtde.layer.borderColor = UIColor.purple.cgColor
        txtde.layer.borderWidth = 4
       
    }
    

    
}
