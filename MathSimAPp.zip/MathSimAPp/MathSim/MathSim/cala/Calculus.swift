import UIKit

class Calculus : UIViewController {
    @IBOutlet weak var expressionTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    @IBAction func differentiateButtonPressed(_ sender: UIButton) {
        if let expression = expressionTextField.text {
            let result = CalculusCalculator.differentiate(expression: expression)
            resultLabel.text = "Differentiation: \(result)"
        } else {
            resultLabel.text = "Invalid input"
        }
    }
}
