import Foundation

class CalculusCalculator {
    static func differentiate(expression: String) -> String {
        // Basic example: Assume the expression is a polynomial in the form "ax^n".
        // Differentiation: d(ax^n)/dx = n * ax^(n-1)
        let components = expression.components(separatedBy: "x^")
        
        guard components.count == 2,
            let coefficient = Double(components[0]),
            let exponent = Double(components[1]) else {
                return "Invalid input"
        }
        
        let newCoefficient = exponent * coefficient
        let newExponent = exponent - 1
        
        return "\(newCoefficient)x^\(newExponent)"
    }
}
