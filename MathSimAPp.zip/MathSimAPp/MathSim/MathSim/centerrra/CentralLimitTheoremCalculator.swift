import Foundation

class CentralLimitTheoremCalculator {
    static func simulateCLT(sampleSize: Int, numberOfSamples: Int) -> [Double] {
        var means = [Double]()

        for _ in 1...numberOfSamples {
            // Generate a sample of random numbers (uniform distribution)
            let sample = (0..<sampleSize).map { _ in Double.random(in: 0..<1) }
            
            // Calculate the mean of the sample
            let mean = sample.reduce(0, +) / Double(sampleSize)
            means.append(mean)
        }

        return means
    }
}
