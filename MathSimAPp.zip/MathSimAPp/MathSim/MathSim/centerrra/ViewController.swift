import UIKit

class ViewController : UIViewController {
    @IBOutlet weak var sampleSizeTextField: UITextField!
    @IBOutlet weak var numberOfSamplesTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    @IBAction func simulateButtonPressed(_ sender: UIButton) {
        if let sampleSizeText = sampleSizeTextField.text,
           let numberOfSamplesText = numberOfSamplesTextField.text,
           let sampleSize = Int(sampleSizeText),
           let numberOfSamples = Int(numberOfSamplesText) {

            let means = CentralLimitTheoremCalculator.simulateCLT(sampleSize: sampleSize, numberOfSamples: numberOfSamples)
            resultLabel.text = "Sample Means: \(means)"
            
        } else {
            resultLabel.text = "Invalid input"
        }
    }
}
