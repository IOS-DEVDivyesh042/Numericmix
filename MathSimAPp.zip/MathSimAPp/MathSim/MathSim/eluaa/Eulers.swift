import UIKit

class Eulers : UIViewController {
    @IBOutlet weak var initialValueTextField: UITextField!
    @IBOutlet weak var stepSizeTextField: UITextField!
    @IBOutlet weak var iterationsTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    @IBAction func solveButtonPressed(_ sender: UIButton) {
        if let initialValueText = initialValueTextField.text,
           let stepSizeText = stepSizeTextField.text,
           let iterationsText = iterationsTextField.text,
           let initialValue = Double(initialValueText),
           let stepSize = Double(stepSizeText),
           let iterations = Int(iterationsText) {

            let results = EulersMethodCalculator.solveODE(initialValue: initialValue, stepSize: stepSize, iterations: iterations)
            resultLabel.text = "Results: \(results)"
            
        } else {
            resultLabel.text = "Invalid input"
        }
    }
}
