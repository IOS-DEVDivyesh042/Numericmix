import Foundation

class EulersMethodCalculator {
    static func solveODE(initialValue: Double, stepSize: Double, iterations: Int) -> [Double] {
        var results = [initialValue]
        var currentY = initialValue
        
        for _ in 1...iterations {
            // Example ODE: dy/dx = y
            let nextY = currentY + stepSize * currentY
            results.append(nextY)
            currentY = nextY
        }
        
        return results
    }
}
