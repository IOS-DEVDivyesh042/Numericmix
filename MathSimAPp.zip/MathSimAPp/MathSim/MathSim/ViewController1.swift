import UIKit

class ViewController1: UIViewController {
    
    // let buttonTitles = ["Button 1", "Button 2", "Button 3", "Button 4", "Button 5"]
    
    
    @IBOutlet weak var btn1: UIButton!
    
    @IBOutlet weak var btn2: UIButton!
    
    @IBOutlet weak var btn3: UIButton!
    
    
    @IBOutlet weak var btn4: UIButton!
    
    @IBOutlet weak var btn5: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    
    @IBAction func btnpytha(_ sender: Any) {
    }
    
    @IBAction func btncalc(_ sender: Any) {
    }
    
    
    @IBAction func btnferma(_ sender: Any) {
    }
    
    @IBAction func btnelura(_ sender: Any) {
    }
    
    
    
    
    
    
    
    
    
}

