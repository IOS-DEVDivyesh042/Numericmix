import UIKit

class Pythagoras : UIViewController {
    @IBOutlet weak var baseTextField: UITextField!
    @IBOutlet weak var heightTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    @IBAction func calculateButtonPressed(_ sender: UIButton) {
        if let baseText = baseTextField.text, let heightText = heightTextField.text,
           let base = Double(baseText), let height = Double(heightText) {
            let hypotenuse = PythagoreanTheorem.calculateHypotenuse(base: base, height: height)
            resultLabel.text = "Hypotenuse: \(hypotenuse)"
        } else {
            resultLabel.text = "Invalid input"
        }
    }
}
