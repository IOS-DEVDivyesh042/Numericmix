import Foundation

class PythagoreanTheorem {
    static func calculateHypotenuse(base: Double, height: Double) -> Double {
        return sqrt(base * base + height * height)
    }
}

