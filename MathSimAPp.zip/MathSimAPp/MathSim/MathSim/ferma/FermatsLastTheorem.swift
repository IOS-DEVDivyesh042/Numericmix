import Foundation

class FermatsLastTheorem {
    static func checkTheorem(a: Int, b: Int, c: Int, n: Int) -> Bool {
        // Fermat's Last Theorem: a^n + b^n = c^n has no solutions for n > 2
        guard n > 2 else {
            print("This theorem is only applicable for n > 2.")
            return false
        }

        let leftSide = pow(Double(a), Double(n)) + pow(Double(b), Double(n))
        let rightSide = pow(Double(c), Double(n))

        return leftSide == rightSide
    }
}

