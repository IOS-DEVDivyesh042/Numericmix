import UIKit

class Fermatlast : UIViewController {
    @IBOutlet weak var aTextField: UITextField!
    @IBOutlet weak var bTextField: UITextField!
    @IBOutlet weak var cTextField: UITextField!
    @IBOutlet weak var nTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    @IBAction func checkButtonPressed(_ sender: UIButton) {
        if let aText = aTextField.text, let bText = bTextField.text,
           let cText = cTextField.text, let nText = nTextField.text,
           let a = Int(aText), let b = Int(bText),
           let c = Int(cText), let n = Int(nText) {

            let isFermatViolated = FermatsLastTheorem.checkTheorem(a: a, b: b, c: c, n: n)

            if isFermatViolated {
                resultLabel.text = "Fermat's Last Theorem is violated for the given values!"
            } else {
                resultLabel.text = "Theorem holds true for the given values."
            }

        } else {
            resultLabel.text = "Invalid input"
        }
    }
}
