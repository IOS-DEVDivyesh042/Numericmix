//
//  BMI.swift
//  SwiftCalcHub
//
//  Created by Manish Bhanushali on 20/11/23.
//

import UIKit

class BMI: UIViewController {

    @IBOutlet weak var heightTextField: UITextField!
    @IBOutlet weak var weightTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        resultLabel.layer.cornerRadius = 20
        resultLabel.layer.borderWidth = 4
        resultLabel.layer.borderColor = UIColor.white.cgColor
    }

    @IBAction func calculateBMI(_ sender: UIButton) {
        if let heightText = heightTextField.text, let weightText = weightTextField.text,
           let heightInFeet = Double(heightText), let weight = Double(weightText) {

            // Convert height from feet to meters
            let heightInMeters = heightInFeet * 0.3048

            // Calculate BMI
            let bmi = weight / pow(heightInMeters, 2)
            
            // Display BMI result
            resultLabel.text = "BMI: \(String(format: "%.2f", bmi))"
        } else {
            resultLabel.text = "Please enter valid height and weight."
        }
    }
}
