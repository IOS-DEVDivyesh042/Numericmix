//
//  Alaram.swift
//  SwiftCalcHub
//
//  Created by Manish Bhanushali on 20/11/23.
//

import UIKit
import UserNotifications

class Alaram: UIViewController {

    @IBOutlet weak var alarmTimePicker: UIDatePicker!
    @IBOutlet weak var alarmStatusLabel: UILabel!

    var timer: Timer?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        alarmStatusLabel.layer.cornerRadius = 20
        alarmStatusLabel.layer.borderWidth = 4
        alarmStatusLabel.layer.borderColor = UIColor.white.cgColor

        // Request notification authorization when the view is loaded
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { (granted, error) in
            // Handle the result of the request
            if !granted {
                print("Notification permission not granted.")
            }
        }
    }

    @IBAction func setAlarm(_ sender: UIButton) {
        let alarmTime = alarmTimePicker.date
        scheduleLocalNotification(at: alarmTime)
    }

    func scheduleLocalNotification(at date: Date) {
        let notification = UNMutableNotificationContent()
        notification.title = "Alarm!"
        notification.body = "Your alarm is ringing."

        // Set the default notification sound
        notification.sound = UNNotificationSound.default

        let triggerDate = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: date)
        let trigger = UNCalendarNotificationTrigger(dateMatching: triggerDate, repeats: false)

        let request = UNNotificationRequest(identifier: "alarmNotification", content: notification, trigger: trigger)

        UNUserNotificationCenter.current().add(request) { (error) in
            if let error = error {
                print("Error scheduling notification: \(error.localizedDescription)")
            } else {
                print("Notification scheduled successfully.")
            }
        }
    }

    @IBAction func cancelAlarm(_ sender: UIButton) {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ["alarmNotification"])
        alarmStatusLabel.text = "Alarm canceled."
    }
}
