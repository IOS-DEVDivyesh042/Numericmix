import UIKit

class Stopwatch: UIViewController {

    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var recentTimesLabel: UILabel!

    var timer: Timer?
    var seconds = 0
    var recentTimes: [String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        timerLabel.layer.cornerRadius = 20
        timerLabel.layer.borderColor = UIColor.white.cgColor
        timerLabel.layer.borderWidth = 4
        
        recentTimesLabel.layer.cornerRadius = 20
        recentTimesLabel.layer.cornerRadius = 20
        recentTimesLabel.layer.cornerRadius = 20
        
    }

    @IBAction func startStopwatch(_ sender: UIButton) {
        timer?.invalidate()
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
    }

    @IBAction func recordTime(_ sender: UIButton) {
        let minutes = (seconds / 60) % 60
        let secondsString = String(format: "%02d", seconds % 60)
        let currentTime = "\(minutes):\(secondsString)"
        
        // Add the current time to the array
        recentTimes.insert(currentTime, at: 0)
        
        // Keep only the 5 most recent times
        if recentTimes.count > 5 {
            recentTimes.removeLast()
        }
        
        // Update the UI to show the recent times
        updateRecentTimesLabel()
        
        // Print debug information
        print("Recent Times: \(recentTimes)")
    }

    @IBAction func resetStopwatch(_ sender: UIButton) {
        timer?.invalidate()
        seconds = 0
        timerLabel.text = "00:00"
        recentTimes.removeAll()
        updateRecentTimesLabel()
    }

    @objc func updateTimer() {
        seconds += 1
        let minutes = (seconds / 60) % 60
        let secondsString = String(format: "%02d", seconds % 60)
        timerLabel.text = "\(minutes):\(secondsString)"
    }

    func updateRecentTimesLabel() {
        DispatchQueue.main.async {
            self.recentTimesLabel.text = "Recent Times:\n" + self.recentTimes.joined(separator: "\n")
        }
    }

}
