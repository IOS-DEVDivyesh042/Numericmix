//
//  Age.swift
//  SwiftCalcHub
//
//  Created by Manish Bhanushali on 20/11/23.
//

//import UIKit
//
//class Age: UIViewController {
//
//    @IBOutlet weak var ageDatePicker: UIDatePicker!
//    @IBOutlet weak var resultLabel: UILabel!
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        configureDatePicker()
//    }
//
//    @IBAction func calculateAge(_ sender: UIButton) {
//        let currentDate = Date()
//        let birthDate = ageDatePicker.date
//        let calendar = Calendar.current
//
//        let ageComponents = calendar.dateComponents([.year, .month, .day, .hour, .minute, .second, .weekOfMonth], from: birthDate, to: currentDate)
//
//        if let years = ageComponents.year,
//            let months = ageComponents.month,
//            let days = ageComponents.day,
//            let hours = ageComponents.hour,
//            let minutes = ageComponents.minute,
//            let seconds = ageComponents.second,
//            let weeks = ageComponents.weekOfMonth {
//
//            let ageString = String(format: "(%d years), %d months, %d days, %d hours, %d minutes, %d seconds, %d weeks", years, months, days, hours, minutes, seconds, weeks)
//
//            print("Age: \(ageString)") // Add this line for debugging
//
//            resultLabel.text = "Age: \(ageString)"
//        } else {
//            print("Error calculating age. \(ageComponents)")
//            resultLabel.text = "Error calculating age."
//        }
//    }
//
//    func configureDatePicker() {
//        // Customize the date picker if needed.
//    }
//}
import UIKit

class Age: UIViewController {

    @IBOutlet weak var ageDatePicker: UIDatePicker!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        configureDatePicker()
        
        resultLabel.layer.cornerRadius = 20
        resultLabel.layer.borderWidth = 4
        resultLabel.layer.borderColor = UIColor.white.cgColor
    }

    @IBAction func calculateAge(_ sender: UIButton) {
        let currentDate = Date()
        let birthDate = ageDatePicker.date
        let calendar = Calendar.current

        let ageComponents = calendar.dateComponents([.year, .month, .day, .hour, .minute, .second, .weekOfMonth], from: birthDate, to: currentDate)

        if let years = ageComponents.year,
            let months = ageComponents.month,
            let days = ageComponents.day,
            let hours = ageComponents.hour,
            let minutes = ageComponents.minute,
            let seconds = ageComponents.second,
            let weeks = ageComponents.weekOfMonth {

            let ageString = String(format: "%d years\n%d months\n%d days\n%d hours\n%d minutes\n%d seconds\n%d weeks", years, months, days, hours, minutes, seconds, weeks)

            print("Age: \(ageString)") // Add this line for debugging

            resultLabel.text = "Age:\n\(ageString)"
        } else {
            print("Error calculating age. \(ageComponents)")
            resultLabel.text = "Error calculating age."
        }
    }

    func configureDatePicker() {
        // Customize the date picker if needed.
    }
}
