import UIKit

class Energy : UIViewController {
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func convertToJoules(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 1.0, unitName: "Joules")
    }

    @IBAction func convertToKilojoules(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 0.001, unitName: "Kilojoules")
    }

    @IBAction func convertToCalories(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 4.184, unitName: "Calories")
    }

    func convertToUnit(unitTag: Int, conversionFactor: Double, unitName: String) {
        guard let inputValueText = inputTextField.text,
              let inputValue = Double(inputValueText) else {
            outputLabel.text = "Invalid input"
            return
        }

        let result = inputValue * conversionFactor
        outputLabel.text = "\(inputValue) \(unitName) is equal to \(result) Joules"
    }
}
