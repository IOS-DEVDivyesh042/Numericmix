

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var view1: UIView!
    
    @IBOutlet weak var btn1: UIButton!
    
    
    
    @IBOutlet weak var btn2: UIButton!
    
    @IBOutlet weak var view2: UIView!
    
    @IBOutlet weak var btn3: UIButton!
    
    
    @IBOutlet weak var view3: UIView!
    
    
    @IBOutlet weak var btn4: UIButton!
    
    @IBOutlet weak var btn5: UIButton!
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btn1.layer.cornerRadius = 10
        btn1.layer.borderColor = UIColor.white.cgColor
        btn1.layer.borderWidth = 3
        
        btn2.layer.cornerRadius = 10
        btn2.layer.borderColor = UIColor.white.cgColor
        btn2.layer.borderWidth = 3
        
        btn3.layer.cornerRadius = 10
        btn3.layer.borderColor = UIColor.white.cgColor
        btn3.layer.borderWidth = 3
        
        btn4.layer.cornerRadius = 10
        btn4.layer.borderColor = UIColor.white.cgColor
        btn4.layer.borderWidth = 3
        
        btn5.layer.cornerRadius = 10
        btn5.layer.borderColor = UIColor.white.cgColor
        btn5.layer.borderWidth = 3
        
        view1.layer.cornerRadius = 4
        view1.layer.borderColor = UIColor.red.cgColor
        view1.layer.borderWidth = 1
        
        view2.layer.cornerRadius = 4
        view2.layer.borderColor = UIColor.red.cgColor
        view2.layer.borderWidth = 1
        
        view3.layer.cornerRadius = 4
        view3.layer.borderColor = UIColor.red.cgColor
        view3.layer.borderWidth = 1
        
        
        
        
        
    }


}

