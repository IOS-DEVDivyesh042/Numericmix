//
//  ViewController.swift
//  ThermoSync
//
//  Created by Manish Bhanushali on 03/11/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var view1: UIView!
    
    @IBOutlet weak var btn1: UIButton!
    
    @IBOutlet weak var view2: UIView!
    
    
    @IBOutlet weak var btn2: UIButton!
    
    @IBOutlet weak var view3: UIView!
    
    
    @IBOutlet weak var btn3: UIButton!
    
    
    @IBOutlet weak var view4: UIView!
    
    @IBOutlet weak var btn4: UIButton!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        view1.layer.cornerRadius = 20
        view2.layer.cornerRadius = 20
        view3.layer.cornerRadius = 20
        view4.layer.cornerRadius = 20
        
        
        btn4.layer.cornerRadius = 20
        btn3.layer.cornerRadius = 20
        btn2.layer.cornerRadius = 20
        btn1.layer.cornerRadius = 20
        
        
        
        // Do any additional setup after loading the view.
    }

    
    @IBAction func btnthr(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "ThermalResistance") as! ThermalResistance
        navigationController!.pushViewController(nextvc, animated: true)
    }
    
    
    @IBAction func therEx(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "ThermalExpansion") as! ThermalExpansion
        navigationController!.pushViewController(nextvc, animated: true)
    }
    
    
    @IBAction func theCo(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "ThermalConductivity") as! ThermalConductivity
        navigationController!.pushViewController(nextvc, animated: true)
    }
    
    
    @IBAction func tempint(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "TemperatureInterval") as! TemperatureInterval
        navigationController!.pushViewController(nextvc, animated: true)
    }
    
    
    
    
    
    

}

