//
//  ThermalResistance.swift
//  ThermoSync
//
//  Created by Manish Bhanushali on 03/11/23.
//

import UIKit

class ThermalResistance : UIViewController {

    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputTextField: UITextField!
    @IBOutlet weak var unitSegmentedControl: UISegmentedControl!

    let conversionFactors: [Double] = [1.0, 0.5556, 0.0011, 0.0024, 0.0283] 
    let unitNames: [String] = ["°C/W", "K/W", "°F/ft²·h·°F", "m²·K/W", "in²·°F/BTU"]

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        convertThermalResistance()
    }

    func convertThermalResistance() {
        if let inputText = inputTextField.text, let inputValue = Double(inputText) {
            let selectedUnitIndex = unitSegmentedControl.selectedSegmentIndex
            let outputValue = inputValue * conversionFactors[selectedUnitIndex]
            let outputUnitName = unitNames[selectedUnitIndex]

            outputTextField.text = "\(outputValue) \(outputUnitName)"
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
