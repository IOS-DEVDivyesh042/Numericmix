//
//  ThermalExpansion.swift
//  ThermoSync
//
//  Created by Manish Bhanushali on 03/11/23.
//

import UIKit

class ThermalExpansion: UIViewController {

    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputTextField: UITextField!
    @IBOutlet weak var unitSegmentedControl: UISegmentedControl!

    let conversionFactors: [Double] = [1.0, 0.0000117, 0.00000651, 0.0000024, 0.0000013] 
    let unitNames: [String] = ["1/°C", "1/K", "1/°F", "1/°R", "1/Kelvin"]

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        convertThermalExpansion()
    }

    func convertThermalExpansion() {
        if let inputText = inputTextField.text, let inputValue = Double(inputText) {
            let selectedUnitIndex = unitSegmentedControl.selectedSegmentIndex
            let outputValue = inputValue * conversionFactors[selectedUnitIndex]
            let outputUnitName = unitNames[selectedUnitIndex]

            outputTextField.text = "\(outputValue) \(outputUnitName)"
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
