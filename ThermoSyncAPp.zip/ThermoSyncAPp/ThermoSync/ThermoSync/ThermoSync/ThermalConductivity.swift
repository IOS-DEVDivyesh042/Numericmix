//
//  ThermalConductivity.swift
//  ThermoSync
//
//  Created by Manish Bhanushali on 03/11/23.
//

import UIKit

class ThermalConductivity : UIViewController {

    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputTextField: UITextField!
    @IBOutlet weak var unitSegmentedControl: UISegmentedControl!

    let conversionFactors: [Double] = [1.0, 0.001, 1.7307, 0.5778, 1000.0] // Conversion factors for five thermal conductivity units
    let unitNames: [String] = ["W/m·K", "W/cm·K", "Btu/ft·h·°F", "cal/s·cm·°C", "mW/m·K"] // Unit names

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        convertThermalConductivity()
    }

    func convertThermalConductivity() {
        if let inputText = inputTextField.text, let inputValue = Double(inputText) {
            let selectedUnitIndex = unitSegmentedControl.selectedSegmentIndex
            let outputValue = inputValue * conversionFactors[selectedUnitIndex]
            let outputUnitName = unitNames[selectedUnitIndex]

            outputTextField.text = "\(outputValue) \(outputUnitName)"
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
