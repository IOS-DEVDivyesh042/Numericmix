//
//  TemperatureInterval.swift
//  ThermoSync
//
//  Created by Manish Bhanushali on 03/11/23.
//

import UIKit

class TemperatureInterval : UIViewController {

    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputTextField: UITextField!
    @IBOutlet weak var unitSegmentedControl: UISegmentedControl!

    let conversionFactors: [Double] = [1.0, 1.8, 33.8, 274.15, 0.5556] // Conversion factors for five temperature interval units
    let unitNames: [String] = ["°C", "°F", "°R", "K", "°C/W"] // Unit names

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        convertTemperatureInterval()
    }

    func convertTemperatureInterval() {
        if let inputText = inputTextField.text, let inputValue = Double(inputText) {
            let selectedUnitIndex = unitSegmentedControl.selectedSegmentIndex
            let outputValue = inputValue * conversionFactors[selectedUnitIndex]
            let outputUnitName = unitNames[selectedUnitIndex]

            outputTextField.text = "\(outputValue) \(outputUnitName)"
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
