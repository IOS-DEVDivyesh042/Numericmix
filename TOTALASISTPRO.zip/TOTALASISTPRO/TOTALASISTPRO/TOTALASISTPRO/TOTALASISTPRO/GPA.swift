import UIKit

class GPA :  UIViewController {

    @IBOutlet weak var gradeTextField: UITextField!
    @IBOutlet weak var creditHoursTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    @IBAction func calculateButtonTapped(_ sender: UIButton) {
        guard let gradeText = gradeTextField.text,
              let creditHoursText = creditHoursTextField.text,
              let grade = Double(gradeText),
              let creditHours = Double(creditHoursText) else {
            resultLabel.text = "Invalid input"
            return
        }

        let calculatedGPA = calculateGPA(grade: grade, creditHours: creditHours)
        resultLabel.text = "GPA: \(calculatedGPA)"
    }

    func calculateGPA(grade: Double, creditHours: Double) -> Double {
        // Assuming a standard GPA scale where A = 4.0, B = 3.0, C = 2.0, and so on
        return grade * creditHours
    }
}
