import UIKit

class Loan : UIViewController {

    @IBOutlet weak var loanAmountTextField: UITextField!
    @IBOutlet weak var interestRateTextField: UITextField!
    @IBOutlet weak var loanDurationTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    @IBAction func calculateButtonTapped(_ sender: UIButton) {
        guard let loanAmountText = loanAmountTextField.text,
              let interestRateText = interestRateTextField.text,
              let loanDurationText = loanDurationTextField.text,
              let loanAmount = Double(loanAmountText),
              let interestRate = Double(interestRateText),
              let loanDuration = Double(loanDurationText) else {
            resultLabel.text = "Invalid input"
            return
        }

        let monthlyPayment = calculateMonthlyPayment(loanAmount: loanAmount, interestRate: interestRate, loanDuration: loanDuration)
        resultLabel.text = "Monthly Payment: \(monthlyPayment)"
    }

    func calculateMonthlyPayment(loanAmount: Double, interestRate: Double, loanDuration: Double) -> Double {
        let monthlyInterestRate = interestRate / 1200 // Assuming annual interest rate
        let numberOfPayments = loanDuration * 12 // Assuming loan duration is in years

        // Monthly payment calculation using the formula for a fixed-rate loan
        let monthlyPayment = (loanAmount * monthlyInterestRate) / (1 - pow(1 + monthlyInterestRate, -numberOfPayments))

        return monthlyPayment
    }
}
