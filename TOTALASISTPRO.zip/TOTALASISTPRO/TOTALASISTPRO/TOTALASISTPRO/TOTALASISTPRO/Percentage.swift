import UIKit

class Percentage : UIViewController {

    @IBOutlet weak var valueTextField: UITextField!
    @IBOutlet weak var percentageTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    @IBAction func calculateButtonTapped(_ sender: UIButton) {
        guard let valueText = valueTextField.text,
              let percentageText = percentageTextField.text,
              let value = Double(valueText),
              let percentage = Double(percentageText) else {
            resultLabel.text = "Invalid input"
            return
        }

        let calculatedPercentage = calculatePercentage(value: value, percentage: percentage)
        resultLabel.text = "\(percentage)% of \(value) is \(calculatedPercentage)"
    }

    func calculatePercentage(value: Double, percentage: Double) -> Double {
        return value * (percentage / 100)
    }
}
