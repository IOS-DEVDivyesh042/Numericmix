import UIKit

class Tip   : UIViewController {

    @IBOutlet weak var billAmountTextField: UITextField!
    @IBOutlet weak var tipPercentageTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    @IBAction func calculateButtonTapped(_ sender: UIButton) {
        guard let billAmountText = billAmountTextField.text,
              let tipPercentageText = tipPercentageTextField.text,
              let billAmount = Double(billAmountText),
              let tipPercentage = Double(tipPercentageText) else {
            resultLabel.text = "Invalid input"
            return
        }

        let calculatedTip = calculateTip(billAmount: billAmount, tipPercentage: tipPercentage)
        let totalAmount = billAmount + calculatedTip

        resultLabel.text = "Tip: \(calculatedTip), Total Amount with Tip: \(totalAmount)"
    }

    func calculateTip(billAmount: Double, tipPercentage: Double) -> Double {
        return billAmount * (tipPercentage / 100)
    }
}
