import UIKit

class Gst : UIViewController {

    @IBOutlet weak var valueTextField: UITextField!
    @IBOutlet weak var gstPercentageTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    @IBAction func calculateButtonTapped(_ sender: UIButton) {
        guard let valueText = valueTextField.text,
              let gstPercentageText = gstPercentageTextField.text,
              let value = Double(valueText),
              let gstPercentage = Double(gstPercentageText) else {
            resultLabel.text = "Invalid input"
            return
        }

        let calculatedGST = calculateGST(value: value, gstPercentage: gstPercentage)
        let totalValueWithGST = value + calculatedGST
        resultLabel.text = "GST: \(calculatedGST), Total Value with GST: \(totalValueWithGST)"
    }

    func calculateGST(value: Double, gstPercentage: Double) -> Double {
        return value * (gstPercentage / 100)
    }
}
