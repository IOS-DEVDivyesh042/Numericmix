import UIKit

class EMI : UIViewController {

    @IBOutlet weak var loanAmountTextField: UITextField!
    @IBOutlet weak var interestRateTextField: UITextField!
    @IBOutlet weak var loanTermTextField: UITextField!

    @IBAction func calculateButtonTapped(_ sender: UIButton) {
        calculateEMI()
    }

    func calculateEMI() {
        guard let amountText = loanAmountTextField.text,
              let interestRateText = interestRateTextField.text,
              let termText = loanTermTextField.text,
              let amount = Double(amountText),
              let interestRate = Double(interestRateText),
              let term = Double(termText) else {
            showAlert(message: "Please enter valid numbers.")
            return
        }

        let monthlyInterestRate = interestRate / (12 * 100)
        let numberOfPayments = term * 12

        let emi = (amount * monthlyInterestRate * pow(1 + monthlyInterestRate, numberOfPayments)) / (pow(1 + monthlyInterestRate, numberOfPayments) - 1)

        showAlert(message: "Your Equated Monthly Installment (EMI) is \(emi)")
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "EMI Calculation", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
}
