import UIKit

class DistanceViewController: UIViewController, CustomDistanceDropdownDelegate {

    lazy var inputTextField: UITextField = {
        let textField = UITextField()
        textField.borderStyle = .roundedRect
        textField.placeholder = "Enter distance"
        textField.keyboardType = .decimalPad
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }()
    
    lazy var distanceDropdownButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Select Distance Unit", for: .normal)
        button.addTarget(self, action: #selector(distanceDropdownButtonTapped), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.black, for: .normal)
        return button
    }()
    
    lazy var convertButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Convert", for: .normal)
        button.addTarget(self, action: #selector(convertButtonTapped), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.black, for: .normal)
        return button
    }()
    
    lazy var resultLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    var distanceDropdownController: CustomDistanceDropdownViewController?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backgroundImage = UIImageView(image: UIImage(named: "bg"))
        backgroundImage.contentMode = .scaleAspectFill
        backgroundImage.translatesAutoresizingMaskIntoConstraints = false
        view.insertSubview(backgroundImage, at: 0)

        [inputTextField, distanceDropdownButton, convertButton, resultLabel].forEach { view.addSubview($0) }

        NSLayoutConstraint.activate([
            
            backgroundImage.topAnchor.constraint(equalTo: view.topAnchor),
                        backgroundImage.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                        backgroundImage.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                        backgroundImage.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            inputTextField.topAnchor.constraint(equalTo: view.topAnchor, constant: 120),
            inputTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            inputTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            inputTextField.heightAnchor.constraint(equalToConstant: 40),

            distanceDropdownButton.topAnchor.constraint(equalTo: inputTextField.bottomAnchor, constant: 20),
            distanceDropdownButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            distanceDropdownButton.heightAnchor.constraint(equalToConstant: 40),

            convertButton.topAnchor.constraint(equalTo: distanceDropdownButton.bottomAnchor, constant: 20),
            convertButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            convertButton.heightAnchor.constraint(equalToConstant: 40),

            resultLabel.topAnchor.constraint(equalTo: convertButton.bottomAnchor, constant: 20),
            resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            resultLabel.heightAnchor.constraint(equalToConstant: 30),
        ])
    }

    @objc func distanceDropdownButtonTapped() {
        showDistanceDropdown()
    }

    func showDistanceDropdown() {
        distanceDropdownController = CustomDistanceDropdownViewController()
        distanceDropdownController?.delegate = self
        distanceDropdownController?.options = ["Meters", "Kilometers", "Miles", "Yards", "Feet"]

        distanceDropdownController?.modalPresentationStyle = .popover
        distanceDropdownController?.popoverPresentationController?.permittedArrowDirections = .up
        distanceDropdownController?.popoverPresentationController?.sourceView = distanceDropdownButton
        distanceDropdownController?.popoverPresentationController?.sourceRect = distanceDropdownButton.bounds

        present(distanceDropdownController!, animated: true, completion: nil)
    }

    @objc func convertButtonTapped() {
        guard let inputValue = Double(inputTextField.text ?? ""), let selectedUnit = distanceDropdownController?.selectedOption else {
            resultLabel.text = "Invalid input or unit not selected"
            return
        }

        let convertedValue: Double
        let convertedUnit: String
        switch selectedUnit {
        case "Meters":
            convertedValue = inputValue
            convertedUnit = "Meters"
        case "Kilometers":
            convertedValue = inputValue / 1000
            convertedUnit = "Kilometers"
        case "Miles":
            convertedValue = inputValue / 1609.34
            convertedUnit = "Miles"
        case "Yards":
            convertedValue = inputValue * 1.09361
            convertedUnit = "Yards"
        case "Feet":
            convertedValue = inputValue * 3.28084
            convertedUnit = "Feet"
        default:
            convertedValue = inputValue
            convertedUnit = selectedUnit
        }

        resultLabel.text = "Converted: \(convertedValue) \(convertedUnit)"
    }

    func didSelectDistanceOption(_ option: String) {
        distanceDropdownButton.setTitle(option, for: .normal)
    }
}
