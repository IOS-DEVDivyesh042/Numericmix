import UIKit

class ViewController1: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Call a function to create and set up buttons
        setupButtons()
    }

    func setupButtons() {
        let fixedColor = UIColor.systemOrange // Replace with your desired fixed color

        let buttonTitles = ["Length", "Volume", "speed", "Distance", "Temprature"]

        for (index, title) in buttonTitles.enumerated() {
            let button = UIButton(type: .system)
            button.setTitle(title, for: .normal)
            button.translatesAutoresizingMaskIntoConstraints = false

            // Set fixed background color for each button
            button.backgroundColor = fixedColor

            // Set unique corner radii for each button
            button.layer.cornerRadius = CGFloat(index + 1) * 20

            // Set unique fonts and text color for each button
            button.titleLabel?.font = UIFont.systemFont(ofSize: 20 + CGFloat(index) * 2, weight: .bold)
            button.setTitleColor(.white, for: .normal)

            // Add button to the view
            view.addSubview(button)

            // Add Auto Layout constraints
            NSLayoutConstraint.activate([
                button.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
                button.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
                button.heightAnchor.constraint(equalToConstant: 100),
                button.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: CGFloat(index) * 120 + 20)
            ])

            // Add touchUpInside action to each button
            button.addTarget(self, action: #selector(buttonTapped(_:)), for: .touchUpInside)
        }
    }

    @objc func buttonTapped(_ sender: UIButton) {
        if let title = sender.currentTitle {
            print("Button tapped: \(title)")
            
            // Check which button is tapped
            switch title {
            case "Length":
                // Open LengthViewController
                let lengthVC = LengthViewController()
                navigationController?.pushViewController(lengthVC, animated: true)
                
            case "Volume":
                // Open VolumeViewController
                let volumeVC = VolumeViewController()
                navigationController?.pushViewController(volumeVC, animated: true)
                // Add cases for other buttons if needed
                
            case "speed" :
                let volumeVC = SpeedViewController()
                navigationController?.pushViewController(volumeVC, animated: true)
                
                
                
            case "Distance" :
                let volumeVC = DistanceViewController()
                navigationController?.pushViewController(volumeVC, animated: true)
                
                
                
            case "Temprature" :
                let volumeVC = TemperatureViewController()
                navigationController?.pushViewController(volumeVC, animated: true)
                
                
                
            default:
                break
            }
        }
    }
}
