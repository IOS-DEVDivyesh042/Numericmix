import UIKit

class VolumeViewController: UIViewController, CustomVolumeDropdownDelegate {

    lazy var inputTextField: UITextField = {
        let textField = UITextField()
        textField.borderStyle = .roundedRect
        textField.placeholder = "Enter volume"
        textField.keyboardType = .decimalPad
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }()
    
    lazy var volumeDropdownButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Select Volume Unit", for: .normal)
        button.addTarget(self, action: #selector(volumeDropdownButtonTapped), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.black, for: .normal)
        return button
    }()
    
    lazy var convertButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Convert", for: .normal)
        button.addTarget(self, action: #selector(convertButtonTapped), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.black, for: .normal)
        return button
        
    }()
    
    lazy var resultLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    var volumeDropdownController: CustomVolumeDropdownViewController?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backgroundImage = UIImageView(image: UIImage(named: "bg"))
        backgroundImage.contentMode = .scaleAspectFill
        backgroundImage.translatesAutoresizingMaskIntoConstraints = false
        view.insertSubview(backgroundImage, at: 0)

        [inputTextField, volumeDropdownButton, convertButton, resultLabel].forEach { view.addSubview($0) }

        NSLayoutConstraint.activate([
            
            backgroundImage.topAnchor.constraint(equalTo: view.topAnchor),
                        backgroundImage.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                        backgroundImage.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                        backgroundImage.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            inputTextField.topAnchor.constraint(equalTo: view.topAnchor, constant: 120),
            inputTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            inputTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            inputTextField.heightAnchor.constraint(equalToConstant: 40),

            volumeDropdownButton.topAnchor.constraint(equalTo: inputTextField.bottomAnchor, constant: 20),
            volumeDropdownButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            volumeDropdownButton.heightAnchor.constraint(equalToConstant: 40),

            convertButton.topAnchor.constraint(equalTo: volumeDropdownButton.bottomAnchor, constant: 20),
            convertButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            convertButton.heightAnchor.constraint(equalToConstant: 40),

            resultLabel.topAnchor.constraint(equalTo: convertButton.bottomAnchor, constant: 20),
            resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            resultLabel.heightAnchor.constraint(equalToConstant: 30),
        ])
    }

    @objc func volumeDropdownButtonTapped() {
        showVolumeDropdown()
    }

    func showVolumeDropdown() {
        volumeDropdownController = CustomVolumeDropdownViewController()
        volumeDropdownController?.delegate = self
        volumeDropdownController?.options = ["Liters", "Gallons", "Cubic Meters", "Cubic Feet", "Milliliters"]

        volumeDropdownController?.modalPresentationStyle = .popover
        volumeDropdownController?.popoverPresentationController?.permittedArrowDirections = .up
        volumeDropdownController?.popoverPresentationController?.sourceView = volumeDropdownButton
        volumeDropdownController?.popoverPresentationController?.sourceRect = volumeDropdownButton.bounds

        present(volumeDropdownController!, animated: true, completion: nil)
    }

    @objc func convertButtonTapped() {
        guard let inputValue = Double(inputTextField.text ?? ""), let selectedUnit = volumeDropdownController?.selectedOption else {
            resultLabel.text = "Invalid input or unit not selected"
            return
        }

        let convertedValue: Double
        let convertedUnit: String
        switch selectedUnit {
        case "Liters":
            convertedValue = inputValue
            convertedUnit = "Liters"
        case "Gallons":
            convertedValue = inputValue * 3.78541
            convertedUnit = "Gallons"
        case "Cubic Meters":
            convertedValue = inputValue * 1000
            convertedUnit = "Cubic Meters"
        case "Cubic Feet":
            convertedValue = inputValue * 28.3168
            convertedUnit = "Cubic Feet"
        case "Milliliters":
            convertedValue = inputValue / 1000
            convertedUnit = "Milliliters"
        default:
            convertedValue = inputValue
            convertedUnit = selectedUnit
        }

        resultLabel.text = "Converted: \(convertedValue) \(convertedUnit)"
    }

    func didSelectVolumeOption(_ option: String) {
        volumeDropdownButton.setTitle(option, for: .normal)
    }
}
