import UIKit

class LengthViewController: UIViewController, CustomLengthDropdownDelegate {

    lazy var inputTextField: UITextField = {
        let textField = UITextField()
        textField.borderStyle = .roundedRect
        textField.placeholder = "Enter length"
        textField.keyboardType = .decimalPad
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }()
    
    lazy var lengthDropdownButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Select Length Unit", for: .normal)
        button.addTarget(self, action: #selector(lengthDropdownButtonTapped), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.black, for: .normal)
        return button
    }()
    
    lazy var convertButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Convert", for: .normal)
        button.addTarget(self, action: #selector(convertButtonTapped), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.black, for: .normal)
        return button
    }()
    
    lazy var resultLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    var lengthDropdownController: CustomLengthDropdownViewController?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        let backgroundImage = UIImageView(image: UIImage(named: "bg"))
             backgroundImage.contentMode = .scaleAspectFill
             backgroundImage.translatesAutoresizingMaskIntoConstraints = false
             view.insertSubview(backgroundImage, at: 0)

        [inputTextField, lengthDropdownButton, convertButton, resultLabel].forEach { view.addSubview($0) }

        NSLayoutConstraint.activate([
            
            backgroundImage.topAnchor.constraint(equalTo: view.topAnchor),
                        backgroundImage.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                        backgroundImage.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                        backgroundImage.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            inputTextField.topAnchor.constraint(equalTo: view.topAnchor, constant: 120),
            inputTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            inputTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            inputTextField.heightAnchor.constraint(equalToConstant: 40),

            lengthDropdownButton.topAnchor.constraint(equalTo: inputTextField.bottomAnchor, constant: 20),
            lengthDropdownButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            lengthDropdownButton.heightAnchor.constraint(equalToConstant: 40),

            convertButton.topAnchor.constraint(equalTo: lengthDropdownButton.bottomAnchor, constant: 20),
            convertButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            convertButton.heightAnchor.constraint(equalToConstant: 40),

            resultLabel.topAnchor.constraint(equalTo: convertButton.bottomAnchor, constant: 20),
            resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            resultLabel.heightAnchor.constraint(equalToConstant: 30),
        ])
    }

    @objc func lengthDropdownButtonTapped() {
        showLengthDropdown()
    }

    func showLengthDropdown() {
        lengthDropdownController = CustomLengthDropdownViewController()
        lengthDropdownController?.delegate = self
        lengthDropdownController?.options = ["Meters", "Kilometers", "Miles", "Yards", "Feet"]

        lengthDropdownController?.modalPresentationStyle = .popover
        lengthDropdownController?.popoverPresentationController?.permittedArrowDirections = .up
        lengthDropdownController?.popoverPresentationController?.sourceView = lengthDropdownButton
        lengthDropdownController?.popoverPresentationController?.sourceRect = lengthDropdownButton.bounds

        present(lengthDropdownController!, animated: true, completion: nil)
    }

    @objc func convertButtonTapped() {
        guard let inputValue = Double(inputTextField.text ?? ""), let selectedUnit = lengthDropdownController?.selectedOption else {
            resultLabel.text = "Invalid input or unit not selected"
            return
        }

        let convertedValue: Double
        let convertedUnit: String
        switch selectedUnit {
        case "Meters":
            convertedValue = inputValue
            convertedUnit = "Meters"
        case "Kilometers":
            convertedValue = inputValue / 1000
            convertedUnit = "Kilometers"
        case "Miles":
            convertedValue = inputValue / 1609.34
            convertedUnit = "Miles"
        case "Yards":
            convertedValue = inputValue * 1.09361
            convertedUnit = "Yards"
        case "Feet":
            convertedValue = inputValue * 3.28084
            convertedUnit = "Feet"
        default:
            convertedValue = inputValue
            convertedUnit = selectedUnit
        }

        resultLabel.text = "Converted: \(convertedValue) \(convertedUnit)"
    }

    func didSelectLengthOption(_ option: String) {
        lengthDropdownButton.setTitle(option, for: .normal)
    }
}
