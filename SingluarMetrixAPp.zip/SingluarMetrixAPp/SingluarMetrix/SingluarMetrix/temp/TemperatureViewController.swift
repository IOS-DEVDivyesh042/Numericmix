import UIKit

class TemperatureViewController: UIViewController, CustomTemperatureDropdownDelegate {

    lazy var inputTextField: UITextField = {
        let textField = UITextField()
        textField.borderStyle = .roundedRect
        textField.placeholder = "Enter temperature"
        textField.keyboardType = .decimalPad
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }()
    
    lazy var temperatureDropdownButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Select Temperature Unit", for: .normal)
        button.addTarget(self, action: #selector(temperatureDropdownButtonTapped), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.black, for: .normal)
        return button
    }()
    
    lazy var convertButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Convert", for: .normal)
        button.addTarget(self, action: #selector(convertButtonTapped), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.black, for: .normal)
        return button
    }()
    
    lazy var resultLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    var temperatureDropdownController: CustomTemperatureDropdownViewController?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backgroundImage = UIImageView(image: UIImage(named: "bg"))
        backgroundImage.contentMode = .scaleAspectFill
        backgroundImage.translatesAutoresizingMaskIntoConstraints = false
        view.insertSubview(backgroundImage, at: 0)

        [inputTextField, temperatureDropdownButton, convertButton, resultLabel].forEach { view.addSubview($0) }

        NSLayoutConstraint.activate([
            
            backgroundImage.topAnchor.constraint(equalTo: view.topAnchor),
                        backgroundImage.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                        backgroundImage.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                        backgroundImage.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            inputTextField.topAnchor.constraint(equalTo: view.topAnchor, constant: 120),
            inputTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            inputTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            inputTextField.heightAnchor.constraint(equalToConstant: 40),

            temperatureDropdownButton.topAnchor.constraint(equalTo: inputTextField.bottomAnchor, constant: 20),
            temperatureDropdownButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            temperatureDropdownButton.heightAnchor.constraint(equalToConstant: 40),

            convertButton.topAnchor.constraint(equalTo: temperatureDropdownButton.bottomAnchor, constant: 20),
            convertButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            convertButton.heightAnchor.constraint(equalToConstant: 40),

            resultLabel.topAnchor.constraint(equalTo: convertButton.bottomAnchor, constant: 20),
            resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            resultLabel.heightAnchor.constraint(equalToConstant: 30),
        ])
    }

    @objc func temperatureDropdownButtonTapped() {
        showTemperatureDropdown()
    }

    func showTemperatureDropdown() {
        temperatureDropdownController = CustomTemperatureDropdownViewController()
        temperatureDropdownController?.delegate = self
        temperatureDropdownController?.options = ["Celsius", "Fahrenheit", "Kelvin"]

        temperatureDropdownController?.modalPresentationStyle = .popover
        temperatureDropdownController?.popoverPresentationController?.permittedArrowDirections = .up
        temperatureDropdownController?.popoverPresentationController?.sourceView = temperatureDropdownButton
        temperatureDropdownController?.popoverPresentationController?.sourceRect = temperatureDropdownButton.bounds

        present(temperatureDropdownController!, animated: true, completion: nil)
    }

    @objc func convertButtonTapped() {
        guard let inputValue = Double(inputTextField.text ?? ""), let selectedUnit = temperatureDropdownController?.selectedOption else {
            resultLabel.text = "Invalid input or unit not selected"
            return
        }

        let convertedValue: Double
        let convertedUnit: String
        switch selectedUnit {
        case "Celsius":
            convertedValue = inputValue
            convertedUnit = "Celsius"
        case "Fahrenheit":
            convertedValue = (inputValue - 32) * 5/9
            convertedUnit = "Fahrenheit"
        case "Kelvin":
            convertedValue = inputValue - 273.15
            convertedUnit = "Kelvin"
        default:
            convertedValue = inputValue
            convertedUnit = selectedUnit
        }

        resultLabel.text = "Converted: \(convertedValue) \(convertedUnit)"
    }

    func didSelectTemperatureOption(_ option: String) {
        temperatureDropdownButton.setTitle(option, for: .normal)
    }
}
