import UIKit

class SpeedViewController: UIViewController, CustomSpeedDropdownDelegate {

    lazy var inputTextField: UITextField = {
        let textField = UITextField()
        textField.borderStyle = .roundedRect
        textField.placeholder = "Enter speed"
        textField.keyboardType = .decimalPad
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }()
    
    lazy var speedDropdownButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Select Speed Unit", for: .normal)
        button.addTarget(self, action: #selector(speedDropdownButtonTapped), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.black, for: .normal)
        return button
    }()
    
    lazy var convertButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Convert", for: .normal)
        button.addTarget(self, action: #selector(convertButtonTapped), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.black, for: .normal)
        return button
    }()
    
    lazy var resultLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    var speedDropdownController: CustomSpeedDropdownViewController?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backgroundImage = UIImageView(image: UIImage(named: "bg"))
        backgroundImage.contentMode = .scaleAspectFill
        backgroundImage.translatesAutoresizingMaskIntoConstraints = false
        view.insertSubview(backgroundImage, at: 0)

        [inputTextField, speedDropdownButton, convertButton, resultLabel].forEach { view.addSubview($0) }

        NSLayoutConstraint.activate([
            
            backgroundImage.topAnchor.constraint(equalTo: view.topAnchor),
                        backgroundImage.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                        backgroundImage.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                        backgroundImage.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            inputTextField.topAnchor.constraint(equalTo: view.topAnchor, constant: 120),
            inputTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            inputTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            inputTextField.heightAnchor.constraint(equalToConstant: 40),

            speedDropdownButton.topAnchor.constraint(equalTo: inputTextField.bottomAnchor, constant: 20),
            speedDropdownButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            speedDropdownButton.heightAnchor.constraint(equalToConstant: 40),

            convertButton.topAnchor.constraint(equalTo: speedDropdownButton.bottomAnchor, constant: 20),
            convertButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            convertButton.heightAnchor.constraint(equalToConstant: 40),

            resultLabel.topAnchor.constraint(equalTo: convertButton.bottomAnchor, constant: 20),
            resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            resultLabel.heightAnchor.constraint(equalToConstant: 30),
        ])
    }

    @objc func speedDropdownButtonTapped() {
        showSpeedDropdown()
    }

    func showSpeedDropdown() {
        speedDropdownController = CustomSpeedDropdownViewController()
        speedDropdownController?.delegate = self
        speedDropdownController?.options = ["Meters/Second", "Kilometers/Hour", "Miles/Hour", "Knots"]

        speedDropdownController?.modalPresentationStyle = .popover
        speedDropdownController?.popoverPresentationController?.permittedArrowDirections = .up
        speedDropdownController?.popoverPresentationController?.sourceView = speedDropdownButton
        speedDropdownController?.popoverPresentationController?.sourceRect = speedDropdownButton.bounds

        present(speedDropdownController!, animated: true, completion: nil)
    }

    @objc func convertButtonTapped() {
        guard let inputValue = Double(inputTextField.text ?? ""), let selectedUnit = speedDropdownController?.selectedOption else {
            resultLabel.text = "Invalid input or unit not selected"
            return
        }

        let convertedValue: Double
        let convertedUnit: String
        switch selectedUnit {
        case "Meters/Second":
            convertedValue = inputValue
            convertedUnit = "Meters/Second"
        case "Kilometers/Hour":
            convertedValue = inputValue * 3.6
            convertedUnit = "Kilometers/Hour"
        case "Miles/Hour":
            convertedValue = inputValue * 2.23694
            convertedUnit = "Miles/Hour"
        case "Knots":
            convertedValue = inputValue * 1.94384
            convertedUnit = "Knots"
        default:
            convertedValue = inputValue
            convertedUnit = selectedUnit
        }

        resultLabel.text = "Converted: \(convertedValue) \(convertedUnit)"
    }

    func didSelectSpeedOption(_ option: String) {
        speedDropdownButton.setTitle(option, for: .normal)
    }
}
