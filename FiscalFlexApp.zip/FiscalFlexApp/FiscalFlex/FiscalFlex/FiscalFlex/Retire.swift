import UIKit

class Retire : UIViewController {
    
    @IBOutlet weak var currentSavingsTextField: UITextField!
    @IBOutlet weak var annualContributionTextField: UITextField!
    @IBOutlet weak var expectedReturnTextField: UITextField!
    @IBOutlet weak var yearsUntilRetirementTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
    }

    @IBAction func calculateButtonPressed(_ sender: UIButton) {
        calculateRetirementSavings()
    }

    func calculateRetirementSavings() {
        guard let currentSavingsText = currentSavingsTextField.text,
              let annualContributionText = annualContributionTextField.text,
              let expectedReturnText = expectedReturnTextField.text,
              let yearsUntilRetirementText = yearsUntilRetirementTextField.text,
              let currentSavings = Double(currentSavingsText),
              let annualContribution = Double(annualContributionText),
              let expectedReturn = Double(expectedReturnText),
              let yearsUntilRetirement = Double(yearsUntilRetirementText) else {

            resultLabel.text = "Invalid input"
            return
        }

        let futureValue = calculateFutureValue(currentSavings: currentSavings,
                                               annualContribution: annualContribution,
                                               expectedReturn: expectedReturn,
                                               yearsUntilRetirement: yearsUntilRetirement)

        resultLabel.text = "Your retirement savings will be $\(futureValue)"
    }

    func calculateFutureValue(currentSavings: Double, annualContribution: Double, expectedReturn: Double, yearsUntilRetirement: Double) -> Double {
        let numberOfPeriods = yearsUntilRetirement
        let interestRate = expectedReturn / 100.0
        let futureValue = currentSavings * pow(1 + interestRate, numberOfPeriods) + annualContribution * ((pow(1 + interestRate, numberOfPeriods) - 1) / interestRate)
        return futureValue
    }
}
