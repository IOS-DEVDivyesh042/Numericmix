import UIKit

class SalesTax : UIViewController {

    @IBOutlet weak var itemCostTextField: UITextField!
    @IBOutlet weak var salesTaxRateTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
       
    }

    @IBAction func calculateButtonPressed(_ sender: UIButton) {
        calculateTotalCost()
    }

    func calculateTotalCost() {
        guard let itemCostText = itemCostTextField.text,
              let salesTaxRateText = salesTaxRateTextField.text,
              let itemCost = Double(itemCostText),
              let salesTaxRate = Double(salesTaxRateText) else {
           
            resultLabel.text = "Invalid input"
            return
        }

        let totalCost = calculateTotalCost(itemCost: itemCost, salesTaxRate: salesTaxRate)

        resultLabel.text = "The total cost including sales tax is $\(totalCost)"
    }

    func calculateTotalCost(itemCost: Double, salesTaxRate: Double) -> Double {
        let salesTaxAmount = itemCost * salesTaxRate / 100.0
        let totalCost = itemCost + salesTaxAmount
        return totalCost
    }
}
