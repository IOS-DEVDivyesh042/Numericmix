import UIKit

class Amortisation : UIViewController {

    @IBOutlet weak var loanAmountTextField: UITextField!
    @IBOutlet weak var interestRateTextField: UITextField!
    @IBOutlet weak var loanTermTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func calculateButtonPressed(_ sender: UIButton) {
        calculateAmortization()
    }

    func calculateAmortization() {
        guard let loanAmountText = loanAmountTextField.text,
              let interestRateText = interestRateTextField.text,
              let loanTermText = loanTermTextField.text,
              let loanAmount = Double(loanAmountText),
              let interestRate = Double(interestRateText),
              let loanTerm = Double(loanTermText) else {

            resultLabel.text = "Invalid input"
            return
        }

        let monthlyPayment = calculateMonthlyPayment(loanAmount: loanAmount,
                                                     interestRate: interestRate,
                                                     loanTerm: loanTerm)

        resultLabel.text = "Your monthly payment is $\(monthlyPayment)"
    }

    func calculateMonthlyPayment(loanAmount: Double, interestRate: Double, loanTerm: Double) -> Double {
        let monthlyInterestRate = interestRate / 100.0 / 12.0
        let numberOfPayments = loanTerm * 12.0
        let denominator = pow(1 + monthlyInterestRate, numberOfPayments) - 1
        let monthlyPayment = loanAmount * (monthlyInterestRate * pow(1 + monthlyInterestRate, numberOfPayments)) / denominator
        return monthlyPayment
    }
}
