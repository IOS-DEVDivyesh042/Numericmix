

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var view1: UIView!
    
    @IBOutlet weak var view2: UIView!
    
    @IBOutlet weak var view3: UIView!
    
    @IBOutlet weak var view4: UIView!
    
    @IBOutlet weak var view5: UIView!
    

    @IBOutlet weak var btn1: UIButton!
    
    @IBOutlet weak var btn3: UIButton!
    
    @IBOutlet weak var btn4: UIButton!
    
    @IBOutlet weak var btn2: UIButton!
    
    @IBOutlet weak var btn5: UIButton!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        
        view5.layer.shadowRadius = 5
        view5.layer.masksToBounds = false
        view5.layer.shadowColor = UIColor.red.cgColor
        view5.layer.shadowOpacity = 1
        view5.layer.shadowOffset = CGSize(width: 3, height: 3)
        view5.layer.cornerRadius = 10
        
        view4.layer.shadowRadius = 5
        view4.layer.masksToBounds = false
        view4.layer.shadowColor = UIColor.red.cgColor
        view4.layer.shadowOpacity = 1
        view4.layer.shadowOffset = CGSize(width: 3, height: 3)
        view4.layer.cornerRadius = 10
        
        view3.layer.shadowRadius = 5
        view3.layer.masksToBounds = false
        view3.layer.shadowColor = UIColor.red.cgColor
        view3.layer.shadowOpacity = 1
        view3.layer.shadowOffset = CGSize(width: 3, height: 3)
        view3.layer.cornerRadius = 10
        
        view2.layer.shadowRadius = 5
        view2.layer.masksToBounds = false
        view2.layer.shadowColor = UIColor.red.cgColor
        view2.layer.shadowOpacity = 1
        view2.layer.shadowOffset = CGSize(width: 3, height: 3)
        view2.layer.cornerRadius = 10
        
        view1.layer.shadowRadius = 5
        view1.layer.masksToBounds = false
        view1.layer.shadowColor = UIColor.red.cgColor
        view1.layer.shadowOpacity = 1
        view1.layer.shadowOffset = CGSize(width: 3, height: 3)
        view1.layer.cornerRadius = 10
        
        
        
        
        
        
    }


}

