import UIKit

class RadExpo : UIViewController {

    @IBOutlet weak var userInputTextField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let userInput = userInputTextField.text, let exposureInRoentgens = Double(userInput) {
            let convertedValues = convertToOtherExposureUnits(exposureInRoentgens)
            navigateToResultViewController(with: convertedValues)
        } else {
            showAlert(message: "Please enter a valid radiation exposure.")
        }
    }

    func convertToOtherExposureUnits(_ exposureInRoentgens: Double) -> [String: Double] {
        let exposureInSieverts = exposureInRoentgens * 0.01
        let exposureInGrays = exposureInRoentgens * 0.01

        return [
            "Sieverts": exposureInSieverts,
            "Grays": exposureInGrays
        ]
    }

    func navigateToResultViewController(with values: [String: Double]) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let resultViewController = storyboard.instantiateViewController(withIdentifier: "ResultVC") as? ResultVC {
            resultViewController.resultValues = values
            self.present(resultViewController, animated: true, completion: nil)
        }
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
}
