import UIKit


protocol AlertPresentable {
    func showAlert(message: String, completion: (() -> Void)?)
}


extension AlertPresentable where Self: UIViewController {
    func showAlert(message: String, completion: (() -> Void)? = nil) {
        let alert = UIAlertController(title: "OUTPUT", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { _ in
            completion?()
        }
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
}

class ResultVC: UIViewController, AlertPresentable {

    var resultValues: [String: Double]?

    override func viewDidLoad() {
        super.viewDidLoad()
        DispatchQueue.main.async {
            self.displayResult()
        }
    }

    func displayResult() {
        var resultText = "Converted Values:\n"
        if let resultValues = resultValues {
            for (unit, value) in resultValues {
                resultText += "\(unit): \(value)\n"
            }
        }
        showAlert(message: resultText) {
            self.dismiss(animated: true, completion: nil)
        }
    }
}
