

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var vwView: UIView!
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        vwView.layer.cornerRadius = 50
        vwView.layer.backgroundColor = UIColor.white.cgColor
        vwView.layer.borderWidth = 4
        vwView.layer.borderColor = UIColor.black.cgColor
        
        
    }
    
    
    
    
    
    
    
    


}

