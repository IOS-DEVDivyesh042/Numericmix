import UIKit

class MolecularWeight: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    @IBOutlet weak var moleculesTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var pickerView: UIPickerView!

    let units = ["Grams", "Ounces", "Atoms", "Moles", "Liters"]

    override func viewDidLoad() {
        super.viewDidLoad()
        pickerView.dataSource = self
        pickerView.delegate = self
    }

    @IBAction func calculateButtonTapped(_ sender: UIButton) {
        if let moleculesText = moleculesTextField.text, let molecules = Double(moleculesText) {
            let selectedUnit = units[pickerView.selectedRow(inComponent: 0)]
            let calculatedWeight = calculateMolecularWeight(molecules: molecules, inUnit: selectedUnit)
            resultLabel.text = "\(calculatedWeight) g/mol"
        } else {
            resultLabel.text = "Invalid input"
        }
    }

    func calculateMolecularWeight(molecules: Double, inUnit unit: String) -> Double {
        switch unit {
        case "Grams":
            return molecules
        case "Ounces":
            return molecules * 0.03527396
        case "Atoms":
            return molecules / (6.022 * pow(10, 23))
        case "Moles":
            return molecules / 6.022 * pow(10, 23)
        case "Liters":
            
            return molecules
        default:
            return 0.0
        }
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return units.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return units[row]
    }
}
