

import UIKit

class Radiationactivity: UIViewController {


        @IBOutlet weak var inputTextField: UITextField!
        @IBOutlet weak var unitSegmentedControl: UISegmentedControl!
        @IBOutlet weak var resultLabel: UILabel!

        let unitConversionFactors: [String: Double] = [
            "Bq": 1.0,
            "Ci": 2.703e-11,
            "Rd": 1.0e6      
        ]

        @IBAction func convertButtonTapped(_ sender: UIButton) {
            guard let selectedUnit = unitSegmentedControl.titleForSegment(at: unitSegmentedControl.selectedSegmentIndex),
                  let inputText = inputTextField.text,
                  let inputValue = Double(inputText),
                  let conversionFactor = unitConversionFactors[selectedUnit] else {
                resultLabel.text = "Please select a unit and enter a valid value"
                return
            }

            let convertedValue = inputValue * conversionFactor
            resultLabel.text = "\(selectedUnit): \(convertedValue)"
        }
    }
