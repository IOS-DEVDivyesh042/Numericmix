import UIKit

class Ph : UIViewController {
    @IBOutlet var inputTextField: UITextField!
    @IBOutlet var unitPicker: UIPickerView!
    @IBOutlet var resultLabel: UILabel!

    // Define the pH units for this converter
    let pHUnits = ["pH", "pOH", "Hydrogen Ion Concentration (H+)", "Hydroxide Ion Concentration (OH-)", "Hydronium Ion Concentration (H3O+)"]
    let conversionFactors: [Double] = [1.0, 14.0, -1.0, -1.0, -1.0]

    override func viewDidLoad() {
        super.viewDidLoad()
        unitPicker.dataSource = self
        unitPicker.delegate = self
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let inputText = inputTextField.text, let inputValue = Double(inputText) {
            let selectedUnitIndex = unitPicker.selectedRow(inComponent: 0)
            let conversionFactor = conversionFactors[selectedUnitIndex]
            let resultValue = inputValue * conversionFactor
            resultLabel.text = "\(inputValue) \(pHUnits[selectedUnitIndex]) = \(resultValue)"
        } else {
            resultLabel.text = "Invalid input"
        }
    }
}

extension Ph : UIPickerViewDataSource, UIPickerViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pHUnits.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pHUnits[row]
    }
}
