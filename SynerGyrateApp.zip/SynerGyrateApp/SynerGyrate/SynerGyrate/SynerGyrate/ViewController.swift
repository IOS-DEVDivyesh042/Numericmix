//
//  ViewController.swift
//  SynerGyrate
//
//  Created by Manish Bhanushali on 11/11/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var view1: UIView!
    
    @IBOutlet weak var view2: UIView!
    
    @IBOutlet weak var view3: UIView!
    
    @IBOutlet weak var btnvol: UIButton!
    
    @IBOutlet weak var btnpre: UIButton!
    
    @IBOutlet weak var btnph: UIButton!
    
    @IBOutlet weak var btnener: UIButton!
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        view1.layer.cornerRadius = 2
        view1.layer.borderWidth = 2
        view1.layer.borderColor = UIColor.black.cgColor
        
        view2.layer.cornerRadius = 2
        view2.layer.borderWidth = 2
        view2.layer.borderColor = UIColor.black.cgColor
        
        view3.layer.cornerRadius = 2
        view3.layer.borderWidth = 2
        view3.layer.borderColor = UIColor.black.cgColor
        
        
        btnener.layer.cornerRadius = 5
        btnener.layer.borderWidth = 2
        btnener.layer.borderColor = UIColor.black.cgColor
        
        btnph.layer.cornerRadius = 5
        btnph.layer.borderWidth = 2
        btnph.layer.borderColor = UIColor.black.cgColor
        
        btnpre.layer.cornerRadius = 5
        btnpre.layer.borderWidth = 2
        btnpre.layer.borderColor = UIColor.black.cgColor
        
        btnvol.layer.cornerRadius = 5
        btnvol.layer.borderWidth = 2
        btnvol.layer.borderColor = UIColor.black.cgColor
       
    }

    @IBAction func Volume(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Volume")
        self.navigationController?.pushViewController(nextvc!, animated: true)
        
    }
    
    
    @IBAction func Pressure(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Pressure")
        self.navigationController?.pushViewController(nextvc!, animated: true)
        
    }
    
    
    @IBAction func PH(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Ph")
        self.navigationController?.pushViewController(nextvc!, animated: true)
        
    }
    
    
    @IBAction func ENERGY(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Energy")
        self.navigationController?.pushViewController(nextvc!, animated: true)
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    

}

