//
//  Pressure.swift
//  Converzilla
//
//  Created by Manish Bhanushali on 07/11/23.
//

import UIKit

class Pressure : UIViewController {
    @IBOutlet var inputTextField: UITextField!
    @IBOutlet var unitPicker: UIPickerView!
    @IBOutlet var resultLabel: UILabel!

    // Define the pressure units for this converter
    let pressureUnits = ["Pascals (Pa)", "Kilopascals (kPa)", "Megapascals (MPa)", "Bars (bar)", "Atmospheres (atm)"]
    let conversionFactors: [Double] = [1.0, 1.0e3, 1.0e6, 1.0e5, 1.01325e5]

    override func viewDidLoad() {
        super.viewDidLoad()
        unitPicker.dataSource = self
        unitPicker.delegate = self
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let inputText = inputTextField.text, let inputValue = Double(inputText) {
            let selectedUnitIndex = unitPicker.selectedRow(inComponent: 0)
            let conversionFactor = conversionFactors[selectedUnitIndex]
            let resultValue = inputValue * conversionFactor
            resultLabel.text = "\(inputValue) \(pressureUnits[selectedUnitIndex]) = \(resultValue)"
        } else {
            resultLabel.text = "Invalid input"
        }
    }
}

extension Pressure : UIPickerViewDataSource, UIPickerViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pressureUnits.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pressureUnits[row]
    }
}
