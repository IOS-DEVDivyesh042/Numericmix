//
//  Energy.swift
//  VersatileHub
//
//  Created by Manish Bhanushali on 10/11/23.
//

import UIKit

class Energy : UIViewController {
    @IBOutlet var inputTextField: UITextField!
    @IBOutlet var sourceUnitPicker: UIPickerView!
    @IBOutlet var targetUnitPicker: UIPickerView!
    @IBOutlet var convertedResultLabel: UILabel!

    let energyUnits = ["Joules", "Calories", "Kilowatt-Hours", "BTUs"]
    let conversionFactors: [[Double]] = [
        [1.0, 0.239006, 2.77778e-7, 0.000947817], // Joules
        [4.184, 1.0, 1.16222e-6, 3.96567e-3], // Calories
        [3.6e+6, 859.845, 1.0, 3412.14], // Kilowatt-Hours
        [1055.06, 252.164, 2.93071e-4, 1.0] // BTUs
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        sourceUnitPicker.dataSource = self
        sourceUnitPicker.delegate = self
        targetUnitPicker.dataSource = self
        targetUnitPicker.delegate = self
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let inputText = inputTextField.text, let inputValue = Double(inputText) {
            let sourceUnitIndex = sourceUnitPicker.selectedRow(inComponent: 0)
            let targetUnitIndex = targetUnitPicker.selectedRow(inComponent: 0)

            let conversionFactor = conversionFactors[sourceUnitIndex][targetUnitIndex]
            let resultValue = inputValue * conversionFactor

            convertedResultLabel.text = "\(inputValue) \(energyUnits[sourceUnitIndex]) = \(resultValue) \(energyUnits[targetUnitIndex])"
        } else {
            convertedResultLabel.text = "Invalid input"
        }
    }
}

extension Energy : UIPickerViewDataSource, UIPickerViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return energyUnits.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return energyUnits[row]
    }
}
