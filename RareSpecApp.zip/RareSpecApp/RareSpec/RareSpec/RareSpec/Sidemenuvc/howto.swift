//
//  how to.swift
//  Unitify Pro
//
//  Created by Manish Bhanushali on 29/10/23.
//

import UIKit

class howto: UIViewController {

    @IBOutlet weak var txtde: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()

        txtde.layer.cornerRadius = 2
        txtde.layer.borderColor = UIColor.white.cgColor
        txtde.layer.borderWidth = 5
       
    }
    


}
