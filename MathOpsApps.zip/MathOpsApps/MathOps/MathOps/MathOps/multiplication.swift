import UIKit

class multiplication: UIViewController {

    @IBOutlet weak var firstSlider: UISlider!
    @IBOutlet weak var secondSlider: UISlider!
    @IBOutlet weak var firstValueLabel: UILabel!
    @IBOutlet weak var secondValueLabel: UILabel!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        updateLabels()
    }

    @IBAction func firstSliderValueChanged(_ sender: UISlider) {
        updateLabels()
    }

    @IBAction func secondSliderValueChanged(_ sender: UISlider) {
        updateLabels()
    }

    func updateLabels() {
        let firstSliderValue = Int(firstSlider.value)
        let secondSliderValue = Int(secondSlider.value)

        firstValueLabel.text = "First Slider Value: \(firstSliderValue)"
        secondValueLabel.text = "Second Slider Value: \(secondSliderValue)"

        let result = firstSliderValue * secondSliderValue
        resultLabel.text = "Result: \(result)"
    }
}
