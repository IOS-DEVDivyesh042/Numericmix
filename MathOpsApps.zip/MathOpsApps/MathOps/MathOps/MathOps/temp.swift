import UIKit

class temp: UIViewController {

    @IBOutlet weak var celsiusSlider: UISlider!
    @IBOutlet weak var fahrenheitSlider: UISlider!
    @IBOutlet weak var celsiusLabel: UILabel!
    @IBOutlet weak var fahrenheitLabel: UILabel!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        updateLabels()
    }

    @IBAction func celsiusSliderValueChanged(_ sender: UISlider) {
        updateLabels()
    }

    @IBAction func fahrenheitSliderValueChanged(_ sender: UISlider) {
        updateLabels()
    }

    func updateLabels() {
        let celsiusValue = Int(celsiusSlider.value)
        let fahrenheitValue = Int(fahrenheitSlider.value)

        celsiusLabel.text = "Celsius: \(celsiusValue)°C"
        fahrenheitLabel.text = "Fahrenheit: \(fahrenheitValue)°F"

        let celsiusToFahrenheit = (celsiusValue * 9/5) + 32
        resultLabel.text = "Result: \(celsiusToFahrenheit)°F"
    }
}
