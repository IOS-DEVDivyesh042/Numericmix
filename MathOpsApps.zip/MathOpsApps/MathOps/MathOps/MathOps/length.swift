import UIKit

class length : UIViewController {

    @IBOutlet weak var metersSlider: UISlider!
    @IBOutlet weak var feetSlider: UISlider!
    @IBOutlet weak var metersLabel: UILabel!
    @IBOutlet weak var feetLabel: UILabel!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        updateLabels()
    }

    @IBAction func metersSliderValueChanged(_ sender: UISlider) {
        updateLabels()
    }

    @IBAction func feetSliderValueChanged(_ sender: UISlider) {
        updateLabels()
    }

    func updateLabels() {
        let metersValue = Int(metersSlider.value)
        let feetValue = Int(feetSlider.value)

        metersLabel.text = "Meters: \(metersValue)m"
        feetLabel.text = "Feet: \(feetValue)ft"

        let metersToFeetConversionFactor: Double = 3.28084
        let metersToFeet = Double(metersValue) * metersToFeetConversionFactor
        resultLabel.text = "Result: \(metersToFeet)ft"
    }
}
