import UIKit

class Loan : UIViewController {

    @IBOutlet weak var loanAmountTextField: UITextField!
    @IBOutlet weak var interestRateTextField: UITextField!
    @IBOutlet weak var loanTermTextField: UITextField!

    @IBAction func calculateButtonTapped(_ sender: UIButton) {
        calculateLoan()
    }

    func calculateLoan() {
        guard let amountText = loanAmountTextField.text,
              let interestRateText = interestRateTextField.text,
              let termText = loanTermTextField.text,
              let amount = Double(amountText),
              let interestRate = Double(interestRateText),
              let term = Double(termText) else {
            showAlert(message: "Please enter valid numbers.")
            return
        }

        let interest = amount * interestRate * term / 100
        let totalAmount = amount + interest

        showAlert(message: "The total amount is \(totalAmount)")
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "Loan Calculation", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
}
