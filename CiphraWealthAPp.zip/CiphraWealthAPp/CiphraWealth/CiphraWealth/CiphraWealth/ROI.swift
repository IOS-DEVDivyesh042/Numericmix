import UIKit

class ROI : UIViewController {
    

    let initialInvestmentTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter Initial Investment"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .decimalPad
        return textField
    }()
    
    let returnAmountTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter Return Amount"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .decimalPad
        return textField
    }()
    
    let calculateButton: UIButton = {
        let button = UIButton(type: .system)
        button.titleLabel?.font = UIFont(name: "ArialRoundedMTBold", size: 24)
        button.setTitle("Calculate ROI", for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.addTarget(self, action: #selector(calculateROI), for: .touchUpInside)
        return button
    }()
    
    let resultLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.numberOfLines = 0
        label.textColor = .white
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    func setupUI() {
            view.backgroundColor = .white

            view.addSubview(calculateButton)
            view.addSubview(initialInvestmentTextField)
            view.addSubview(returnAmountTextField)
            view.addSubview(resultLabel)

            calculateButton.translatesAutoresizingMaskIntoConstraints = false
            initialInvestmentTextField.translatesAutoresizingMaskIntoConstraints = false
            returnAmountTextField.translatesAutoresizingMaskIntoConstraints = false
            resultLabel.translatesAutoresizingMaskIntoConstraints = false

            NSLayoutConstraint.activate([
                calculateButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 100),
                calculateButton.heightAnchor.constraint(equalToConstant: 50),
                calculateButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),

                initialInvestmentTextField.topAnchor.constraint(equalTo: calculateButton.bottomAnchor, constant: 20),
                initialInvestmentTextField.heightAnchor.constraint(equalToConstant: 50),
                initialInvestmentTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 60),
                initialInvestmentTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

                returnAmountTextField.topAnchor.constraint(equalTo: initialInvestmentTextField.bottomAnchor, constant: 30),
                returnAmountTextField.heightAnchor.constraint(equalToConstant: 50),
                returnAmountTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
                returnAmountTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

                resultLabel.topAnchor.constraint(equalTo: returnAmountTextField.bottomAnchor, constant: 20),
                resultLabel.heightAnchor.constraint(equalToConstant: 50),
                resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
                resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            ])

            // Set the button as the first responder
            calculateButton.becomeFirstResponder()
        }

    
    @objc func calculateROI() {
        guard let initialInvestmentText = initialInvestmentTextField.text, let initialInvestment = Double(initialInvestmentText),
              let returnAmountText = returnAmountTextField.text, let returnAmount = Double(returnAmountText) else {
            resultLabel.text = "Invalid input. Please enter valid numbers."
            return
        }
        
        let roi = (returnAmount - initialInvestment) / initialInvestment * 100
        resultLabel.text = String(format: "ROI: %.2f%%", roi)
    }
}
