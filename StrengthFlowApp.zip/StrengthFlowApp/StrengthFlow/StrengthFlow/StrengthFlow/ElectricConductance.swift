

import UIKit

class ElectricConductance: UIViewController {

    @IBOutlet weak var valueTextField: UITextField!
    @IBOutlet weak var fromUnitSegmentedControl: UISegmentedControl!
    @IBOutlet weak var toUnitSegmentedControl: UISegmentedControl!
    @IBOutlet weak var resultLabel: UILabel!

    let units = ["S", "μS"]
    let conversionFactors: [Double] = [1.0, 1e-6]

    override func viewDidLoad() {
        super.viewDidLoad()
        setupSegmentedControls()
    }

    func setupSegmentedControls() {
        fromUnitSegmentedControl.removeAllSegments()
        toUnitSegmentedControl.removeAllSegments()

        for unit in units {
            fromUnitSegmentedControl.insertSegment(withTitle: unit, at: fromUnitSegmentedControl.numberOfSegments, animated: false)
            toUnitSegmentedControl.insertSegment(withTitle: unit, at: toUnitSegmentedControl.numberOfSegments, animated: false)
        }

        fromUnitSegmentedControl.selectedSegmentIndex = 0
        toUnitSegmentedControl.selectedSegmentIndex = 1
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let inputValue = Double(valueTextField.text ?? "") {
            let fromIndex = fromUnitSegmentedControl.selectedSegmentIndex
            let toIndex = toUnitSegmentedControl.selectedSegmentIndex
            let result = convertValue(inputValue, fromUnitIndex: fromIndex, toUnitIndex: toIndex)
            resultLabel.text = "\(inputValue) \(units[fromIndex]) = \(result) \(units[toIndex])"
        } else {
            resultLabel.text = "Invalid input"
        }
    }

    func convertValue(_ value: Double, fromUnitIndex: Int, toUnitIndex: Int) -> Double {
        let conversionFactor = conversionFactors[fromUnitIndex] / conversionFactors[toUnitIndex]
        return value * conversionFactor
    }
}
