import UIKit

class volume : UIViewController {

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var millilitersLabel: UILabel!
    @IBOutlet weak var litersLabel: UILabel!
    @IBOutlet weak var cubicInchesLabel: UILabel!
    @IBOutlet weak var cubicFeetLabel: UILabel!
    @IBOutlet weak var gallonsLabel: UILabel!

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let userInput = textField.text, let userVolume = Double(userInput) {
            let convertedMilliliters = userVolume * 1000
            let convertedLiters = userVolume
            let convertedCubicInches = userVolume * 61.0237
            let convertedCubicFeet = userVolume / 28.3168
            let convertedGallons = userVolume / 4.54609

            millilitersLabel.text = "Converted Milliliters: \(convertedMilliliters)"
            litersLabel.text = "Converted Liters: \(convertedLiters)"
            cubicInchesLabel.text = "Converted Cubic Inches: \(convertedCubicInches)"
            cubicFeetLabel.text = "Converted Cubic Feet: \(convertedCubicFeet)"
            gallonsLabel.text = "Converted Gallons: \(convertedGallons)"
        } else {
            millilitersLabel.text = "Invalid input"
            litersLabel.text = ""
            cubicInchesLabel.text = ""
            cubicFeetLabel.text = ""
            gallonsLabel.text = ""
        }
    }
}
