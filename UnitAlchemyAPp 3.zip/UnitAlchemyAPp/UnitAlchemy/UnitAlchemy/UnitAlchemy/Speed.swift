import UIKit

class Speed: UIViewController {

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var metersPerSecondLabel: UILabel!
    @IBOutlet weak var kilometersPerHourLabel: UILabel!
    @IBOutlet weak var milesPerHourLabel: UILabel!
    @IBOutlet weak var knotsLabel: UILabel!
    @IBOutlet weak var feetPerSecondLabel: UILabel!
    @IBOutlet weak var machLabel: UILabel!

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let userInput = textField.text, let userSpeed = Double(userInput) {
            let convertedMetersPerSecond = userSpeed
            let convertedKilometersPerHour = userSpeed * 3.6
            let convertedMilesPerHour = userSpeed * 2.23694
            let convertedKnots = userSpeed * 1.94384
            let convertedFeetPerSecond = userSpeed * 3.28084
            let convertedMach = userSpeed / 343.2

            metersPerSecondLabel.text = "Converted m/s: \(convertedMetersPerSecond)"
            kilometersPerHourLabel.text = "Converted km/h: \(convertedKilometersPerHour)"
            milesPerHourLabel.text = "Converted mph: \(convertedMilesPerHour)"
            knotsLabel.text = "Converted knots: \(convertedKnots)"
            feetPerSecondLabel.text = "Converted ft/s: \(convertedFeetPerSecond)"
            machLabel.text = "Converted Mach: \(convertedMach)"
        } else {
            metersPerSecondLabel.text = "Invalid input"
            kilometersPerHourLabel.text = ""
            milesPerHourLabel.text = ""
            knotsLabel.text = ""
            feetPerSecondLabel.text = ""
            machLabel.text = ""
        }
    }
}
