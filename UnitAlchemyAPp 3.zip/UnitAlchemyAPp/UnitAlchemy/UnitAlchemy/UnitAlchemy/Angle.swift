import UIKit

class Angle : UIViewController {

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var degreesLabel: UILabel!
    @IBOutlet weak var radiansLabel: UILabel!
    @IBOutlet weak var gradiansLabel: UILabel!
    @IBOutlet weak var revolutionsLabel: UILabel!

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let userInput = textField.text, let userAngle = Double(userInput) {
            let convertedDegrees = userAngle
            let convertedRadians = userAngle * .pi / 180
            let convertedGradians = userAngle * 10 / 9
            let convertedRevolutions = userAngle / 360

            degreesLabel.text = "Converted Degrees: \(convertedDegrees)"
            radiansLabel.text = "Converted Radians: \(convertedRadians)"
            gradiansLabel.text = "Converted Gradians: \(convertedGradians)"
            revolutionsLabel.text = "Converted Revolutions: \(convertedRevolutions)"
        } else {
            degreesLabel.text = "Invalid input"
            radiansLabel.text = ""
            gradiansLabel.text = ""
            revolutionsLabel.text = ""
        }
    }
}

