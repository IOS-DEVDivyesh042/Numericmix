import UIKit

class Data : UIViewController {

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var kilobytesLabel: UILabel!
    @IBOutlet weak var megabytesLabel: UILabel!
    @IBOutlet weak var gigabytesLabel: UILabel!
    @IBOutlet weak var terabytesLabel: UILabel!

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let userInput = textField.text, let userData = Double(userInput) {
            let convertedKilobytes = userData / 1024
            let convertedMegabytes = convertedKilobytes / 1024
            let convertedGigabytes = convertedMegabytes / 1024
            let convertedTerabytes = convertedGigabytes / 1024

            kilobytesLabel.text = "Converted KB: \(convertedKilobytes)"
            megabytesLabel.text = "Converted MB: \(convertedMegabytes)"
            gigabytesLabel.text = "Converted GB: \(convertedGigabytes)"
            terabytesLabel.text = "Converted TB: \(convertedTerabytes)"
        } else {
            kilobytesLabel.text = "Invalid input"
            megabytesLabel.text = ""
            gigabytesLabel.text = ""
            terabytesLabel.text = ""
        }
    }
}
