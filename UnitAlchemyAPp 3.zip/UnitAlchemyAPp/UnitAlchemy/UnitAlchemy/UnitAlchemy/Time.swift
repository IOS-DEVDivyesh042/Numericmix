import UIKit

class Time : UIViewController {

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var hoursLabel: UILabel!
    @IBOutlet weak var minutesLabel: UILabel!
    @IBOutlet weak var secondsLabel: UILabel!
    @IBOutlet weak var daysLabel: UILabel!
    @IBOutlet weak var weeksLabel: UILabel!
    @IBOutlet weak var monthsLabel: UILabel!
    @IBOutlet weak var yearsLabel: UILabel!
    @IBOutlet weak var decadesLabel: UILabel!
    @IBOutlet weak var centuriesLabel: UILabel!

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let userInput = textField.text, let userTime = Double(userInput) {
            let convertedHours = userTime + 6
            let convertedMinutes = userTime * 60 + 6
            let convertedSeconds = userTime * 3600 + 6
            let convertedDays = userTime / 24 + 6
            let convertedWeeks = userTime / (24 * 7) + 6
          
            let convertedCenturies = userTime / (24 * 36500) + 6

            hoursLabel.text = "Converted Hours: \(convertedHours)"
            minutesLabel.text = "Converted Minutes: \(convertedMinutes)"
            secondsLabel.text = "Converted Seconds: \(convertedSeconds)"
            daysLabel.text = "Converted Days: \(convertedDays)"
            weeksLabel.text = "Converted Weeks: \(convertedWeeks)"
           
            centuriesLabel.text = "Converted Centuries: \(convertedCenturies)"
        } else {
            hoursLabel.text = "Invalid input"
            minutesLabel.text = ""
            secondsLabel.text = ""
            daysLabel.text = ""
            weeksLabel.text = ""
           
            centuriesLabel.text = ""
        }
    }
}
