import UIKit

class Paperthickness : UIViewController {

    @IBOutlet weak var paperThicknessTextField: UITextField!
    @IBOutlet weak var quantityOfPaperTextField: UITextField!
    @IBOutlet weak var stackThicknessTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
       
    }

    @IBAction func calculateButtonTapped(_ sender: UIButton) {
        
        guard let paperThicknessStr = paperThicknessTextField.text,
              let quantityOfPaperStr = quantityOfPaperTextField.text,
              let stackThicknessStr = stackThicknessTextField.text,
              let paperThickness = Double(paperThicknessStr),
              let quantityOfPaper = Double(quantityOfPaperStr),
              let stackThickness = Double(stackThicknessStr) else {
            resultLabel.text = "Invalid input. Please enter valid numbers."
            return
        }

        let totalThickness = paperThickness * quantityOfPaper + stackThickness
        resultLabel.text = "Total Thickness: \(totalThickness) units"
    }

    @IBAction func clearButtonTapped(_ sender: UIButton) {
    
        paperThicknessTextField.text = ""
        quantityOfPaperTextField.text = ""
        stackThicknessTextField.text = ""
        resultLabel.text = ""
    }
}
