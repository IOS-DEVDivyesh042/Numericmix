import UIKit

class SlackTime : UIViewController {

    @IBOutlet weak var taskDurationTextField: UITextField!
    @IBOutlet weak var dependenciesTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func calculateButtonTapped(_ sender: UIButton) {
       
        guard let taskDurationStr = taskDurationTextField.text,
              let dependenciesStr = dependenciesTextField.text,
              let taskDuration = Double(taskDurationStr),
              let dependencies = Double(dependenciesStr) else {
            resultLabel.text = "Invalid input. Please enter valid numbers."
            return
        }

        let slackTime = dependencies == 0 ? 0 : taskDuration + dependencies
        resultLabel.text = "Slack Time: \(slackTime) units"
    }

    @IBAction func clearButtonTapped(_ sender: UIButton) {
       
        taskDurationTextField.text = ""
        dependenciesTextField.text = ""
        resultLabel.text = ""
    }
}
