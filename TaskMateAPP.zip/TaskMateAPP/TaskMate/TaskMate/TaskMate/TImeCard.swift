import UIKit

class TImeCard : UIViewController {

    @IBOutlet weak var startTimeTextField: UITextField!
    @IBOutlet weak var endTimeTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
 
    }

    @IBAction func calculateButtonTapped(_ sender: UIButton) {
       
        guard let startTimeStr = startTimeTextField.text,
              let endTimeStr = endTimeTextField.text,
              let startTime = convertTo24HourFormat(startTimeStr),
              let endTime = convertTo24HourFormat(endTimeStr) else {
            resultLabel.text = "Invalid input. Please enter valid time format (HH:mm)."
            return
        }

        let totalHours = calculateTotalHours(startTime: startTime, endTime: endTime)
        resultLabel.text = "Total Hours Worked: \(totalHours) hours"
    }

    @IBAction func clearButtonTapped(_ sender: UIButton) {
        
        startTimeTextField.text = ""
        endTimeTextField.text = ""
        resultLabel.text = ""
    }

    
    private func convertTo24HourFormat(_ time: String) -> Date? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        return dateFormatter.date(from: time)
    }

    
    private func calculateTotalHours(startTime: Date, endTime: Date) -> Double {
        let calendar = Calendar.current
        let components = calendar.dateComponents([.hour, .minute], from: startTime, to: endTime)
        let hours = Double(components.hour ?? 0)
        let minutes = Double(components.minute ?? 0) / 60.0
        return hours + minutes
    }
}
