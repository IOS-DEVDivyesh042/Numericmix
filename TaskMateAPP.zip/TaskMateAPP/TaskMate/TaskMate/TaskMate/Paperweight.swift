import UIKit

class Paperweight : UIViewController {

    @IBOutlet weak var paperWeightTextField: UITextField!
    @IBOutlet weak var sheetSizeTextField: UITextField!
    @IBOutlet weak var quantityOfSheetsTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func calculateButtonTapped(_ sender: UIButton) {
    
        guard let paperWeightStr = paperWeightTextField.text,
              let sheetSizeStr = sheetSizeTextField.text,
              let quantityOfSheetsStr = quantityOfSheetsTextField.text,
              let paperWeight = Double(paperWeightStr),
              let sheetSize = Double(sheetSizeStr),
              let quantityOfSheets = Double(quantityOfSheetsStr) else {
            resultLabel.text = "Invalid input. Please enter valid numbers."
            return
        }

        let totalWeight = paperWeight * sheetSize * quantityOfSheets
        resultLabel.text = "Total Weight: \(totalWeight) units"
    }

    @IBAction func clearButtonTapped(_ sender: UIButton) {
        paperWeightTextField.text = ""
        sheetSizeTextField.text = ""
        quantityOfSheetsTextField.text = ""
        resultLabel.text = ""
    }
}
