import UIKit

class GWAM : UIViewController {

    @IBOutlet weak var wordsTypedTextField: UITextField!
    @IBOutlet weak var timeTakenTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func calculateButtonTapped(_ sender: UIButton) {
       
        guard let wordsTypedStr = wordsTypedTextField.text,
              let timeTakenStr = timeTakenTextField.text,
              let wordsTyped = Double(wordsTypedStr),
              let timeTaken = Double(timeTakenStr) else {
            resultLabel.text = "Invalid input. Please enter valid numbers."
            return
        }

        let gwam = calculateGWAM(wordsTyped: wordsTyped, timeTaken: timeTaken)
        resultLabel.text = "GWAM: \(gwam) words per minute"
    }

    @IBAction func clearButtonTapped(_ sender: UIButton) {
        
        wordsTypedTextField.text = ""
        timeTakenTextField.text = ""
        resultLabel.text = ""
    }

    
    private func calculateGWAM(wordsTyped: Double, timeTaken: Double) -> Double {
        guard timeTaken > 0 else {
            return 0
        }
        let minutes = timeTaken / 60.0
        return wordsTyped / minutes
    }
}
