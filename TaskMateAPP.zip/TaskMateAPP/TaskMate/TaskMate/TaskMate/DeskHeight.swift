import UIKit

class DeskHeight : UIViewController {

    @IBOutlet weak var elbowHeightTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func calculateButtonTapped(_ sender: UIButton) {
       
        guard let elbowHeightStr = elbowHeightTextField.text,
              let elbowHeight = Double(elbowHeightStr) else {
            resultLabel.text = "Invalid input. Please enter a valid number."
            return
        }

        let deskHeight = elbowHeight
        resultLabel.text = "Recommended Desk Height: \(deskHeight) units"
    }

    @IBAction func clearButtonTapped(_ sender: UIButton) {
        
        elbowHeightTextField.text = ""
        resultLabel.text = ""
    }
}

