//
//  tempview1.swift
//  QuickSmart
//
//  Created by Manish Bhanushali on 21/11/23.
//

import UIKit

class tempview1: UIViewController {

    @IBOutlet weak var btn3: UIButton!
    
    @IBOutlet weak var txtf: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtf.layer.cornerRadius = 20
        txtf.layer.borderColor  = UIColor.black.cgColor
        txtf.layer.borderWidth = 5
        
        
        btn3.layer.cornerRadius = 5
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
