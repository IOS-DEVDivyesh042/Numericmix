import UIKit

class Ph: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var unitPickerView: UIPickerView!

    let units = ["pH", "pOH"]

    override func viewDidLoad() {
        super.viewDidLoad()

        // Set the delegate and data source for the pickerView
        unitPickerView.delegate = self
        unitPickerView.dataSource = self
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        guard let inputValue = inputTextField.text, !inputValue.isEmpty else {
            showAlert(message: "Please enter a value.")
            return
        }

        // Get the selected unit from the pickerView
        let selectedUnitIndex = unitPickerView.selectedRow(inComponent: 0)
        let selectedUnit = units[selectedUnitIndex]

        guard let numericValue = Double(inputValue) else {
            showAlert(message: "Invalid numeric value entered.")
            return
        }

        let convertedValue = convertValue(numericValue, to: selectedUnit)
        showAlert(message: "Converted: \(convertedValue) \(selectedUnit)")
    }

    func convertValue(_ value: Double, to unit: String) -> Double {
        switch unit.lowercased() {
        case "ph":
            return value
        case "poh":
            return 14 - value
        default:
            showAlert(message: "Invalid unit entered.")
            return value
        }
    }

    // MARK: - UIPickerViewDelegate and UIPickerViewDataSource

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return units.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return units[row]
    }

//    func showAlert(message: String) {
//        let alert = UIAlertController(title: "Conversion Result", message: message, preferredStyle: .alert)
//        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
//        alert.addAction(okAction)
//        present(alert, animated: true, completion: nil)
//    }
}
