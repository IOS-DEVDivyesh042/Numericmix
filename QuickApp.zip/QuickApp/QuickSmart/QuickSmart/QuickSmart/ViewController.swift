//
//  ViewController.swift
//  QuickSmart
//
//  Created by Manish Bhanushali on 21/11/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var view1: UIView!
    
    
    @IBOutlet weak var btn1: UIButton!
    
    @IBOutlet weak var btn2: UIButton!
    
    
    @IBOutlet weak var btn3: UIButton!
    
    
    @IBOutlet weak var btn4: UIButton!
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view1.layer.cornerRadius = 20
        view1.layer.borderColor = UIColor.white.cgColor
        view1.layer.borderWidth = 3
        btn1.layer.cornerRadius = 20
        btn2.layer.cornerRadius = 20
        btn3.layer.cornerRadius = 20
        btn4.layer.cornerRadius = 20
        
 
        
    }
    
    
    @IBAction func btnph(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Phview1")
        self.navigationController?.pushViewController(nextvc!, animated: true)
        
    }
    
    
    @IBAction func btnwater(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "watwerview1")
        self.navigationController?.pushViewController(nextvc!, animated: true)
        
    }
    
    
    @IBAction func btntemp(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "tempview1")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    @IBAction func btndistance(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "distancview1")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
}

