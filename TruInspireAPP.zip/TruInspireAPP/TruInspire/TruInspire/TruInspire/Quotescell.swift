import UIKit


class Quotescell: UITableViewCell {

    @IBOutlet weak var authorLabel: UILabel!
   // @IBOutlet weak var messageLabel: UILabel!
    
    @IBOutlet weak var imgg: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        authorLabel.layer.cornerRadius = 20
        authorLabel.layer.borderWidth = 2
        authorLabel.layer.borderColor = UIColor.white.cgColor
        
        
        imgg.layer.cornerRadius = 2
        imgg.layer.borderColor = UIColor.red.cgColor
        imgg.layer.borderWidth = 2
    }
    
    
    func configure(with quote: Quote) {
        authorLabel.text = "- \(quote.author)"
       
        authorLabel.topAnchor.constraint(equalTo: authorLabel.bottomAnchor, constant: 30).isActive = true
        
    }
}
