// ViewController.swift

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!

        //var quotes = [Quote]()
    let quotes = [
        Quote(text: "The only limit to our realization of tomorrow will be our doubts of today.", author: "Franklin D. Roosevelt"),
        Quote(text: "Life is what happens when you're busy making other plans.", author: "Allen Saunders"),
        Quote(text: "The greatest glory in living lies not in never falling, but in rising every time we fall.", author: "Nelson Mandela"),
        Quote(text: "The way to get started is to quit talking and begin doing.", author: "Walt Disney"),
        Quote(text: "Get busy living or get busy dying.", author: "Stephen King"),
        Quote(text: "You have within you right now, everything you need to deal with whatever the world can throw at you.", author: "Brian Tracy"),
        Quote(text: "The purpose of our lives is to be happy.", author: "Dalai Lama"),
        Quote(text: "Life is really simple, but we insist on making it complicated.", author: "Confucius"),
        Quote(text: "Believe you can, and you're halfway there.", author: "Theodore Roosevelt"),
        Quote(text: "Success is not final, failure is not fatal: It is the courage to continue that counts.", author: "Winston Churchill"),
        Quote(text: "The only way to do great work is to love what you do.", author: "Steve Jobs"),
        Quote(text: "In three words I can sum up everything I've learned about life: It goes on.", author: "Robert Frost"),
        Quote(text: "Your time is limited, don't waste it living someone else's life.", author: "Steve Jobs"),
        Quote(text: "The best way to predict the future is to create it.", author: "Peter Drucker"),
        Quote(text: "Life is either a daring adventure or nothing at all.", author: "Helen Keller"),
        Quote(text: "Challenges are what make life interesting and overcoming them is what makes life meaningful.", author: "Joshua J. Marine"),
        Quote(text: "Don't watch the clock; do what it does. Keep going.", author: "Sam Levenson"),
        Quote(text: "Do not wait to strike till the iron is hot, but make it hot by striking.", author: "William Butler Yeats"),
        Quote(text: "It's not what happens to you, but how you react to it that matters.", author: "Epictetus"),
        Quote(text: "The only place where success comes before work is in the dictionary.", author: "Vidal Sassoon"),
        Quote(text: "Don't count the days, make the days count.", author: "Muhammad Ali"),
        Quote(text: "Success usually comes to those who are too busy to be looking for it.", author: "Henry David Thoreau"),
        Quote(text: "What lies behind us and what lies before us are tiny matters compared to what lies within us.", author: "Ralph Waldo Emerson"),
        Quote(text: "The best revenge is massive success.", author: "Frank Sinatra"),
        Quote(text: "If you want to achieve greatness stop asking for permission.", author: "Anonymous"),
        Quote(text: "The future belongs to those who believe in the beauty of their dreams.", author: "Eleanor Roosevelt"),
        Quote(text: "The only way to do great work is to love what you do.", author: "Steve Jobs"),
        Quote(text: "Believe you can and you're halfway there.", author: "Theodore Roosevelt"),
        Quote(text: "It always seems impossible until it's done.", author: "Nelson Mandela"),
        Quote(text: "Your time is limited, don't waste it living someone else's life.", author: "Steve Jobs"),
        Quote(text: "Success is not final, failure is not fatal: It is the courage to continue that counts.", author: "Winston Churchill"),
        Quote(text: "In three words I can sum up everything I've learned about life: It goes on.", author: "Robert Frost"),
        Quote(text: "The best way to predict the future is to create it.", author: "Peter Drucker"),
        Quote(text: "Life is either a daring adventure or nothing at all.", author: "Helen Keller"),
        Quote(text: "Challenges are what make life interesting and overcoming them is what makes life meaningful.", author: "Joshua J. Marine"),
        Quote(text: "Don't watch the clock; do what it does. Keep going.", author: "Sam Levenson"),
        Quote(text: "Do not wait to strike till the iron is hot, but make it hot by striking.", author: "William Butler Yeats"),
        Quote(text: "It's not what happens to you, but how you react to it that matters.", author: "Epictetus"),
        Quote(text: "The only place where success comes before work is in the dictionary.", author: "Vidal Sassoon"),
        Quote(text: "Don't count the days, make the days count.", author: "Muhammad Ali"),
        Quote(text: "Success usually comes to those who are too busy to be looking for it.", author: "Henry David Thoreau"),
        Quote(text: "What lies behind us and what lies before us are tiny matters compared to what lies within us.", author: "Ralph Waldo Emerson"),
        Quote(text: "The best revenge is massive success.", author: "Frank Sinatra"),
        Quote(text: "If you want to achieve greatness stop asking for permission.", author: "Anonymous"),
        Quote(text: "The future belongs to those who believe in the beauty of their dreams.", author: "Eleanor Roosevelt"),
       
            Quote(text: "Success is not final, failure is not fatal: It is the courage to continue that counts.", author: "Winston Churchill"),
            Quote(text: "The only way to do great work is to love what you do.", author: "Steve Jobs"),
            Quote(text: "In three words I can sum up everything I've learned about life: It goes on.", author: "Robert Frost"),
            Quote(text: "Your time is limited, don't waste it living someone else's life.", author: "Steve Jobs"),
            Quote(text: "The best way to predict the future is to create it.", author: "Peter Drucker"),
            Quote(text: "Life is either a daring adventure or nothing at all.", author: "Helen Keller"),
            Quote(text: "Challenges are what make life interesting and overcoming them is what makes life meaningful.", author: "Joshua J. Marine"),
            Quote(text: "Don't watch the clock; do what it does. Keep going.", author: "Sam Levenson"),
            Quote(text: "Do not wait to strike till the iron is hot, but make it hot by striking.", author: "William Butler Yeats"),
            Quote(text: "It's not what happens to you, but how you react to it that matters.", author: "Epictetus"),
            Quote(text: "The only place where success comes before work is in the dictionary.", author: "Vidal Sassoon"),
            Quote(text: "Don't count the days, make the days count.", author: "Muhammad Ali"),
            Quote(text: "Success usually comes to those who are too busy to be looking for it.", author: "Henry David Thoreau"),
            Quote(text: "What lies behind us and what lies before us are tiny matters compared to what lies within us.", author: "Ralph Waldo Emerson"),
            Quote(text: "The best revenge is massive success.", author: "Frank Sinatra"),
            Quote(text: "If you want to achieve greatness stop asking for permission.", author: "Anonymous"),
            Quote(text: "The future belongs to those who believe in the beauty of their dreams.", author: "Eleanor Roosevelt"),
            Quote(text: "The only limit to our realization of tomorrow will be our doubts of today.", author: "Franklin D. Roosevelt"),
            Quote(text: "Life is what happens when you're busy making other plans.", author: "Allen Saunders"),
            Quote(text: "The greatest glory in living lies not in never falling, but in rising every time we fall.", author: "Nelson Mandela"),
            Quote(text: "The way to get started is to quit talking and begin doing.", author: "Walt Disney"),
            Quote(text: "Get busy living or get busy dying.", author: "Stephen King"),
            Quote(text: "You have within you right now, everything you need to deal with whatever the world can throw at you.", author: "Brian Tracy"),
            Quote(text: "The purpose of our lives is to be happy.", author: "Dalai Lama"),
            Quote(text: "Life is really simple, but we insist on making it complicated.", author: "Confucius"),
            Quote(text: "Believe you can, and you're halfway there.", author: "Theodore Roosevelt"),
            Quote(text: "The only way to do great work is to love what you do.", author: "Steve Jobs"),
            Quote(text: "In three words I can sum up everything I've learned about life: It goes on.", author: "Robert Frost"),
            Quote(text: "Your time is limited, don't waste it living someone else's life.", author: "Steve Jobs"),
            Quote(text: "The best way to predict the future is to create it.", author: "Peter Drucker"),
            Quote(text: "Life is either a daring adventure or nothing at all.", author: "Helen Keller"),
            Quote(text: "Challenges are what make life interesting and overcoming them is what makes life meaningful.", author: "Joshua J. Marine"),
            Quote(text: "Don't watch the clock; do what it does. Keep going.", author: "Sam Levenson"),
            Quote(text: "Do not wait to strike till the iron is hot, but make it hot by striking.", author: "William Butler Yeats"),
            Quote(text: "It's not what happens to you, but how you react to it that matters.", author: "Epictetus"),
            Quote(text: "The only place where success comes before work is in the dictionary.", author: "Vidal Sassoon"),
            Quote(text: "Don't count the days, make the days count.", author: "Muhammad Ali"),
            Quote(text: "Success usually comes to those who are too busy to be looking for it.", author: "Henry David Thoreau"),
            Quote(text: "What lies behind us and what lies before us are tiny matters compared to what lies within us.", author: "Ralph Waldo Emerson"),
            Quote(text: "The best revenge is massive success.", author: "Frank Sinatra"),
            Quote(text: "If you want to achieve greatness stop asking for permission.", author: "Anonymous"),
            Quote(text: "The future belongs to those who believe in the beauty of their dreams.", author: "Eleanor Roosevelt")
 

    ]


    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        
        
        
        tableView.layer.transform = CATransform3DMakeScale(1.1, 0.1, 0.1)
        UIView.animate(withDuration: 1.0,animations: { [self] in
            tableView.layer.transform = CATransform3DMakeScale(1.0, 1.0,1.0)
            
        }, completion: nil)
        

    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return quotes.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Quotescell", for: indexPath) as! Quotescell

        let quote = quotes[indexPath.row]
        cell.configure(with: quote)

        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedQuote = quotes[indexPath.row]
        showQuoteAlert(quote: selectedQuote)
        tableView.deselectRow(at: indexPath, animated: true)
    }

   

    
    func showQuoteAlert(quote: Quote) {
        let alert = UIAlertController(title: quote.author, message: quote.text, preferredStyle: .alert)

        let titleFont = [NSAttributedString.Key.font: UIFont(name: "Hoefler Text", size: 20)]
        let titleAttrString = NSMutableAttributedString(string: quote.author, attributes: titleFont as [NSAttributedString.Key : Any])
        alert.setValue(titleAttrString, forKey: "attributedTitle")

      
        let messageFont = [NSAttributedString.Key.font: UIFont(name: "Hoefler Text", size: 24)]
        let messageAttrString = NSMutableAttributedString(string: quote.text, attributes: messageFont as [NSAttributedString.Key : Any])
        alert.setValue(messageAttrString, forKey: "attributedMessage")

        let cancelAction = UIAlertAction(title: "ok", style: .cancel, handler: nil)
        alert.addAction(cancelAction)

        present(alert, animated: true, completion: nil)
    }

    
    func addQuoteToBookmarks(_ quote: Quote) {
        print("Quote added to bookmarks: \(quote)")
    }
    
   
}

struct Quote {
    var text: String
    var author: String
}
