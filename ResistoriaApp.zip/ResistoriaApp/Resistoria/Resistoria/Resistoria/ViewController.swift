//
//  ViewController.swift
//  Resistoria
//
//  Created by Manish Bhanushali on 01/11/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var view1: UIView!
    
    @IBOutlet weak var view2: UIView!
    
    @IBOutlet weak var btn1: UIButton!
    
    @IBOutlet weak var btn2: UIButton!
    
    @IBOutlet weak var btn3: UIButton!

    @IBOutlet weak var btn4: UIButton!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        view1.layer.cornerRadius = 50
        view1.layer.borderWidth = 5
        view1.layer.borderColor = UIColor.black.cgColor
        view2.layer.cornerRadius = 50
        
        btn1.layer.cornerRadius = 10
        btn2.layer.cornerRadius = 10
        btn3.layer.cornerRadius = 10
        btn4.layer.cornerRadius = 10
        
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func eleconducta(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "ElectricConductance") as! ElectricConductance
        navigationController!.pushViewController(nextvc, animated: true)
    }
    
    
    
    
    
    @IBAction func elecvonducti(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "ElectricConductivity") as! ElectricConductivity
        navigationController?.pushViewController(nextvc, animated: true)
    }
    
    
    
    @IBAction func elecresis(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "ElectricResistivity") as! ElectricResistivity
        navigationController?.pushViewController(nextvc, animated: true)
    }
    
    
    @IBAction func elecresistan(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "ElectricResistance") as! ElectricResistance
        navigationController?.pushViewController(nextvc, animated: true)
    }
    
    
    
    
    
    
    
    
    
    
    


}

