//
//  DoseEquivalent.swift
//  Viscografix
//
//  Created by Manish Bhanushali on 09/11/23.
//

import UIKit

class DoseEquivalent: UIViewController {

        @IBOutlet weak var inputTextField: UITextField!
        @IBOutlet weak var unitSegmentedControl: UISegmentedControl!
        @IBOutlet weak var resultLabel: UILabel!

        let unitConversionFactors: [String: Double] = [
            "Sv": 1.0,
            "Rem": 100,  // Conversion factor from Sv to Rem
            "Rad": 100    // Conversion factor from Sv to Rad
        ]

        @IBAction func convertButtonTapped(_ sender: UIButton) {
            guard let selectedUnit = unitSegmentedControl.titleForSegment(at: unitSegmentedControl.selectedSegmentIndex),
                  let inputText = inputTextField.text,
                  let inputValue = Double(inputText),
                  let conversionFactor = unitConversionFactors[selectedUnit] else {
                resultLabel.text = "Please select a unit and enter a valid value"
                return
            }

            let convertedValue = inputValue * conversionFactor
            resultLabel.text = "\(selectedUnit): \(convertedValue)"
        }
    }
