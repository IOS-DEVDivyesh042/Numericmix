//
//  RadiationAbsorbedDose.swift
//  Viscografix
//
//  Created by Manish Bhanushali on 09/11/23.
//

import UIKit

class RadiationAbsorbedDose: UIViewController {
    
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var unitSegmentedControl: UISegmentedControl!
    @IBOutlet weak var resultLabel: UILabel!
    
    let unitConversionFactors: [String: Double] = [
        "Gy": 1.0,
        "Rad": 100,      // Conversion factor from Gy to Rad
        "Sv": 1.0        // Conversion factor from Gy to Sv
    ]
    
    @IBAction func convertButtonTapped(_ sender: UIButton) {
        guard let selectedUnit = unitSegmentedControl.titleForSegment(at: unitSegmentedControl.selectedSegmentIndex),
              let inputText = inputTextField.text,
              let inputValue = Double(inputText),
              let conversionFactor = unitConversionFactors[selectedUnit] else {
            resultLabel.text = "Please select a unit and enter a valid value"
            return
        }
        
        let convertedValue = inputValue * conversionFactor
        resultLabel.text = "\(selectedUnit): \(convertedValue)"
    }
}
