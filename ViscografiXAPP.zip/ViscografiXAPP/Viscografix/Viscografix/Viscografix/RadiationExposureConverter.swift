//
//  RadiationExposureConverter.swift
//  Viscografix
//
//  Created by Manish Bhanushali on 09/11/23.
//



import UIKit

class RadiationExposureConverter: UIViewController {
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var unitSegmentedControl: UISegmentedControl!
    @IBOutlet weak var resultLabel: UILabel!

    let unitConversionFactors: [String: Double] = [
        "C/kg": 1.0,
        "R": 3876.0,    // Conversion factor from C/kg to R
        "Gy": 1.0e-2    // Conversion factor from C/kg to Gy
    ]

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        guard let selectedUnit = unitSegmentedControl.titleForSegment(at: unitSegmentedControl.selectedSegmentIndex),
              let inputText = inputTextField.text,
              let inputValue = Double(inputText),
              let conversionFactor = unitConversionFactors[selectedUnit] else {
            resultLabel.text = "Please select a unit and enter a valid value"
            return
        }

        let convertedValue = inputValue * conversionFactor
        resultLabel.text = "\(selectedUnit): \(convertedValue)"
    }
}
