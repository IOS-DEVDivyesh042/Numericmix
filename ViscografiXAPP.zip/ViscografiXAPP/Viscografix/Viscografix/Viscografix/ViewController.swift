//
//  ViewController.swift
//  Viscografix
//
//  Created by Manish Bhanushali on 09/11/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var view2: UIView!
    
    @IBOutlet weak var view1: UIView!
    
    
    @IBOutlet weak var view3: UIView!
    
    
    
    @IBOutlet weak var view4: UIView!
    
    
    @IBOutlet weak var view5: UIView!
    
    
    @IBOutlet weak var btn3: UIButton!
    
    
    @IBOutlet weak var btn2: UIButton!
    @IBOutlet weak var btn1: UIButton!
    @IBOutlet weak var btn4: UIButton!
    @IBOutlet weak var btn5: UIButton!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        btn1.layer.cornerRadius = 5
        btn1.layer.borderColor = UIColor.black.cgColor
        btn1.layer.borderWidth = 3
        
        btn2.layer.cornerRadius = 5
        btn2.layer.borderColor = UIColor.black.cgColor
        btn2.layer.borderWidth = 3
        
        btn3.layer.cornerRadius = 5
        btn3.layer.borderColor = UIColor.black.cgColor
        btn3.layer.borderWidth = 3
        
        btn4.layer.cornerRadius = 5
        btn4.layer.borderColor = UIColor.black.cgColor
        btn4.layer.borderWidth = 3
        
        btn5.layer.cornerRadius = 5
        btn5.layer.borderColor = UIColor.black.cgColor
        btn5.layer.borderWidth = 3
        
        
        view1.layer.cornerRadius = 5
        view1.layer.borderColor = UIColor.black.cgColor
        view1.layer.borderWidth = 3
        
        view2.layer.cornerRadius = 5
        view2.layer.borderColor = UIColor.black.cgColor
        view2.layer.borderWidth = 3
        
        view5.layer.cornerRadius = 5
        view5.layer.borderColor = UIColor.black.cgColor
        view5.layer.borderWidth = 3
        
        view4.layer.cornerRadius = 5
        view4.layer.borderColor = UIColor.black.cgColor
        view4.layer.borderWidth = 3
        
        view3.layer.cornerRadius = 5
        view3.layer.borderColor = UIColor.black.cgColor
        view3.layer.borderWidth = 3
        
        
        
    }
    
    //@IBOutlet weak var btnradia: UIView!
    
    @IBAction func btnradia(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Radiation")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    @IBAction func btnRadiabsor(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "RadiationAbsorbedDose")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    @IBAction func btndoseeqvi(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "DoseEquivalent")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    @IBAction func radiaexpo(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "RadiationExposureConverter")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    @IBAction func radiaactivi(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Radiationactivity")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    
    
    
    
    
    
    
    
    


}

