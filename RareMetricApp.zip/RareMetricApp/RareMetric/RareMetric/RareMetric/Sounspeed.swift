
import UIKit

class Sounspeed : UIViewController {
    @IBOutlet var inputTextField: UITextField!
    @IBOutlet var unitPicker: UIPickerView!
    @IBOutlet var resultLabel: UILabel!

    
    let soundSpeedUnits = ["Meters per Second (m/s)", "Feet per Second (ft/s)", "Kilometers per Hour (km/h)", "Miles per Hour (mph)", "Knots (kn)"]
    let conversionFactors: [Double] = [1.0, 0.3048, 0.27778, 0.44704, 0.514444]

    override func viewDidLoad() {
        super.viewDidLoad()
        unitPicker.dataSource = self
        unitPicker.delegate = self
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let inputText = inputTextField.text, let inputValue = Double(inputText) {
            let selectedUnitIndex = unitPicker.selectedRow(inComponent: 0)
            let conversionFactor = conversionFactors[selectedUnitIndex]
            let resultValue = inputValue * conversionFactor
            resultLabel.text = "\(inputValue) \(soundSpeedUnits[selectedUnitIndex]) = \(resultValue)"
        } else {
            resultLabel.text = "Invalid input"
        }
    }
}

extension Sounspeed : UIPickerViewDataSource, UIPickerViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return soundSpeedUnits.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return soundSpeedUnits[row]
    }
}
