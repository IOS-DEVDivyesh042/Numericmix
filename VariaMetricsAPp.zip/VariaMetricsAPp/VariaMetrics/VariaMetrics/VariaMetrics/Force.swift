import UIKit

class Force: UIViewController {
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Additional setup if needed
    }

    @IBAction func convertToNewtons(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 1.0, unitName: "Newtons")
    }

    @IBAction func convertToKilogramsForce(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 0.101971621, unitName: "Kilograms Force")
    }

    @IBAction func convertToPoundForce(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 0.224808943, unitName: "Pound Force")
    }

    // Add more conversion functions as needed

    func convertToUnit(unitTag: Int, conversionFactor: Double, unitName: String) {
        guard let inputValueText = inputTextField.text,
              let inputValue = Double(inputValueText) else {
            outputLabel.text = "Invalid input"
            return
        }

        let result = inputValue * conversionFactor
        outputLabel.text = "\(inputValue) \(unitName) is equal to \(result) Newtons"
    }
}
