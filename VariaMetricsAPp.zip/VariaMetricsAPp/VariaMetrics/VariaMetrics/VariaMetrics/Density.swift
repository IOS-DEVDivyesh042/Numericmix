import UIKit

class Density: UIViewController {
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Additional setup if needed
    }

    @IBAction func convertToKilogramsPerCubicMeter(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 1.0, unitName: "Kilograms/m³")
    }

    @IBAction func convertToGramsPerCubicCentimeter(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 0.001, unitName: "Grams/cm³")
    }

    // Add more conversion functions as needed

    func convertToUnit(unitTag: Int, conversionFactor: Double, unitName: String) {
        guard let inputValueText = inputTextField.text,
              let inputValue = Double(inputValueText) else {
            outputLabel.text = "Invalid input"
            return
        }

        let result = inputValue * conversionFactor
        outputLabel.text = "\(inputValue) \(unitName) is equal to \(result) Kilograms/m³"
    }
}
