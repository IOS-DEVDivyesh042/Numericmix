import UIKit

class CarChargingCost: UIViewController {

    let hoursTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Hours"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .numberPad
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.layer.cornerRadius = 8
        return textField
    }()

    let minutesTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Minutes"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .numberPad
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.layer.cornerRadius = 8
        return textField
    }()

    let chargingRateTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Charging Rate"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .decimalPad
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.layer.cornerRadius = 8
        return textField
    }()

    let calculateButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Calculate", for: .normal)
        button.addTarget(self, action: #selector(calculateButtonTapped), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.layer.backgroundColor = UIColor.black.cgColor
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 50 // Set the corner radius to half of the button's height
        return button
    }()

    let resultLabel: UILabel = {
        let label = UILabel()
        label.text = "Charging cost: $0.00"
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textColor = UIColor.black
        label.font = UIFont.systemFont(ofSize: 16)
        label.textAlignment = .center
        return label
    }()

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = UIColor.white

        view.addSubview(hoursTextField)
        view.addSubview(minutesTextField)
        view.addSubview(chargingRateTextField)
        view.addSubview(calculateButton)
        view.addSubview(resultLabel)

        setupConstraints()
    }

    func setupConstraints() {
        NSLayoutConstraint.activate([
            hoursTextField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            hoursTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            hoursTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            hoursTextField.heightAnchor.constraint(equalToConstant: 44),

            minutesTextField.topAnchor.constraint(equalTo: hoursTextField.bottomAnchor, constant: 20),
            minutesTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            minutesTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            minutesTextField.heightAnchor.constraint(equalToConstant: 44),

            chargingRateTextField.topAnchor.constraint(equalTo: minutesTextField.bottomAnchor, constant: 20),
            chargingRateTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            chargingRateTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            chargingRateTextField.heightAnchor.constraint(equalToConstant: 44),

            calculateButton.topAnchor.constraint(equalTo: chargingRateTextField.bottomAnchor, constant: 20),
            calculateButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 50),
            calculateButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -50),
            calculateButton.heightAnchor.constraint(equalToConstant: 100), // Keep the height at 100

            resultLabel.topAnchor.constraint(equalTo: calculateButton.bottomAnchor, constant: 20),
            resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            resultLabel.heightAnchor.constraint(equalToConstant: 44),
        ])
    }

    @objc func calculateButtonTapped() {
        guard let hoursText = hoursTextField.text, let minutesText = minutesTextField.text, let chargingRateText = chargingRateTextField.text,
              let hours = Double(hoursText), let minutes = Double(minutesText), let chargingRate = Double(chargingRateText) else {
           
            resultLabel.text = "Invalid input"
            return
        }

        let totalTime = hours + minutes / 60.0
        let cost = calculateChargingCost(chargingTime: totalTime, chargingRate: chargingRate)
        resultLabel.text = String(format: "Charging cost: $%.2f", cost)
    }

    func calculateChargingCost(chargingTime: Double, chargingRate: Double) -> Double {
        return chargingTime * chargingRate
    }
}
