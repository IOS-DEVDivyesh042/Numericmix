import UIKit

class RPM: UIViewController, UITextFieldDelegate {

    let engineRPMTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Engine RPM"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .numberPad
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.layer.cornerRadius = 8
        return textField
    }()

    let wheelRPMTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Wheel RPM"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .numberPad
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.layer.cornerRadius = 8
        return textField
    }()

    let tireDiameterTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Tire Diameter (inches)"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .decimalPad
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.layer.cornerRadius = 8
        return textField
    }()

    let vehicleSpeedTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Vehicle Speed (mph)"
        textField.borderStyle = .roundedRect
        textField.keyboardType = .decimalPad
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.layer.cornerRadius = 8
        return textField
    }()

    let calculateButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Calculate", for: .normal)
        button.addTarget(self, action: #selector(calculateButtonTapped), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.layer.backgroundColor = UIColor.black.cgColor
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 50
        return button
    }()

    let resultLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.text = "Output Parameters:"
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    override func loadView() {
        super.loadView()

        view.backgroundColor = .white

        view.addSubview(engineRPMTextField)
        view.addSubview(wheelRPMTextField)
        view.addSubview(tireDiameterTextField)
        view.addSubview(vehicleSpeedTextField)
        view.addSubview(calculateButton)
        view.addSubview(resultLabel)

        engineRPMTextField.delegate = self
        wheelRPMTextField.delegate = self
        tireDiameterTextField.delegate = self
        vehicleSpeedTextField.delegate = self

        NSLayoutConstraint.activate([
            
            
            engineRPMTextField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            engineRPMTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            engineRPMTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            engineRPMTextField.heightAnchor.constraint(equalToConstant: 44),
            
            wheelRPMTextField.topAnchor.constraint(equalTo: engineRPMTextField.bottomAnchor, constant: 20),
            wheelRPMTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            wheelRPMTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            wheelRPMTextField.heightAnchor.constraint(equalToConstant: 44),
            
            tireDiameterTextField.topAnchor.constraint(equalTo: wheelRPMTextField.bottomAnchor, constant: 20),
            tireDiameterTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            tireDiameterTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            tireDiameterTextField.heightAnchor.constraint(equalToConstant: 44),
            
            vehicleSpeedTextField.topAnchor.constraint(equalTo: tireDiameterTextField.bottomAnchor, constant: 20),
            vehicleSpeedTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            vehicleSpeedTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            vehicleSpeedTextField.heightAnchor.constraint(equalToConstant: 44),

            calculateButton.topAnchor.constraint(equalTo: vehicleSpeedTextField.bottomAnchor, constant: 20),
            calculateButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 50),
            calculateButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -50),
            calculateButton.heightAnchor.constraint(equalToConstant: 100), // Keep the height at 100

            resultLabel.topAnchor.constraint(equalTo: calculateButton.bottomAnchor, constant: 20),
            resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
        ])
    }

    @objc func calculateButtonTapped() {
        guard let engineRPMText = engineRPMTextField.text,
              let wheelRPMText = wheelRPMTextField.text,
              let tireDiameterText = tireDiameterTextField.text,
              let vehicleSpeedText = vehicleSpeedTextField.text,
              let engineRPM = Double(engineRPMText),
              let wheelRPM = Double(wheelRPMText),
              let tireDiameter = Double(tireDiameterText),
              let vehicleSpeed = Double(vehicleSpeedText) else {
       
            resultLabel.text = "Invalid input"
            return
        }

        let outputParameters = calculateOutputParameters(engineRPM: engineRPM, wheelRPM: wheelRPM, tireDiameter: tireDiameter, vehicleSpeed: vehicleSpeed)
        resultLabel.text = "Output Parameters:\n\(outputParameters)"
    }

    func calculateOutputParameters(engineRPM: Double, wheelRPM: Double, tireDiameter: Double, vehicleSpeed: Double) -> String {
      
        let gearRatio = wheelRPM / engineRPM
        let finalDriveRatio = vehicleSpeed / wheelRPM
        let torqueAtWheel = 100.0
        let horsepowerAtWheel = torqueAtWheel * wheelRPM / 5252.0

        return """
        Gear Ratio: \(gearRatio)
        Final Drive Ratio: \(finalDriveRatio)
        Torque at Wheel: \(torqueAtWheel)
        Horsepower at Wheel: \(horsepowerAtWheel)
        """
    }

    // Implement UITextFieldDelegate method to switch focus to the next text field
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == engineRPMTextField {
            wheelRPMTextField.becomeFirstResponder()
        } else if textField == wheelRPMTextField {
            tireDiameterTextField.becomeFirstResponder()
        } else if textField == tireDiameterTextField {
            vehicleSpeedTextField.becomeFirstResponder()
        } else {
            textField.resignFirstResponder()
        }
        return true
    }
}
