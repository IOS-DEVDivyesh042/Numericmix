

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var btn1: UIButton!
    
    @IBOutlet weak var btn2: UIButton!
    
    @IBOutlet weak var btn3: UIButton!
    
    @IBOutlet weak var view1: UIView!
    
    @IBOutlet weak var btn4: UIButton!
    
    
    @IBOutlet weak var btn5: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        view1.layer.cornerRadius = 50
        view1.layer.backgroundColor = UIColor.black.cgColor
        view1.layer.borderColor = UIColor.red.cgColor
        view1.layer.borderWidth = 5
        
        
        btn1.layer.cornerRadius = 50
        btn2.layer.cornerRadius = 50
        btn3.layer.cornerRadius = 50
        btn4.layer.cornerRadius = 50
        btn5.layer.cornerRadius = 50
        
        
//
//        btn1.layer.cornerRadius = btn1.frame.size.height / 2
//               btn1.clipsToBounds = true
//        btn2.layer.cornerRadius = btn1.frame.size.height / 2
//               btn2.clipsToBounds = true
//        btn3.layer.cornerRadius = btn1.frame.size.height / 2
//               btn3.clipsToBounds = true
//        btn4.layer.cornerRadius = btn1.frame.size.height / 2
//               btn4.clipsToBounds = true
//        btn5.layer.cornerRadius = btn1.frame.size.height / 2
//               btn5.clipsToBounds = true
//
        
        
        
        
        
        
    
    }
    
    @IBAction func btnRpm(_ sender: Any) {
    }
    
    


}

