// RadiationVC.swift

import UIKit

class Radiation: UIViewController {

    @IBOutlet weak var userInputTextField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let userInput = userInputTextField.text, let radiationLevelInGray = Double(userInput) {
            let convertedValues = convertToOtherRadiationUnits(radiationLevelInGray)
            navigateToResultViewController(with: convertedValues)
        } else {
            showAlert(message: "Please enter a valid radiation level.")
        }
    }

    func convertToOtherRadiationUnits(_ radiationLevelInGray: Double) -> [String: Double] {
        let radiationLevelInSieverts = radiationLevelInGray
        let radiationLevelInMillisieverts = radiationLevelInGray * 1000
        let radiationLevelInMicrosieverts = radiationLevelInGray * 1_000_000
        let radiationLevelInRem = radiationLevelInGray * 100
        let radiationLevelInMillirem = radiationLevelInGray * 100_000

        return [
            "Sieverts": radiationLevelInSieverts,
            "Millisieverts": radiationLevelInMillisieverts,
            "Microsieverts": radiationLevelInMicrosieverts,
            "Rem": radiationLevelInRem,
            "Millirem": radiationLevelInMillirem
        ]
    }

    func navigateToResultViewController(with values: [String: Double]) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let resultViewController = storyboard.instantiateViewController(withIdentifier: "ResultVC") as? ResultVC {
            resultViewController.resultValues = values
            self.present(resultViewController, animated: true, completion: nil)
        }
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { [weak self] _ in
            self?.dismiss(animated: true, completion: nil)
        }
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
}
