import UIKit

class Raddose : UIViewController {

    @IBOutlet weak var userInputTextField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let userInput = userInputTextField.text, let absorbedDoseInGray = Double(userInput) {
            let convertedValues = convertToOtherAbsorbedDoseUnits(absorbedDoseInGray)
            navigateToResultViewController(with: convertedValues)
        } else {
            showAlert(message: "Please enter a valid radiation absorbed dose.")
        }
    }

    func convertToOtherAbsorbedDoseUnits(_ absorbedDoseInGray: Double) -> [String: Double] {
        let absorbedDoseInRad = absorbedDoseInGray * 100
        let absorbedDoseInSieverts = absorbedDoseInGray
        let absorbedDoseInMilligray = absorbedDoseInGray * 1000
        let absorbedDoseInMicrogray = absorbedDoseInGray * 1_000_000
        let absorbedDoseInJoulesPerKilogram = absorbedDoseInGray

        return [
            "Rad": absorbedDoseInRad,
            "Sieverts": absorbedDoseInSieverts,
            "Milligrays": absorbedDoseInMilligray,
            "Micrograys": absorbedDoseInMicrogray,
            "Joules/Kilogram": absorbedDoseInJoulesPerKilogram
        ]
    }

    func navigateToResultViewController(with values: [String: Double]) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let resultViewController = storyboard.instantiateViewController(withIdentifier: "ResultVC") as? ResultVC {
            resultViewController.resultValues = values
            self.present(resultViewController, animated: true, completion: nil)
        }
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
}
