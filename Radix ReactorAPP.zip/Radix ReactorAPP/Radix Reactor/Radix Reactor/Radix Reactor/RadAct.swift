import UIKit

class RadAct: UIViewController {

    @IBOutlet weak var userInputTextField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let userInput = userInputTextField.text, let activityInBecquerels = Double(userInput) {
            let convertedValues = convertToOtherActivityUnits(activityInBecquerels)
            navigateToResultViewController(with: convertedValues)
        } else {
            showAlert(message: "Please enter a valid radiation activity.")
        }
    }

    func convertToOtherActivityUnits(_ activityInBecquerels: Double) -> [String: Double] {
        let activityInCuries = activityInBecquerels * 2.7027e-11
        let activityInRutherfords = activityInBecquerels * 1.0e-6
        let activityInDisintegrationsPerMinute = activityInBecquerels * 60.0
        let activityInDisintegrationsPerSecond = activityInBecquerels

        return [
            "Curies": activityInCuries,
            "Rutherfords": activityInRutherfords,
            "DPM (Disintegrations/Minute)": activityInDisintegrationsPerMinute,
            "DPS (Disintegrations/Second)": activityInDisintegrationsPerSecond
        ]
    }

    func navigateToResultViewController(with values: [String: Double]) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let resultViewController = storyboard.instantiateViewController(withIdentifier: "ResultVC") as? ResultVC {
            resultViewController.resultValues = values
            self.present(resultViewController, animated: true, completion: nil)
        }
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
}
