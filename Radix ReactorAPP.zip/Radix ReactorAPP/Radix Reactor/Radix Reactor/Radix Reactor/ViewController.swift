//
//  ViewController.swift
//  Radix Reactor
//
//  Created by Manish Bhanushali on 26/11/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var btn1: UIButton!
    
    @IBOutlet weak var btn2: UIButton!
    
    @IBOutlet weak var btn4: UIButton!
    
    @IBOutlet weak var btn3: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        btn1.layer.cornerRadius = 20
        btn3.layer.cornerRadius = 20
        btn2.layer.cornerRadius = 20
        btn4.layer.cornerRadius = 20
        // Do any additional setup after loading the view.
    }


}

