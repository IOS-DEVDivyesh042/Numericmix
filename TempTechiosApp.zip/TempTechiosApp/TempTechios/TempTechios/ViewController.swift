


import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var view1: UIView!
    
    
    @IBOutlet weak var view2: UIView!
    
    @IBOutlet weak var btn1: UIButton!
    
    
    @IBOutlet weak var btn2: UIButton!
    
    @IBOutlet weak var btn3: UIButton!
    
    
    
    
    @IBOutlet weak var btn4: UIButton!
    
    
    
    @IBOutlet weak var btn5: UIButton!
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        view1.layer.cornerRadius = 50
        view2.layer.cornerRadius = 50
        btn1.layer.cornerRadius = 5
        btn2.layer.cornerRadius = 5
        btn3.layer.cornerRadius = 5
        btn4.layer.cornerRadius = 5
        btn5.layer.cornerRadius = 5
        
        
        
        
        
    }


}

